﻿/*******************************************************************************************************/
// File:    MapL10.cs
// Summary: Creates map for level 10 and its elements: Enemies, planets, 
// Version: Version 1.0 - 2016-06-14
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-06-14 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class MapL10 : MapTemplate
    {
        public static readonly int NUMBER_OF_BG_STARS = 800;
        public static readonly int NUMBER_OF_PLANETS = 2;
        public static readonly int NUMBER_OF_ASTEROIDS = 20;
        public static readonly int NUMBER_OF_CLASS2_ENEMIES = 10;
        public static readonly int NUMBER_OF_ENEMIES_PER_PLANET = 7;
        // List of background stars, planets, asteroids and enemies
        System.Collections.Generic.List<Star> bgStars;
        System.Collections.Generic.List<Star> bgStarsLayer2;
        System.Collections.Generic.List<Planet> planets;
        System.Collections.Generic.List<Asteroid> asteroids;
        System.Collections.Generic.List<EnemyTemplate> enemies;
        System.Collections.Generic.List<BeamModel> enemyBeams = new System.Collections.Generic.List<BeamModel>();

        public MapL10(Player player)
        {
            bgStars = new System.Collections.Generic.List<Star>();
            bgStarsLayer2 = new System.Collections.Generic.List<Star>();
            planets = new System.Collections.Generic.List<Planet>();
            asteroids = new System.Collections.Generic.List<Asteroid>();
            enemies = new System.Collections.Generic.List<EnemyTemplate>();
            borderRadius = 2.0f; // Radius of the area the player is allowed to be in the map.
            musicTitle = "Boss3"; // Music

            // PLANETS

            Vector2[] planetModelPositions = new Vector2[]
            {
                new Vector2(1.8f, -0.2f),  // yellow
                new Vector2(1.8f, 0),   // dark
            };

            float[] planetModelRadius = new float[]
            {
                0.1f, 0.25f
            };

            // Ability obtained when visiting the planet
            PlanetPower[] planetPower = new PlanetPower[]
            {
                PlanetPower.None, PlanetPower.None
            };

            // Setting players weapons/abilities for the map
            Player.BEAM_WEAPON.setBeamDamage(15);
            Player.BEAM_WEAPON.setBeamColor(Color.Orange);
            Player.BEAM_WEAPON.setAutoFireState(AutoFireState.NotLoaded);
            Player.MISSILE_WEAPON.setMissileState(MissileState.NotLoaded);
            Player.SHIELD.setShieldState(ShieldState.Powered);
            Player.SHIELD.setHitPoints(Player.SHIELD.STARTING_HITPOINTS);
            Player.FURY_MODE.setFuryState(FuryState.NotLoaded);
            Player.FURY_MODE.setFuryLoadTime(3.0f);
            Player.FURY_MODE.setFuryLoadTimer();

            LandingStatus[] landingStatus = new LandingStatus[] 
            {
                LandingStatus.Landable, LandingStatus.NotLandable
            };

            PlanetTexture[] planetTextures = new PlanetTexture[]
            {
                PlanetTexture.Yellow, PlanetTexture.Dark
            };

            // CLASS 2 ENEMIES and LURKERS are spread randomly on the map, excluding area near the player (centre of map, avoiding enemy to spawn on player)

            for (int index = 0; index < NUMBER_OF_CLASS2_ENEMIES; index++)
            {
                Vector2 position = borderRadius * (float)Geometry.rand.NextDouble() * Geometry.PlaceRandomInCircle();
                int x = index / 2;

                if (System.Math.Abs(position.X) > borderRadius / 5 && System.Math.Abs(position.Y) > borderRadius / 5 && x * 2 == index)
                {
                    enemies.Add(new Class3Enemy(player, position));
                }
                else if (System.Math.Abs(position.X) > borderRadius / 5 && System.Math.Abs(position.Y) > borderRadius / 5 && x * 2 != index)
                {
                    enemies.Add(new Tractor(player, position));
                }
                else
                {
                    index--; // Enemy will get new coordinates if they were too near centre of map
                }
            }

            // POSITIONING PLANETS AND PLANET ENEMIES ON MAP

            for (int count = 0; count < NUMBER_OF_PLANETS; count++)
            {
                // PLANETS

                planets.Add(new Planet(planetModelPositions[count], planetModelRadius[count], planetPower[count], landingStatus[count], planetTextures[count]));

                // PLANET CLASS 1 ENEMIES

                if (count > 0)
                {
                    for (int index = 0; index < NUMBER_OF_ENEMIES_PER_PLANET; index++)
                    {
                        Vector2 position = new Vector2(
                            planetModelPositions[count].X + 0.5f * (float)(Geometry.rand.NextDouble() - 0.5f),
                            planetModelPositions[count].Y + 0.5f * (float)(Geometry.rand.NextDouble() - 0.5f)
                        );
                        enemies.Add(new Class2Enemy(player, position));
                    }
                }
            }

            // CARRIER (BOSS)
            EnemyTemplate carrier = new Carrier(player, new Vector2(0.7f, 0));
            enemies.Add(carrier);

            // TRACTOR ENEMIES
            enemies.Add(new Tractor(player, new Vector2(0.7f, 0.2f)));
            enemies.Add(new Tractor(player, new Vector2(0.7f, -0.2f)));


            // Creating BACKGROUND STARS

            for (int index = 0; index < NUMBER_OF_BG_STARS; index++)
            {
                Star star = createStar(bgStar);

                if (bgStar)
                {
                    // Faint stars
                    bgStars.Add(star);
                    bgStar = false;
                }
                else
                {
                    // Near stars
                    bgStarsLayer2.Add(star);
                    bgStar = true;
                }
            }

            // Creating ASTEROIDS

            // Creating ASTEROIDS of various types. Big more seldom than small

            asteroids = createAsteroids(NUMBER_OF_ASTEROIDS);
        }

        /// <summary>
        /// GET METHODS
        /// </summary>
        /// <returns></returns>
        public override System.Collections.Generic.List<Star> getBgStars() { return bgStars; }
        public override System.Collections.Generic.List<Star> getBgStarsLayer2() { return bgStarsLayer2; }
        public override System.Collections.Generic.List<Planet> getPlanets() { return planets; }
        public override System.Collections.Generic.List<Asteroid> getAsteroids() { return asteroids; }
        public override System.Collections.Generic.List<EnemyTemplate> getEnemies() { return enemies; }
        public override System.Collections.Generic.List<BeamModel> getEnemyBeams() { return enemyBeams; }
    }
}
