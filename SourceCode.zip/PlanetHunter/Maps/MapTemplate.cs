﻿/*******************************************************************************************************/
// File:    MapTemplate.cs
// Summary: Astract class containing methods used in the maps
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    abstract class MapTemplate
    {
        public static readonly Vector2[] AsteroidPositionsOnTexture = new Vector2[] {
            new Vector2(470, 0),
            new Vector2(540, 140),
            new Vector2(568, 223),
            new Vector2(584, 333),
            new Vector2(566, 422),
            new Vector2(523, 504)
        };
        public static readonly Vector2[] AsteroidSizesOnTexture = new Vector2[] {
            new Vector2(100, 125),
            new Vector2(65, 45),
            new Vector2(50, 40),
            new Vector2(20, 30),
            new Vector2(15, 15),
            new Vector2(6, 6)
        };
        public static readonly int[] AsteroidDamage = new int[] { 50, 20, 20, 10, 5, 3 };

        protected float borderRadius;
        protected bool bgStar = true;
        protected string musicTitle;
        /// <summary>
        /// GET METHODS
        /// </summary>
        public abstract System.Collections.Generic.List<Star> getBgStars();
        public abstract System.Collections.Generic.List<Star> getBgStarsLayer2();
        public abstract System.Collections.Generic.List<Planet> getPlanets();
        public abstract System.Collections.Generic.List<Asteroid> getAsteroids();
        public abstract System.Collections.Generic.List<EnemyTemplate> getEnemies();
        public abstract System.Collections.Generic.List<BeamModel> getEnemyBeams();
        public float getBorderRadius() { return borderRadius; }
        public string getMusicTitle() { return musicTitle; }

        // Creating ASTEROIDS of various types. Big more seldom than small
        public System.Collections.Generic.List<Asteroid> createAsteroids(int numberOfAsteroids)
        {
            System.Collections.Generic.List<Asteroid> asteroids = new System.Collections.Generic.List<Asteroid>();

            for (int index = 0; index < numberOfAsteroids; index++)
            {
                Vector2 position = (float)Geometry.rand.NextDouble() * borderRadius * Geometry.PlaceRandomInCircle();

                if (System.Math.Sqrt(position.X * position.X + position.Y * position.Y) > borderRadius / 10 && 50 * (index / 50) == index)
                {
                    asteroids.Add(new Asteroid(position, 50, 0));
                }
                else if (System.Math.Sqrt(position.X * position.X + position.Y * position.Y) > borderRadius / 10 && 20 * (index / 20) == index)
                {
                    asteroids.Add(new Asteroid(position, 35, 1));
                }
                else if (System.Math.Sqrt(position.X * position.X + position.Y * position.Y) > borderRadius / 10 && 10 * (index / 10) == index)
                {
                    asteroids.Add(new Asteroid(position, 25, 2));
                }
                else if (System.Math.Sqrt(position.X * position.X + position.Y * position.Y) > borderRadius / 10 && 6 * (index / 6) == index)
                {
                    asteroids.Add(new Asteroid(position, 20, 3));
                }
                else if (System.Math.Sqrt(position.X * position.X + position.Y * position.Y) > borderRadius / 10 && 2 * (index / 2) == index)
                {
                    asteroids.Add(new Asteroid(position, 15, 4));
                }
                else if (System.Math.Sqrt(position.X * position.X + position.Y * position.Y) > borderRadius / 10)
                {
                    asteroids.Add(new Asteroid(position, 10, 5));
                }
                else
                {
                    index--;
                }
            }
            return asteroids;
        }

        public Star createStar(bool bgStar)
        {
            Star star;

            int colorNumber = (int)(Geometry.rand.NextDouble() * 4);
            Color starColor = Color.White;

            switch (colorNumber)
            {
                case 0:
                    starColor = Color.Blue;
                    break;
                case 1:
                    starColor = Color.White;
                    break;
                case 2:
                    starColor = Color.Yellow;
                    break;
                case 3:
                    starColor = Color.Red;
                    break;
            }
            if (bgStar)
            {
                // Faint white stars
                Vector2 position = (float)Geometry.rand.NextDouble() * borderRadius * 1.2f * Geometry.PlaceRandomInCircle();
                star = new Star(position, 9, starColor);
            }
            else
            {
                // Faint white stars
                Vector2 position = (float)Geometry.rand.NextDouble() * borderRadius * 1.2f * Geometry.PlaceRandomInCircle();
                star = new Star(position, 20, starColor);
            }

            return star;
        }
    }
}
