﻿/*******************************************************************************************************/
// File:    MapL1.cs
// Summary: Creates map for level 1 and its elements: Enemies, planets, 
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Media;

namespace Model
{
    class MapL1 : MapTemplate
    {
        public static readonly int NUMBER_OF_BG_STARS = 800;
        public static readonly int NUMBER_OF_PLANETS = 7;
        public static readonly int NUMBER_OF_ASTEROIDS = 20;
        public static readonly int NUMBER_OF_CLASS2_ENEMIES = 10;
        public static readonly int NUMBER_OF_ENEMIES_PER_PLANET = 3;
        // List of background stars, planets, asteroids and enemies
        System.Collections.Generic.List<Star> bgStars;
        System.Collections.Generic.List<Star> bgStarsLayer2;
        System.Collections.Generic.List<Planet> planets;
        PlanetTexture[] planetTextures;
        System.Collections.Generic.List<Asteroid> asteroids;
        System.Collections.Generic.List<EnemyTemplate> enemies;
        System.Collections.Generic.List<BeamModel> enemyBeams;        

        public MapL1(Player player)
        {
            bgStars = new System.Collections.Generic.List<Star>();
            bgStarsLayer2 = new System.Collections.Generic.List<Star>();
            planets = new System.Collections.Generic.List<Planet>();
            asteroids = new System.Collections.Generic.List<Asteroid>();
            enemies = new System.Collections.Generic.List<EnemyTemplate>();
            enemyBeams = new System.Collections.Generic.List<BeamModel>();
            // Radius of the area the player is allowed to be on the map.
            borderRadius = 2.0f;
            musicTitle = "Music1"; // Music

            // PLANETS

            Vector2[] planetModelPositions = new Vector2[]
            {
                new Vector2(-0.2f, -0.2f),  // yellow
                new Vector2(0, -1.8f),      // dark
                new Vector2(-0.2f, -1.7f),  // red
                new Vector2(1.5f, 0.2f),    // ocean

                new Vector2(-0.3f, 1.5f),   // neptune
                new Vector2(-0.5f, 1.3f),   // methane
                new Vector2(0.8f, 1.6f),     // yellow_green
            };

            float[] planetModelRadius = new float[]
            {
                0.1f, 0.25f, 0.07f, 0.1f,
                0.3f, 0.05f, 0.12f
            };

            // Ability obtained when visiting the planet
            PlanetPower[] planetPower = new PlanetPower[]
            {
                PlanetPower.AutoFire, PlanetPower.None, PlanetPower.Missile, PlanetPower.HpRestore,
                PlanetPower.None, PlanetPower.HpRestore, PlanetPower.None
            };

            Player.BEAM_WEAPON.setBeamDamage(10);
            Player.BEAM_WEAPON.setBeamColor(Color.Yellow);
            Player.BEAM_WEAPON.setAutoFireState(AutoFireState.OffPlayer);
            Player.MISSILE_WEAPON.setMissileState(MissileState.OffPlayer);
            Player.SHIELD.setShieldState(ShieldState.OffPlayer);
            Player.SHIELD.setHitPoints(Player.SHIELD.STARTING_HITPOINTS);
            Player.FURY_MODE.setFuryState(FuryState.OffPlayer);
            Player.FURY_MODE.setFuryLoadTime(5.0f);
            Player.FURY_MODE.setFuryLoadTimer();

            LandingStatus[] landingStatus = new LandingStatus[] 
            {
                LandingStatus.Landable, LandingStatus.NotLandable, LandingStatus.Landable, LandingStatus.Landable,
                LandingStatus.NotLandable, LandingStatus.Landable, LandingStatus.Landable
            };

            planetTextures = new PlanetTexture[]
            {
                PlanetTexture.Yellow, PlanetTexture.Dark, PlanetTexture.Red, PlanetTexture.Ocean,
                PlanetTexture.NeptuneLike, PlanetTexture.Methane, PlanetTexture.YellowGreen
            };
            
            // CLASS 2 ENEMIES is spread randomly on the map, excluding area near the player (centre of map, avoiding enemy to spawn on player)

            for (int index = 0; index < NUMBER_OF_CLASS2_ENEMIES; index++)
            {
                Vector2 position = borderRadius * (float)Geometry.rand.NextDouble() * Geometry.PlaceRandomInCircle();

                if (System.Math.Abs(position.X) > borderRadius / 3 && System.Math.Abs(position.Y) > borderRadius / 3)
                {
                    enemies.Add(new Class2Enemy(player, position));
                }
                else
                {
                    index--; // Enemy will get new coordinates if they were too near centre of map
                }
            }
            
            // NEAREST PLANET

            planets.Add(new Planet(planetModelPositions[0], planetModelRadius[0], planetPower[0], landingStatus[0], planetTextures[0]));
            
            // POSITIONING the PLANETS AND ENEMIES near the planets
            
            for (int count = 1; count < NUMBER_OF_PLANETS; count++)
            {
                // PLANETS

                planets.Add(new Planet(planetModelPositions[count], planetModelRadius[count], planetPower[count], landingStatus[count], planetTextures[count]));

                // ENEMIES near PLANET 
                
                if (count > 0)
                {
                    for (int index = 0; index < NUMBER_OF_ENEMIES_PER_PLANET; index++)
                    {
                        Vector2 position = new Vector2(
                            planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f),
                            planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f)
                        );
                        enemies.Add(new Class1Enemy(player, position));
                    }
                }
                
                // A DEFENCE STATION is placed near one of the planets

                if (count == NUMBER_OF_PLANETS - 1)
                {
                    Vector2 position = new Vector2(
                        planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f),
                        planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f)
                    );
                    enemies.Add(new DefenceStation(player, position));
                }
                
            }
            
            // Creating BACKGROUND STARS

            for (int index = 0; index < NUMBER_OF_BG_STARS; index++)
            {
                Star star = createStar(bgStar);

                if (bgStar)
                {
                    // Faint stars
                    bgStars.Add(star);
                    bgStar = false;
                }
                else
                {
                    // Near stars
                    bgStarsLayer2.Add(star);
                    bgStar = true;
                }
            }

            asteroids = createAsteroids(NUMBER_OF_ASTEROIDS);
        }

        /// <summary>
        /// GET METHODS
        /// </summary>
        public override System.Collections.Generic.List<Star> getBgStars() { return bgStars; }
        public override System.Collections.Generic.List<Star> getBgStarsLayer2() { return bgStarsLayer2; }
        public override System.Collections.Generic.List<Planet> getPlanets() { return planets; }
        // public override PlanetTexture[] getPlanetTextures() { return planetTextures; }
        public override System.Collections.Generic.List<Asteroid> getAsteroids() { return asteroids; }
        public override System.Collections.Generic.List<EnemyTemplate> getEnemies() { return enemies; }
        public override System.Collections.Generic.List<BeamModel> getEnemyBeams() { return enemyBeams; }
    }
}
