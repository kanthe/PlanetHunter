﻿/*******************************************************************************************************/
// File:    MapL9.cs
// Summary: Creates map for level 9 and its elements: Enemies, planets, 
// Version: Version 1.0 - 2016-06-15
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-06-15 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class MapL9 : MapTemplate
    {
        public static readonly int NUMBER_OF_BG_STARS = 800;
        public static readonly int NUMBER_OF_PLANETS = 7;
        public static readonly int NUMBER_OF_ASTEROIDS = 100;
        public static readonly int NUMBER_OF_CLASS2_ENEMIES = 10;
        public static readonly int NUMBER_OF_ENEMIES_PER_PLANET = 3;
        // List of background stars, planets, asteroids and enemies
        System.Collections.Generic.List<Star> bgStars;
        System.Collections.Generic.List<Star> bgStarsLayer2;
        System.Collections.Generic.List<Planet> planets;
        System.Collections.Generic.List<Asteroid> asteroids;
        System.Collections.Generic.List<EnemyTemplate> enemies;
        System.Collections.Generic.List<BeamModel> enemyBeams = new System.Collections.Generic.List<BeamModel>();

        public MapL9(Player player)
        {
            bgStars = new System.Collections.Generic.List<Star>();
            bgStarsLayer2 = new System.Collections.Generic.List<Star>();
            planets = new System.Collections.Generic.List<Planet>();
            asteroids = new System.Collections.Generic.List<Asteroid>();
            enemies = new System.Collections.Generic.List<EnemyTemplate>();
            borderRadius = 2.0f; // Radius of the area the player is allowed to be in the map.
            musicTitle = "Music5"; // Music

            // PLANETS

            Vector2[] planetModelPositions = new Vector2[]
            {
                new Vector2(-0.2f, -0.2f),   // blue_red
                new Vector2(0.3f, 0.5f),     // Pink
                new Vector2(0.5f, 0.3f),     // methane
                new Vector2(-0.5f, -1.7f),   // jupiter-like
                new Vector2(-0.5f, -1.8f),   // yellow_green
                new Vector2(-1.0f, 0.5f),    // Green
                new Vector2(0.8f, -0.6f)     // Dark
            };

            float[] planetModelRadius = new float[]
            {
                0.1f, 0.25f, 0.07f, 0.1f, 0.3f, 0.05f, 0.12f
            };

            // Ability obtained when visiting the planet
            PlanetPower[] planetPower = new PlanetPower[]
            {
                PlanetPower.HpRestore, PlanetPower.None, PlanetPower.HpRestore, PlanetPower.None, PlanetPower.HpRestore, PlanetPower.ShieldRestore, PlanetPower.None
            };

            // Setting players weapons/abilities for the map
            Player.BEAM_WEAPON.setBeamDamage(15);
            Player.BEAM_WEAPON.setBeamColor(Color.Orange);
            Player.BEAM_WEAPON.setAutoFireState(AutoFireState.NotLoaded);
            Player.MISSILE_WEAPON.setMissileState(MissileState.NotLoaded);
            Player.SHIELD.setShieldState(ShieldState.Powered);
            Player.SHIELD.setHitPoints(Player.SHIELD.STARTING_HITPOINTS);
            Player.FURY_MODE.setFuryState(FuryState.NotLoaded);
            Player.FURY_MODE.setFuryLoadTime(5.0f);
            Player.FURY_MODE.setFuryLoadTimer();

            LandingStatus[] landingStatus = new LandingStatus[] 
            {
                LandingStatus.Landable, LandingStatus.NotLandable, LandingStatus.Landable, LandingStatus.NotLandable, LandingStatus.Landable, LandingStatus.Landable, LandingStatus.NotLandable
            };

            PlanetTexture[] planetTextures = new PlanetTexture[]
            {
                PlanetTexture.BlueRed, PlanetTexture.Pink, PlanetTexture.Methane, PlanetTexture.JupiterLike, PlanetTexture.YellowGreen, PlanetTexture.Green, PlanetTexture.Dark
            };

            // CLASS 2 ENEMIES and LURKERS are spread randomly on the map, excluding area near the player (centre of map, avoiding enemy to spawn on player)

            for (int index = 0; index < NUMBER_OF_CLASS2_ENEMIES; index++)
            {
                Vector2 position = borderRadius * (float)Geometry.rand.NextDouble() * Geometry.PlaceRandomInCircle();

                if (System.Math.Abs(position.X) > borderRadius / 5)
                {
                    enemies.Add(new Class2Enemy(player, position));
                }
                else
                {
                    index--; // Enemy will get new coordinates if they were too near centre of map
                }
            }

            // NEAREST PLANET and its ENEMIES (avoiding enemies to spawn at player)

            planets.Add(new Planet(planetModelPositions[0], planetModelRadius[0], planetPower[0], landingStatus[0], planetTextures[0]));

            enemies.Add(new Class1Enemy(player, new Vector2(-0.3f, -0.3f)));
            enemies.Add(new Class1Enemy(player, new Vector2(-0.3f, -0.2f)));
            enemies.Add(new Joker(player, new Vector2(-0.2f, -0.3f)));

            // NEXT NEAREST PLANETS and its ENEMIES (avoiding enemies to spawn at player)

            planets.Add(new Planet(planetModelPositions[1], planetModelRadius[1], planetPower[1], landingStatus[1], planetTextures[1]));

            // POSITIONING PLANETS AND PLANET ENEMIES ON MAP

            for (int count = 2; count < NUMBER_OF_PLANETS; count++)
            {
                // PLANETS

                planets.Add(new Planet(planetModelPositions[count], planetModelRadius[count], planetPower[count], landingStatus[count], planetTextures[count]));

                // PLANET ENEMIES
                Vector2 position;

                for (int noOfClass1 = 0; noOfClass1 < 2; noOfClass1++)
                {
                    position =
                        new Vector2(
                            planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f),
                            planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f)
                        );
                    enemies.Add(new Class1Enemy(player, position));
                }
                for (int noOfTractors = 0; noOfTractors < 1; noOfTractors++)
                {
                    position =
                        new Vector2(
                            planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f),
                            planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f)
                        );
                    enemies.Add(new Tractor(player, position));
                }
                for (int noOfTeleporters = 0; noOfTeleporters < 1; noOfTeleporters++)
                {
                    position =
                        new Vector2(
                            planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f),
                            planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f)
                        );
                    enemies.Add(new Teleporter(player, position));
                }
                for (int noOfJokers = 0; noOfJokers < 2; noOfJokers++)
                {
                    position =
                        new Vector2(
                            planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f),
                            planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f)
                        );
                    enemies.Add(new Joker(player, position));
                }

                for (int noOfLurkers = 0; noOfLurkers < 1; noOfLurkers++)
                {
                    position =
                        new Vector2(
                            planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f),
                            planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f)
                        );
                    enemies.Add(new Lurker(player, position));
                }

                // DEFENCE STATION is placed near one planet
                if (count == 3)
                {
                    Vector2 stationPosition = new Vector2(
                        planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f),
                        planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f)
                    );
                    enemies.Add(new DefenceStation(player, stationPosition));
                }

                // BATTLESHIP is placed near one planet
                if (count == NUMBER_OF_PLANETS - 1)
                {
                    Vector2 stationPosition = new Vector2(
                        planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f),
                        planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f)
                    );
                    enemies.Add(new BattleShip(player, stationPosition));
                }
            }


            // Creating BACKGROUND STARS

            for (int index = 0; index < NUMBER_OF_BG_STARS; index++)
            {
                Star star = createStar(bgStar);

                if (bgStar)
                {
                    // Faint stars
                    bgStars.Add(star);
                    bgStar = false;
                }
                else
                {
                    // Near stars
                    bgStarsLayer2.Add(star);
                    bgStar = true;
                }
            }

            // Creating ASTEROIDS of various types. Big more seldom than small
            asteroids = createAsteroids(NUMBER_OF_ASTEROIDS);
        }

        /// <summary>
        /// GET METHODS
        /// </summary>
        /// <returns></returns>
        public override System.Collections.Generic.List<Star> getBgStars() { return bgStars; }
        public override System.Collections.Generic.List<Star> getBgStarsLayer2() { return bgStarsLayer2; }
        public override System.Collections.Generic.List<Planet> getPlanets() { return planets; }
        public override System.Collections.Generic.List<Asteroid> getAsteroids() { return asteroids; }
        public override System.Collections.Generic.List<EnemyTemplate> getEnemies() { return enemies; }
        public override System.Collections.Generic.List<BeamModel> getEnemyBeams() { return enemyBeams; }
    }
}
