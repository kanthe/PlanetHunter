﻿/*******************************************************************************************************/
// File:    Planet.cs
// Summary: Creates a planet
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    // Abilities obtained from the planet
    public enum PlanetPower { None, HpRestore, BeamEnhance, AutoFire, Missile, Shield, ShieldRestore, Fury, FuryEnhance}
    // Names of all planets
    public enum PlanetTexture { Dark, Green, JupiterLike, Methane, NeptuneLike, UranusLike, Ocean, Pink, Red, Yellow, YellowGreen, BlueRed, YellowRed, Grey, Cracks, MoreCracks }
    // Landing status
    public enum LandingStatus { NotLandable, Landable, PlayerOverPlanet, PlayerIsLanding, PlayerHasLanded }

    class Planet
    {
        Vector2 position;
        float diameter;
        PlanetPower power;
        LandingStatus landingStatus;
        PlanetTexture planetTexture;
        Timer landTimer = new Timer(Player.LANDING_TIME);
        public int countDownState = 0;

        public Planet(Vector2 position, float diameter, PlanetPower power, LandingStatus landingStatus, PlanetTexture planetTexture)
        {
            this.position = position;
            this.diameter = diameter;
            this.landingStatus = landingStatus;
            this.power = power;
            this.planetTexture = planetTexture;
        }

        // GET METHODS

        public Vector2 getPosition() { return position; }
        public float getDiameter() { return diameter; }
        public LandingStatus getLandingStatus() { return landingStatus; }
        public PlanetPower getPower() { return power; }
        public PlanetTexture getPlanetTexture() { return planetTexture; }
        public Timer getLandTimer() { return landTimer; }

        // SET METHODS

        public void setLandingStatus(LandingStatus landingStatus) { this.landingStatus = landingStatus; }
        public void resetLandTimer() { landTimer.resetTimer(); }
    }
}
