﻿/*******************************************************************************************************/
// File:    MapL2.cs
// Summary: Creates map for level 2 and its elements: Enemies, planets, 
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class MapL2 : MapTemplate
    {
        public static readonly int NUMBER_OF_BG_STARS = 800;
        public static readonly int NUMBER_OF_PLANETS = 7;
        public static readonly int NUMBER_OF_ASTEROIDS = 50;
        public static readonly int NUMBER_OF_CLASS2_ENEMIES = 10;
        public static readonly int NUMBER_OF_ENEMIES_PER_PLANET = 3;
        // List of background stars, planets, asteroids and enemies
        System.Collections.Generic.List<Star> bgStars;
        System.Collections.Generic.List<Star> bgStarsLayer2;
        System.Collections.Generic.List<Planet> planets;
        System.Collections.Generic.List<Asteroid> asteroids;
        System.Collections.Generic.List<EnemyTemplate> enemies;
        System.Collections.Generic.List<BeamModel> enemyBeams = new System.Collections.Generic.List<BeamModel>();

        public MapL2(Player player)
        {
            bgStars = new System.Collections.Generic.List<Star>();
            bgStarsLayer2 = new System.Collections.Generic.List<Star>();
            planets = new System.Collections.Generic.List<Planet>();
            asteroids = new System.Collections.Generic.List<Asteroid>();
            enemies = new System.Collections.Generic.List<EnemyTemplate>();
            borderRadius = 2.0f; // Radius of the area the player is allowed to be in the map.
            musicTitle = "Music2"; // Music

            // PLANETS

            Vector2[] planetModelPositions = new Vector2[]
            {
                new Vector2(-0.2f, -0.2f),   // blue_red
                new Vector2(0.3f, 0.5f),     // Pink
                new Vector2(0.5f, 0.3f),     // methane
                new Vector2(-0.5f, -1.7f),   // jupiter-like
                new Vector2(-0.5f, -1.8f),   // yellow_green
                new Vector2(-1.0f, 0.5f),    // Green
                new Vector2(0.8f, -0.6f)     // Dark
            };

            float[] planetModelRadius = new float[]
            {
                0.1f, 0.25f, 0.07f, 0.1f, 0.3f, 0.05f, 0.12f
            };

            // Ability obtained when visiting the planet
            PlanetPower[] planetPower = new PlanetPower[]
            {
                PlanetPower.HpRestore, PlanetPower.None, PlanetPower.None, PlanetPower.None, PlanetPower.HpRestore, PlanetPower.BeamEnhance, PlanetPower.None
            };

            LandingStatus[] landingStatus = new LandingStatus[] 
            {
                LandingStatus.Landable, LandingStatus.NotLandable, LandingStatus.Landable, LandingStatus.NotLandable, LandingStatus.Landable, LandingStatus.Landable, LandingStatus.Landable
            };

            PlanetTexture[] planetTextures = new PlanetTexture[]
            {
                PlanetTexture.BlueRed, PlanetTexture.Pink, PlanetTexture.Methane, PlanetTexture.JupiterLike, PlanetTexture.YellowGreen, PlanetTexture.Green, PlanetTexture.Dark
            };

            // Setting players weapons/abilities for the map
            Player.BEAM_WEAPON.setAutoFireState(AutoFireState.NotLoaded);
            Player.MISSILE_WEAPON.setMissileState(MissileState.NotLoaded);

            // CLASS 2 ENEMIES is spread randomly on the map, excluding area near the player (centre of map, avoiding eney to spawn on player)

            for (int index = 0; index < NUMBER_OF_CLASS2_ENEMIES; index++)
            {
                Vector2 position = borderRadius * (float)Geometry.rand.NextDouble() * Geometry.PlaceRandomInCircle();

                if (System.Math.Abs(position.X) > borderRadius / 5 && System.Math.Abs(position.Y) > borderRadius / 5)
                {
                    enemies.Add(new Class2Enemy(player, position));
                }
                else
                {
                    index--; // Enemy will get new coordinates if they were too near centre of map
                }
            }

            // NEAREST PLANET and its ENEMIES (avoiding enemies to spawn at player)

            planets.Add(new Planet(planetModelPositions[0], planetModelRadius[0], planetPower[0], landingStatus[0], planetTextures[0]));

            enemies.Add(new Class1Enemy(player, new Vector2(-0.3f, -0.3f)));
            enemies.Add(new Tractor(player, new Vector2(-0.3f, -0.2f)));

            // NEXT NEAREST PLANETS and its ENEMIES (avoiding enemies to spawn at player)
            
            planets.Add(new Planet(planetModelPositions[1], planetModelRadius[1], planetPower[1], landingStatus[1], planetTextures[1]));

            // POSITIONING PLANETS AND PLANET ENEMIES ON MAP

            for (int count = 2; count < NUMBER_OF_PLANETS; count++)
            {
                // PLANETS

                planets.Add(new Planet(planetModelPositions[count], planetModelRadius[count], planetPower[count], landingStatus[count], planetTextures[count]));

                // PLANET ENEMIES

                for (int index = 0; index < NUMBER_OF_ENEMIES_PER_PLANET; index++)
                {
                    Vector2 position =
                        new Vector2(
                            planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f),
                            planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 0.5f)
                        );
                    enemies.Add(new Class1Enemy(player, position));
                }

                // TELEPORTER is placed near the next nearest planet
                if (count == 3)
                {
                    for (int i = 0; i < 2; i++)
                    {
                        Vector2 teleporterPosition = new Vector2(
                            planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f),
                            planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f)
                        );
                        enemies.Add(new Teleporter(player, teleporterPosition));
                    }
                }

                // DEFENCE STATIONS is placed near two of the planets
                if (count == 3)
                {
                    Vector2 stationPosition = new Vector2(
                        planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f),
                        planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f)
                    );
                    enemies.Add(new DefenceStation(player, stationPosition));
                }

                if (count == NUMBER_OF_PLANETS - 1)
                {
                    Vector2 stationPosition = new Vector2(
                        planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f),
                        planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f)
                    );
                    enemies.Add(new DefenceStation(player, stationPosition));
                }
            }


            // Creating BACKGROUND STARS

            for (int index = 0; index < NUMBER_OF_BG_STARS; index++)
            {
                Star star = createStar(bgStar);

                if (bgStar)
                {
                    // Faint stars
                    bgStars.Add(star);
                    bgStar = false;
                }
                else
                {
                    // Near stars
                    bgStarsLayer2.Add(star);
                    bgStar = true;
                }
            }

            // Creating ASTEROIDS of various types. Big more seldom than small
            asteroids = createAsteroids(NUMBER_OF_ASTEROIDS);
        }

        /// <summary>
        /// GET METHODS
        /// </summary>
        /// <returns></returns>
        public override System.Collections.Generic.List<Star> getBgStars() { return bgStars; }
        public override System.Collections.Generic.List<Star> getBgStarsLayer2() { return bgStarsLayer2; }
        public override System.Collections.Generic.List<Planet> getPlanets() { return planets; }
        public override System.Collections.Generic.List<Asteroid> getAsteroids() { return asteroids; }
        public override System.Collections.Generic.List<EnemyTemplate> getEnemies() { return enemies; }
        public override System.Collections.Generic.List<BeamModel> getEnemyBeams() { return enemyBeams; }
    }
}
