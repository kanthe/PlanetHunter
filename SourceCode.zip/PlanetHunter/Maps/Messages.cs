﻿/*******************************************************************************************************/
// File:    Messages.cs
// Summary: Loading images, containing all messeges, which will be shown in the game
// Has a method which draws any messag.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{

    class Messages
    {
        float messageTime = 3.0f; // The time the messge is shown
        Timer messageTimer; // Counts down message time
        bool pauseForMessage = false; // Used by GameController to pause during message time
        // All needed textures;
        Texture2D messageTexture;
        Texture2D openingTexture; 
        Texture2D gameOverTexture;
        Texture2D landingSuccessfulTexture;
        Texture2D mapL1StartTexture;
        Texture2D mapL2StartTexture;
        Texture2D mapL3StartTexture;
        Texture2D mapL4StartTexture;
        Texture2D mapL5StartTexture;
        Texture2D mapL6StartTexture;
        Texture2D mapL7StartTexture;
        Texture2D mapL8StartTexture;
        Texture2D mapL9StartTexture;
        Texture2D mapL10StartTexture;
        Texture2D levelCompleteTexture;
        Texture2D firstLandingTexture;
        Texture2D asteroidWarningTexture;
        Texture2D mapL1DefenceStationTexture;
        Texture2D hpRestoreTexture;
        Texture2D beamEnhanceTexture;
        Texture2D autoFireTexture;
        Texture2D missileTexture;
        Texture2D shieldTexture;
        Texture2D shieldRestoreTexture;
        Texture2D furyTexture;
        Texture2D furyEnhanceTexture;
        Texture2D finishTexture;

        public Messages(ContentManager content)
        {
            messageTimer = new Timer(messageTime);
            // Loading all needed textures
            openingTexture = content.Load<Texture2D>("message_opening");
            gameOverTexture = content.Load<Texture2D>("message_gameOver");
            landingSuccessfulTexture = content.Load<Texture2D>("message_landing_successful");
            mapL1StartTexture = content.Load<Texture2D>("message_level_1");
            mapL2StartTexture = content.Load<Texture2D>("message_level_2");
            mapL3StartTexture = content.Load<Texture2D>("message_level_3");
            mapL4StartTexture = content.Load<Texture2D>("message_level_4");
            mapL5StartTexture = content.Load<Texture2D>("message_level_5");
            mapL6StartTexture = content.Load<Texture2D>("message_level_6");
            mapL7StartTexture = content.Load<Texture2D>("message_level_7");
            mapL8StartTexture = content.Load<Texture2D>("message_level_8");
            mapL9StartTexture = content.Load<Texture2D>("message_level_9");
            mapL10StartTexture = content.Load<Texture2D>("message_level_10");
            levelCompleteTexture = content.Load<Texture2D>("message_level_done");
            firstLandingTexture = content.Load<Texture2D>("message_first_landing");
            asteroidWarningTexture = content.Load<Texture2D>("message_mapL1Asteroids");
            mapL1DefenceStationTexture = content.Load<Texture2D>("message_space_station");
            hpRestoreTexture = content.Load<Texture2D>("message_hp_restore");
            beamEnhanceTexture = content.Load<Texture2D>("message_beam_enhance");
            autoFireTexture = content.Load<Texture2D>("message_autoFire");
            missileTexture = content.Load<Texture2D>("message_missile");
            shieldTexture = content.Load<Texture2D>("message_shield");
            shieldRestoreTexture = content.Load<Texture2D>("message_shield_restore");
            furyTexture = content.Load<Texture2D>("message_fury");
            furyEnhanceTexture = content.Load<Texture2D>("message_fury_enhance");
            finishTexture = content.Load<Texture2D>("message_finish");
        }

        // GET METHODS

        public float getMessageTime() { return messageTime; }
        public bool getPauseForMessage() { return pauseForMessage; }

        // SET METHODS

        public void setMessageTimer(float messageTime) { messageTimer.setTimer(messageTime); }

        // DRAWS a message

        public bool show(Vector2 position, Message message, SpriteBatch spriteBatch, float deltaTime)
        {
            pauseForMessage = false;
            // Choosing message, called in the method
            switch (message) 
            {
                case Message.Opening:
                    messageTexture = openingTexture;
                    messageTime = 5.0f;
                    break;
                case Message.GameOver:
                    messageTexture = gameOverTexture;
                    messageTime = 2.0f;
                    break;
                case Message.LandingSuccessful:
                    messageTexture = landingSuccessfulTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL1Start:
                    messageTexture = mapL1StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL2Start:
                    messageTexture = mapL2StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL3Start:
                    messageTexture = mapL3StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL4Start:
                    messageTexture = mapL4StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL5Start:
                    messageTexture = mapL5StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL6Start:
                    messageTexture = mapL6StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL7Start:
                    messageTexture = mapL7StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL8Start:
                    messageTexture = mapL8StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL9Start:
                    messageTexture = mapL9StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL10Start:
                    messageTexture = mapL10StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.LevelComplete:
                    messageTexture = levelCompleteTexture;
                    messageTime = 2.0f;
                    break;
                case Message.FirstPlanetVisit:
                    messageTexture = firstLandingTexture;
                    messageTime = 5.0f;
                    break;
                case Message.AsteroidWarning:
                    messageTexture = asteroidWarningTexture;
                    messageTime = 2.0f;
                    break;
                case Message.DefenceStationWarning:
                    messageTexture = mapL1DefenceStationTexture;
                    messageTime = 5.0f;
                    break;
                case Message.HpRestore:
                    messageTexture = hpRestoreTexture;
                    messageTime = 5.0f;
                    break;
                case Message.BeamEnhance:
                    messageTexture = beamEnhanceTexture;
                    messageTime = 5.0f;
                    break;
                case Message.AutoFire:
                    messageTexture = autoFireTexture;
                    messageTime = 5.0f;
                    break;
                case Message.Missile:
                    messageTexture = missileTexture;
                    messageTime = 5.0f;
                    break;
                case Message.Shield:
                    messageTexture = shieldTexture;
                    messageTime = 5.0f;
                    break;
                case Message.ShieldRestore:
                    messageTexture = shieldRestoreTexture;
                    messageTime = 5.0f;
                    break;
                case Message.Fury:
                    messageTexture = furyTexture;
                    messageTime = 5.0f;
                    break;
                case Message.FuryEnhance:
                    messageTexture = furyEnhanceTexture;
                    messageTime = 5.0f;
                    break;
                case Message.Finished:
                    messageTexture = finishTexture;
                    messageTime = 30.0f;
                    position.Y -= messageTexture.Bounds.Height / 2;
                    break;
            }

            if (message != Message.None)
            {
                messageTimer.setTimer(messageTime);
                pauseForMessage = true;
                // Centering message
                position = position - new Vector2(messageTexture.Bounds.Width / 2, messageTexture.Bounds.Height / 2);

                if (!messageTimer.runTimer(deltaTime))
                {
                    spriteBatch.Draw(messageTexture, position, Color.White);
                    return false;
                }
                else
                {
                    messageTimer.resetTimer();
                }
            }
            return true;
        }
    }
}
