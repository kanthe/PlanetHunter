﻿/*******************************************************************************************************/
// File:    Border.cs
// Summary: Creating and drawing a border in a square
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Model;

namespace View
{
    /// <summary>
    /// Creating and drawing a border in a square
    /// </summary>
    class Border
    {
        float borderRadius; // Distance center to border 
        public static readonly int thickness = 5;
        public static readonly Color color = Color.Red;
        Texture2D borderTexture;
        Camera camera;
        
        public Border(GraphicsDevice device, float borderRadius)
        {
            this.borderRadius = borderRadius;
            camera = GameView.camera;
            // Making texture for the frame
            borderTexture = new Texture2D(device, 1, 1);
            borderTexture.SetData(new[] { color });
        }
        /// <summary>
        /// Draws the border
        /// </summary>
        /// <param name="scale">One model unit (square width)</param>
        public void DrawBorder(int scale, SpriteBatch spriteBatch)
        {
            float visualBorderRadius = camera.scaleObject(borderRadius);
            Vector2 viewOrigoPosition = camera.modelPositionToViewPosition(new Vector2(0, 0));
            int numberOfCircleParts = (int)(Geometry.PI * borderRadius * scale / 10);
            float angle = 2 * (float)Geometry.PI / numberOfCircleParts; // Angle between each red border mark
            // Draws border, one by one mark
            for (int count = 0; count < numberOfCircleParts; count++)
            {
                spriteBatch.Draw(borderTexture,
                    new Rectangle(
                        (int)(viewOrigoPosition.X - visualBorderRadius + visualBorderRadius * (1.0f + (float)System.Math.Cos(angle * count))),
                        (int)(viewOrigoPosition.Y + visualBorderRadius - visualBorderRadius * (1.0f + (float)System.Math.Sin(angle * count))), 
                        thickness, 
                        thickness
                        ),
                    color
                    );
            }
        }
    }
}
