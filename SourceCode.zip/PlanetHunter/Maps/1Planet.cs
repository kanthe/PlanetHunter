﻿using Microsoft.Xna.Framework;

namespace Model
{
    public enum PlanetPower { None, AutoFire, Missile}
    public enum PlanetTexture { Dark, Green, Jupiter_like, Methane, Neptune_like, Ocean, Pink, BlueRed, Red, Yellow, Yellow_Green }
    public enum PlanetState { PlayerAwayFromPlanet, PlayerOverPlanet, PlayerLanding, Visited, Dead }

    class Planet
    {
        Vector2 position;
        float diameter;
        PlanetPower power;
        PlanetTexture planetTexture;
        PlanetState planetState = PlanetState.PlayerAwayFromPlanet;

        public Planet(Vector2 position, float radius, bool islandable, PlanetPower power, PlanetTexture planetTexture)
        {
            this.position = position;
            this.diameter = radius;
            this.power = power;
            this.planetTexture = planetTexture;

            if (islandable)
            {
                planetState = PlanetState.PlayerAwayFromPlanet;
            }
            else
            {
                planetState = PlanetState.Dead;
            }
        }

        // GET METHODS

        public Vector2 getPosition() { return position; }
        public float getDiameter() { return diameter; }
        public PlanetPower getPower() { return power; }
        public PlanetTexture getPlanetTexture() { return planetTexture; }
        public PlanetState getPlanetState() { return planetState; }

        // SET METHODS

        public void setPlanetState(PlanetState planetState) { this.planetState = planetState; }
    }

}
