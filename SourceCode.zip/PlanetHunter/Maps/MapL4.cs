﻿/*******************************************************************************************************/
// File:    MapL4.cs
// Summary: Creates map for level 4 and its elements: Enemies, planets, 
// Version: Version 1.0 - 2016-06-14
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-06-14 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class MapL4 : MapTemplate
    {
        public static readonly int NUMBER_OF_BG_STARS = 800;
        public static readonly int NUMBER_OF_PLANETS = 8;
        public static readonly int NUMBER_OF_ASTEROIDS = 150;
        public static readonly int NUMBER_OF_CLASS2_ENEMIES = 15;
        public static readonly int NUMBER_OF_TRACTORS = 8;
        public static readonly int NUMBER_OF_ENEMIES_PER_PLANET = 2;
        // List of background stars, planets, asteroids and enemies
        System.Collections.Generic.List<Star> bgStars;
        System.Collections.Generic.List<Star> bgStarsLayer2;
        System.Collections.Generic.List<Planet> planets;
        System.Collections.Generic.List<Asteroid> asteroids;
        System.Collections.Generic.List<EnemyTemplate> enemies;
        System.Collections.Generic.List<BeamModel> enemyBeams = new System.Collections.Generic.List<BeamModel>();

        public MapL4(Player player)
        {
            bgStars = new System.Collections.Generic.List<Star>();
            bgStarsLayer2 = new System.Collections.Generic.List<Star>();
            planets = new System.Collections.Generic.List<Planet>();
            asteroids = new System.Collections.Generic.List<Asteroid>();
            enemies = new System.Collections.Generic.List<EnemyTemplate>();
            borderRadius = 2.0f; // Radius of the area the player is allowed to be in the map.
            musicTitle = "Music3"; // Music

            // PLANETS

            Vector2[] planetModelPositions = new Vector2[]
            {
                new Vector2(-0.2f, -1.5f),   // more_cracks
                new Vector2(0.9f, -1.0f),     // uranus_like
                new Vector2(0.7f, -0.9f),     // grey
                new Vector2(-1.5f, -0.2f),   // neptune_like
                new Vector2(-1.5f, 0),   // yellow_red
                new Vector2(-1.0f, -1.0f),    // Red
                new Vector2(-0.8f, 1.0f),     // Dark
                new Vector2(1.5f, 1.0f)    // Yellow
            };

            float[] planetModelRadius = new float[]
            {
                0.1f, 0.25f, 0.07f, 0.3f, 0.1f, 0.05f, 0.12f, 0.2f
            };

            // Ability obtained when visiting the planet
            PlanetPower[] planetPower = new PlanetPower[]
            {
                PlanetPower.Shield, PlanetPower.None, PlanetPower.None, PlanetPower.None, PlanetPower.HpRestore, PlanetPower.None, PlanetPower.None, PlanetPower.HpRestore
            };

            LandingStatus[] landingStatus = new LandingStatus[] 
            {
                LandingStatus.Landable, LandingStatus.NotLandable, LandingStatus.Landable, LandingStatus.NotLandable,
                LandingStatus.Landable, LandingStatus.Landable, LandingStatus.Landable, LandingStatus.Landable
            };

            PlanetTexture[] planetTextures = new PlanetTexture[]
            {
                PlanetTexture.MoreCracks, PlanetTexture.UranusLike, PlanetTexture.Grey, PlanetTexture.NeptuneLike, PlanetTexture.YellowRed, PlanetTexture.Red, PlanetTexture.Dark, PlanetTexture.Yellow
            };

            // Setting players weapons/abilities for the map
            Player.BEAM_WEAPON.setBeamDamage(15);
            Player.BEAM_WEAPON.setBeamColor(Color.Orange);
            Player.BEAM_WEAPON.setAutoFireState(AutoFireState.NotLoaded);
            Player.MISSILE_WEAPON.setMissileState(MissileState.NotLoaded);
            Player.SHIELD.setShieldState(ShieldState.OffPlayer);
            Player.SHIELD.setHitPoints(Player.SHIELD.STARTING_HITPOINTS);
            Player.FURY_MODE.setFuryState(FuryState.OffPlayer);
            Player.FURY_MODE.setFuryLoadTime(5.0f);
            Player.FURY_MODE.setFuryLoadTimer();

            // CLASS 2 ENEMIES and LURKERS is spread randomly on the map, excluding area near the player (centre of map, avoiding enemy to spawn on player)

            for (int index = 0; index < NUMBER_OF_CLASS2_ENEMIES; index++)
            {
                Vector2 position = borderRadius * (float)Geometry.rand.NextDouble() * Geometry.PlaceRandomInCircle();

                if (System.Math.Abs(position.X) > borderRadius / 5 && System.Math.Abs(position.Y) > borderRadius / 5)
                {
                    enemies.Add(new Class2Enemy(player, position));
                }
                else
                {
                    index--; // Enemy will get new coordinates if they were too near centre of map
                }
            }

            // TRACTOR ENEMIES is spread randomly on the map, excluding area near the player (centre of map, avoiding eney to spawn on player)

            for (int index = 0; index < NUMBER_OF_TRACTORS; index++)
            {
                Vector2 position = borderRadius * (float)Geometry.rand.NextDouble() * Geometry.PlaceRandomInCircle();

                if (System.Math.Abs(position.X) > borderRadius / 5 && System.Math.Abs(position.Y) > borderRadius / 5)
                {
                    enemies.Add(new Tractor(player, position));
                }
                else
                {
                    index--; // Enemy will get new coordinates if they were too near centre of map
                }
            }

            // POSITIONING PLANETS AND PLANET ENEMIES ON MAP

            for (int count = 0; count < NUMBER_OF_PLANETS; count++)
            {
                // PLANETS

                planets.Add(new Planet(planetModelPositions[count], planetModelRadius[count], planetPower[count], landingStatus[count], planetTextures[count]));
                
                // LURKERS near all planets
                for (int i = 0; i < 4; i++)
                {
                    Vector2 lurkerPosition = new Vector2(
                        planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f),
                        planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f)
                    );
                    enemies.Add(new Lurker(player, lurkerPosition));
                }
                // DEFENCE STATION is placed near the next nearest planet
                if (count == 3)
                {
                    Vector2 stationPosition = new Vector2(
                        planetModelPositions[count].X + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f),
                        planetModelPositions[count].Y + 0.2f * (float)(Geometry.rand.NextDouble() - 1.0f)
                    );
                    enemies.Add(new DefenceStation(player, stationPosition));
                }
                
            }

            // Creating BACKGROUND STARS

            for (int index = 0; index < NUMBER_OF_BG_STARS; index++)
            {
                Star star = createStar(bgStar);

                if (bgStar)
                {
                    // Faint stars
                    bgStars.Add(star);
                    bgStar = false;
                }
                else
                {
                    // Near stars
                    bgStarsLayer2.Add(star);
                    bgStar = true;
                }
            }

            asteroids = createAsteroids(NUMBER_OF_ASTEROIDS);
        }

        /// <summary>
        /// GET METHODS
        /// </summary>
        /// <returns></returns>
        public override System.Collections.Generic.List<Star> getBgStars() { return bgStars; }
        public override System.Collections.Generic.List<Star> getBgStarsLayer2() { return bgStarsLayer2; }
        public override System.Collections.Generic.List<Planet> getPlanets() { return planets; }
        public override System.Collections.Generic.List<Asteroid> getAsteroids() { return asteroids; }
        public override System.Collections.Generic.List<EnemyTemplate> getEnemies() { return enemies; }
        public override System.Collections.Generic.List<BeamModel> getEnemyBeams() { return enemyBeams; }
    }
}
