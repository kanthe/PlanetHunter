﻿/*******************************************************************************************************/
// File:    GameSimulation.cs
// Summary: Creates the player and maps and thus setting up initial condition of the game. Also reseting
// initial conditions when restarting game and keep track of current level.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    public enum TutorialState { True, False }
    public enum GameState { StartMode, Menu, Controls, Credits, NewGame, Continue, Reset, Exit } // All different states of the game
    // Every message gets its own enum Message value
    public enum Message
    {
        None,
        Opening,
        MapL1Start,
        MapL2Start,
        MapL3Start,
        MapL4Start,
        MapL5Start,
        MapL6Start,
        MapL7Start,
        MapL8Start,
        MapL9Start,
        MapL10Start,
        LevelComplete,
        GameOver,
        FirstPlanetVisit,
        AsteroidWarning,
        DefenceStationWarning,
        LandingSuccessful,
        HpRestore,
        BeamEnhance,
        AutoFire,
        Missile,
        Shield,
        ShieldRestore,
        Fury,
        FuryEnhance,
        Finished
    }
    
    /// <summary>
    /// Creating the main object models, which are visual in the game, map and player. 
    /// Map creates Enemies, planets asteroids...
    /// </summary>
    class GameSimulation
    {
        TutorialState tutorialState = TutorialState.False; // Determines if a lot of messeges will be show in game or not
        GameState gameState; // State of the game
        Message message = Message.None; // Class containing all messages shown in the game
        // Keeping track of messages so they are not shown many times (if they should'n do that)
        bool[] hasShownMessage = new bool[] { 
            false, false, false, false, false, 
            false, false, false, false, false, 
            false, false, false, false, false, 
            false, false, false, false, false, 
            false, false, false, false, false, 
            false, false};
        public int level;
        int numberOfVisitedPlanets = 0; // Counting visited planets. At a certain amount, players should go to another level
        Player player; // The model representation of the player.
        MapTemplate map; // The model representation of the map.
        int totalNumberOfPlanets = 0;

        public GameSimulation() {
            // Initial conditions
            level = 1;
            player = new Player(new Vector2(0.01f, 0.01f)); // The player
            map = new MapL1(player); // The Map (initially first level)

            foreach (Planet planet in map.getPlanets())
            {
                if (planet.getLandingStatus() == LandingStatus.Landable)
                {
                    totalNumberOfPlanets++;
                }
            }
        }

        // GET METHODS

        public TutorialState getTutorialState() { return tutorialState; }
        public GameState getGameState() { return gameState; }
        public Message getMessage() { return message; }
        public bool[] getHasShownMessage() { return hasShownMessage; }
        public int getLevel() { return level; }
        public int getNumberOfVisitedPlanets() { return numberOfVisitedPlanets; }
        public Player getPlayer() { return player; }
        public MapTemplate getMap() { return map; }
        public int getTotalNumberOfPlanets() { return totalNumberOfPlanets; }

        // SET METHODS

        public void setTutorialState(TutorialState tutorialState) { this.tutorialState = tutorialState; }
        public void setGameState(GameState gameState) { this.gameState = gameState; }
        public void setMessage(Message message) { this.message = message; }
        public void setHasShownMessage(Message message, bool HasShownMessage) { hasShownMessage[(int)message] = HasShownMessage; }
        public void setNumberOfVisitedPlanets(int numberOfVisitedPlanets) { this.numberOfVisitedPlanets = numberOfVisitedPlanets; }
        public void setLevel(int level) { this.level = level; }

        // ADVANCE LEVEL

        public void advanceLevel()
        {
            if (hasShownMessage[(int)Message.LevelComplete] || hasShownMessage[(int)Message.Finished])
            {
                level++;
                gameState = GameState.Reset;
            }
        }

        public void skipLevel() // (Triggered by key)
        {
            level++;
            gameState = GameState.Reset;
        }

        public void reverseLevel() // (Triggered by key)
        {
            level--;
            gameState = GameState.Reset;
        }

        public void restartLevel()
        {
            if (hasShownMessage[(int)Message.GameOver])
            {
                gameState = GameState.Reset;
            }
        }
        /// <summary>
        /// Sets game back to initial conditions (except possibly a new level)
        /// </summary>
        public void reset()
        {
            gameState = GameState.Continue;
            message = Message.None;
            hasShownMessage[(int)Message.Opening] = false;
            hasShownMessage[(int)Message.AsteroidWarning] = false;
            hasShownMessage[(int)Message.DefenceStationWarning] = false;
            hasShownMessage[(int)Message.FirstPlanetVisit] = false;
            // So that the level introduction in the beginning is showing again
            hasShownMessage[(int)Message.MapL1Start] = false;
            hasShownMessage[(int)Message.MapL2Start] = false;
            hasShownMessage[(int)Message.MapL3Start] = false;
            hasShownMessage[(int)Message.MapL4Start] = false;
            hasShownMessage[(int)Message.MapL5Start] = false;
            hasShownMessage[(int)Message.MapL6Start] = false;
            hasShownMessage[(int)Message.MapL7Start] = false;
            hasShownMessage[(int)Message.MapL8Start] = false;
            hasShownMessage[(int)Message.MapL9Start] = false;
            hasShownMessage[(int)Message.MapL10Start] = false;
            hasShownMessage[(int)Message.LevelComplete] = false;
            hasShownMessage[(int)Message.GameOver] = false;

            player = new Player(new Vector2(0.01f, 0.01f));

            switch (level)
            {
                case 1:
                    map = new MapL1(player);
                    break;
                case 2:
                    map = new MapL2(player);
                    break;
                case 3:
                    map = new MapL3(player);
                    break;
                case 4:
                    map = new MapL4(player);
                    break;
                case 5:
                    map = new MapL5(player);
                    break;
                case 6:
                    map = new MapL6(player);
                    break;
                case 7:
                    map = new MapL7(player);
                    break;
                case 8:
                    map = new MapL8(player);
                    break;
                case 9:
                    map = new MapL9(player);
                    break;
                case 10:
                    map = new MapL10(player);
                    break;
                case 11:
                    level = 1;
                    map = new MapL1(player);
                    break;
            }
            numberOfVisitedPlanets = 0;
            totalNumberOfPlanets = 0;

            foreach (Planet planet in map.getPlanets())
            {
                if (planet.getLandingStatus() == LandingStatus.Landable)
                {
                    totalNumberOfPlanets++;
                }
            }

        }
    }
}
