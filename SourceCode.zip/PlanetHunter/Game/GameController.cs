﻿/*******************************************************************************************************/
// File:    GameController.cs
// Summary: GameController is the "motor" of the game. When updated from MasterController it controls 
// the movement and actions of player and enemies. AAlso controlls when messages and shown and all 
// actions in game, triggered by the keyboard.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using View;
using Model;

namespace Controller
{
    /// <summary>
    /// Handles input from player and updates game.
    /// </summary>
    class GameController
    {
        public static bool messageDisplayed = false;
        GameSimulation gameSimulation; // Model representation of the game
        EventListener eventListener;  // Drawing things and/or playing sounds in respons to events
        Messages messages; // Containing all messages shown in the game
        // Activates the levels at one key stroke
        Activator activator = new Activator(0); // Activates responses to keys pressed
        Activator shieldActivator = new Activator(0);
        Activator furyActivator = new Activator(0);
        Activator skipLevelActivator = new Activator(0);
        Activator reverseLevelActivator = new Activator(0);
        Activator gasActivator = new Activator(0);
        Activator landingActivator = new Activator(0);

        public GameController(GameSimulation gameSimulation, EventListener eventListener, Messages messages)
        {
            this.messages = messages;
            gameSimulation.setGameState(GameState.Continue);
            this.gameSimulation = gameSimulation;
            this.eventListener = eventListener;
        }
        /// <summary>
        /// Updates the players AND enemies movement and actions.
        /// </summary>
        /// <param name="gameTime">GameTime object containing total time of game, time since last update, etc.</param>
        /// 
        
        public void Update(GameTime gameTime)
        {
            // Get the current gamepad state.
            GamePadState currentState = GamePad.GetState(PlayerIndex.One);
            // The gametime step in seconds
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // Esc: Go to MENU

            bool escapeButtonPressed = Keyboard.GetState().IsKeyDown(Keys.Escape) || currentState.IsConnected && currentState.Buttons.Back == ButtonState.Pressed;

            if (escapeButtonPressed)
            {
                gameSimulation.setGameState(GameState.Menu);
            }

            // Space: PAUSE

            bool pauseButtonPressed = Keyboard.GetState().IsKeyDown(Keys.Space) || currentState.IsConnected && currentState.Buttons.Start == ButtonState.Pressed;
            bool pause = activator.activateDeactivateOnRelease(pauseButtonPressed);

            // Makes all the updates if pause is not activated or if the message object do not give pause intructions when playing a message
            if (!pause && !messages.getPauseForMessage()) 
            {
                /*
                 ********************************************************************************
                 * CONTROLS PLAYER                                                             *
                 ********************************************************************************
                 */
                Player player = gameSimulation.getPlayer();

                // MOVE player in current speed and direction using the Movement class
                Vector2 position = player.getMovement().move(player.getPosition(), player.getSpeed(), player.getDirection(), gameSimulation.getMap().getBorderRadius(), deltaTime);
                player.setPosition(position);

                // BACKGROUND STARS movement
                // using slower speeds to create an illusion of depth

                System.Collections.Generic.List<Star> bgStars = gameSimulation.getMap().getBgStars();
                System.Collections.Generic.List<Star> bgStarsLayer2 = gameSimulation.getMap().getBgStarsLayer2();

                foreach (Star star in bgStars) 
                {
                    Vector2 starPosition = star.getPosition();
                    starPosition = star.getMovement().move(starPosition, player.getSpeed() / 2, player.getDirection(), 1000.0f, deltaTime);
                    star.setPosition(starPosition);
                }
                foreach (Star star in bgStarsLayer2)
                {
                    Vector2 starPosition = star.getPosition();
                    starPosition = star.getMovement().move(starPosition, player.getSpeed() / 3, player.getDirection(), 1000.0f, deltaTime);
                    star.setPosition(starPosition);
                }

                //
                // GAS (accelerate)
                //
                bool gasButtonPressed = Keyboard.GetState().IsKeyDown(Keys.Up) || currentState.IsConnected && currentState.Triggers.Right > 0.2f;
                if (gasButtonPressed)
                {
                    float speed = player.getMovement().gas(player.getSpeed(), deltaTime);
                    player.setSpeed(speed);
                    player.setDirection(Geometry.AngleToDirection(player.getAngle()));
                    // Exposions makes illusion of rocket exhause
                    eventListener.MakeExplosion(player.getPosition() - player.getDirection() * Player.DIAMETER / 2, gameTime, 0.2f, 10.0f, 10.0f, 50.0f, 0.1f, 3.0f);
                }
                if(gasActivator.activeOneTimeStep(gasButtonPressed))
                {
                    eventListener.playPlayerGasSound();
                }
                //
                // BREAK (decelerate)
                //
                if (Keyboard.GetState().IsKeyDown(Keys.Down) || currentState.IsConnected && currentState.Triggers.Left > 0.2f)
                {
                    float speed = player.getMovement().break_(player.getSpeed(), deltaTime);
                    player.setSpeed(speed);
                }
                //
                // Turn LEFT
                //
                if (Keyboard.GetState().IsKeyDown(Keys.Left) || currentState.IsConnected && currentState.ThumbSticks.Left.X < -0.8f)
                {
                    float angle = player.getMovement().turnLeft(player.getAngle(), deltaTime);
                    player.setAngle(angle);
                }
                else if (Keyboard.GetState().IsKeyDown(Keys.Left) || currentState.IsConnected && currentState.ThumbSticks.Left.X < -0.2f)
                {
                    player.getMovement().setRotationSpeed(Player.ROTATION_SPEED / 4);
                    float angle = player.getMovement().turnLeft(player.getAngle(), deltaTime);
                    player.setAngle(angle);
                    player.getMovement().setRotationSpeed(Player.ROTATION_SPEED);
                }
                //
                // Turn RIGHT
                //
                if (Keyboard.GetState().IsKeyDown(Keys.Right) || currentState.IsConnected && currentState.ThumbSticks.Left.X > 0.8f)
                {
                    float angle = player.getMovement().turnRight(player.getAngle(), deltaTime);
                    player.setAngle(angle);
                }
                else if (Keyboard.GetState().IsKeyDown(Keys.Right) || currentState.IsConnected && currentState.ThumbSticks.Left.X > 0.2f)
                {
                    player.getMovement().setRotationSpeed(Player.ROTATION_SPEED / 4);
                    float angle = player.getMovement().turnRight(player.getAngle(), deltaTime);
                    player.setAngle(angle);
                    player.getMovement().setRotationSpeed(Player.ROTATION_SPEED);
                }

                /*
                 ********************************************************************************
                 * WEAPONS / ABILITIES                                                          *
                 ********************************************************************************
                 */
                //
                // Shoot BEAM
                //
                // True if player presses the fire button. That does not mean a beam is fired, since 
                // beam is only fired once when pressing the fire button, not one every time step, "deltaTime".
                bool fireButtonPressed = Keyboard.GetState().IsKeyDown(Keys.Q) || currentState.IsConnected && currentState.Buttons.A == ButtonState.Pressed;
                bool playerShootBeams = player.shootBeams(fireButtonPressed, deltaTime);
                // Beam sound
                if (playerShootBeams)
                {
                    eventListener.playPlayerBeamSound();
                }

                // Moving PLAYERS BEAMS. All beams are stored in the BeamWeapon object until deleted (at window boundaries, if it hits an enemy
                // or outside map boundary.

                for (int index = Player.BEAM_WEAPON.getBeams().Count - 1; index >= 0; index--)
                {
                    BeamModel beam = Player.BEAM_WEAPON.getBeams()[index];

                    if (Geometry.AbsoluteValue(beam.getPosition()) > gameSimulation.getMap().getBorderRadius() * 1.1f)
                    {
                        Player.BEAM_WEAPON.getBeams().RemoveAt(index);
                    }
                    Vector2 beamPosition = player.getMovement().move(beam.getPosition(), beam.getSpeed(), beam.getDirection(), gameSimulation.getMap().getBorderRadius() * 1.11f, deltaTime);
                    beam.setPosition(beamPosition);

                    // ENEMY IS HIT by players beam. 

                    for (int count = gameSimulation.getMap().getEnemies().Count - 1; count >= 0; count--)
                    {
                        EnemyTemplate enemy = gameSimulation.getMap().getEnemies()[count];

                        if (Geometry.IsInsideCircle(beam.getPosition(), 0, enemy.getPosition(), enemy.getDiameter()))
                        {
                            enemy.isHit(beam.getBeamDamage());
                            Player.BEAM_WEAPON.getBeams().Remove(beam);
                        }
                    }
                }

                // LAUNCH MISSILE

                bool missileButtonPressed = Keyboard.GetState().IsKeyDown(Keys.W) || currentState.IsConnected && currentState.Buttons.B == ButtonState.Pressed;
                bool playerLaunchMissile = false;

                if (Player.MISSILE_WEAPON.getMissileState() != MissileState.OffPlayer)
                {
                    playerLaunchMissile = player.launchMissile(missileButtonPressed, deltaTime);
                }
                // Missile sound
                if (playerLaunchMissile)
                {
                    eventListener.playMissileSound();
                }


                // Moving PLAYERS MISSILES. All beams are stored in the BeamWeapon object until deleted (at window boundaries or if it hits an enemy)

                for (int index = Player.MISSILE_WEAPON.getMissiles().Count - 1; index >= 0; index--)
                {
                    MissileModel missile = Player.MISSILE_WEAPON.getMissiles()[index];
                    if (Geometry.AbsoluteValue(missile.getPosition()) > gameSimulation.getMap().getBorderRadius() * 1.1f)
                    {
                        Player.MISSILE_WEAPON.getMissiles().RemoveAt(index);
                    }
                    Vector2 missilePosition = player.getMovement().move(missile.getPosition(), Player.MISSILE_WEAPON.getSpeed(), missile.getDirection(), gameSimulation.getMap().getBorderRadius() * 1.1f, deltaTime);
                    missile.setPosition(missilePosition);

                    // ENEMY IS HIT by players missile. 

                    for (int count = gameSimulation.getMap().getEnemies().Count - 1; count >= 0; count--)
                    {
                        EnemyTemplate enemy = gameSimulation.getMap().getEnemies()[count];

                        if (Geometry.IsInsideCircle(missile.getPosition(), 0, enemy.getPosition(), enemy.getDiameter()))
                        {
                            enemy.isHit(Player.MISSILE_WEAPON.getDamage());
                            Player.MISSILE_WEAPON.getMissiles().Remove(missile);
                        }
                    }
                }

                // SHIELD
                
                // shield.countDownShield(deltaTime);
                bool shieldButtonPressed = Keyboard.GetState().IsKeyDown(Keys.E) || currentState.IsConnected && currentState.Buttons.X == ButtonState.Pressed;
                bool playerPowerShield = Player.SHIELD.powerShield(shieldButtonPressed, deltaTime);

                // Shield sound
                if (shieldActivator.activeOneTimeStep(shieldButtonPressed) && Player.SHIELD.getShieldState() == ShieldState.Powered)
                {
                    eventListener.playShieldSound();
                }

                if (Player.SHIELD.getShieldState() == ShieldState.Powered)
                {
                    if (Player.SHIELD.getHitPoints() <= 0)
                    {
                        Player.SHIELD.setShieldState(ShieldState.OffPlayer);
                        // Player.SHIELD.resetCountDown();
                    }
                    eventListener.AnimateShield();
                }

                // FURY MODE

                bool furyButtonPressed = Keyboard.GetState().IsKeyDown(Keys.F) || currentState.IsConnected && currentState.Buttons.Y == ButtonState.Pressed;
                // Fury sound
                if (furyActivator.activeOneTimeStep(furyButtonPressed) && Player.FURY_MODE.getFuryState() == FuryState.Loaded)
                {
                    eventListener.playFurySound();
                }
                bool playerPowerFuryMode = Player.FURY_MODE.powerFuryMode(furyButtonPressed, deltaTime);

                
                if (Player.FURY_MODE.getFuryState() == FuryState.Active)
                {
                    Player.MISSILE_WEAPON.setMissileLoadTime(2.0f);
                    Player.BEAM_WEAPON.setAutoFireLoadTime(1.5f);
                    Player.COLOR = Color.Red;
                }
                else
                {
                    Player.MISSILE_WEAPON.setMissileLoadTime(5.0f);
                    Player.BEAM_WEAPON.setAutoFireLoadTime(3.0f);
                    Player.COLOR = Color.White;
                }


                // LAND ON PLANET

                System.Collections.Generic.List<Planet> planets = gameSimulation.getMap().getPlanets(); // All planets on map
                bool landButtonPressed = Keyboard.GetState().IsKeyDown(Keys.A) || currentState.IsConnected && currentState.Buttons.LeftStick == ButtonState.Pressed;

                foreach (Planet planet in planets)
                {
                    if (    // Showing MESSAGE when player is near the first landable planet, only one time, if tutorial mode is on 
                        gameSimulation.getTutorialState() == TutorialState.True && 
                        !gameSimulation.getHasShownMessage()[(int)Message.FirstPlanetVisit] &&
                        Geometry.IsInsideCircle(player.getPosition(), 0, planet.getPosition(), planet.getDiameter()) &&
                        gameSimulation.getLevel() == 1)
                    {
                        gameSimulation.setMessage(Message.FirstPlanetVisit);
                    }
                    bool isLanding = (planet.getLandingStatus() == LandingStatus.PlayerIsLanding);

                    if(landingActivator.activeOneTimeStep(isLanding))
                    {
                        eventListener.playPlayerLandingSound();
                    }
                    // landOnPlanet returns true if landing is successful.
                    // Message is played and message and eventual ability or weapon is triggered
                    if (player.landOnPlanet(planet, landButtonPressed, deltaTime))
                    {
                        eventListener.stopPlayerLandingSound();
                        eventListener.playMessageSound();
                        gameSimulation.setMessage(Message.LandingSuccessful);
                        gameSimulation.setNumberOfVisitedPlanets(gameSimulation.getNumberOfVisitedPlanets() + 1);

                        switch (planet.getPower())
                        {
                            case PlanetPower.HpRestore:
                                gameSimulation.setMessage(Message.HpRestore);
                                break;
                            case PlanetPower.BeamEnhance:
                                gameSimulation.setMessage(Message.BeamEnhance);
                                break;
                            case PlanetPower.AutoFire:
                                gameSimulation.setMessage(Message.AutoFire);
                                break;
                            case PlanetPower.Missile:
                                gameSimulation.setMessage(Message.Missile);
                                break;
                            case PlanetPower.Shield:
                                gameSimulation.setMessage(Message.Shield);
                                break;
                            case PlanetPower.ShieldRestore:
                                gameSimulation.setMessage(Message.ShieldRestore);
                                break;
                            case PlanetPower.Fury:
                                gameSimulation.setMessage(Message.Fury);
                                break;
                            case PlanetPower.FuryEnhance:
                                gameSimulation.setMessage(Message.FuryEnhance);
                                break;
                        }
                    }
                }

                /*
                 ********************************************************************************
                 * ASTEROIDS                                                                    *
                 ********************************************************************************
                 */

                // Going through all ASTEROIDS (stored in the Map) making damage on player and destroyes missile if it gets too near

                System.Collections.Generic.List<Asteroid> asteroids = gameSimulation.getMap().getAsteroids();
                
                for (int count = asteroids.Count - 1; count >= 0; count--)
                {
                    Asteroid asteroid = asteroids[count];
                    Vector2 astroidPosition = asteroid.getPosition();
                    float asteroidSize = (float)asteroid.getSize() / GameView.camera.getScale();

                    // Player CRASH on ASTEROID

                    if (asteroid.activator.activeOneTimeStep( 
                        Geometry.IsInsideCircle(player.getPosition(), Player.DIAMETER, asteroid.getPosition(), asteroidSize)
                        ))
                    {
                        player.setHitPoints(player.getHitPoints() - asteroid.getDamage());
                        eventListener.MakeExplosion(asteroid.getPosition() + new Vector2(asteroidSize / 2, asteroidSize / 2), gameTime, 0.05f, 10.0f, 20.0f, 100.0f, 0.1f, 10.0f);
                        eventListener.playExplosionSmallSound();
                        asteroids.Remove(asteroid);

                        // ASTEROID warning message

                        if (gameSimulation.getTutorialState() == TutorialState.True && 
                            !gameSimulation.getHasShownMessage()[(int)Message.AsteroidWarning] &&
                            gameSimulation.getLevel() == 1)
                        {
                            gameSimulation.setMessage(Message.AsteroidWarning);
                        }
                    }

                    // BEAM HITS AND DESTROYS ASTEROID

                    for (int index = Player.BEAM_WEAPON.getBeams().Count - 1; index >= 0; index--)
                    {
                        BeamModel beam = Player.BEAM_WEAPON.getBeams()[index];

                        if (Geometry.IsInsideCircle(beam.getPosition(), asteroid.getSize() / GameView.camera.getScale(), asteroid.getPosition(), (float)asteroid.getSize() / GameView.WINDOWSIZE.Y))
                        {
                            Player.BEAM_WEAPON.getBeams().Remove(beam);
                            asteroids.Remove(asteroid);
                            eventListener.MakeExplosion(asteroid.getPosition() + new Vector2(asteroidSize / 2, asteroidSize / 2), gameTime, 0.05f, 10.0f, 20.0f, 100.0f, 0.1f, 10.0f);
                            eventListener.playExplosionSmallSound();
                        }
                    }
                }

                /*
                 ********************************************************************************
                 * ENEMIES                                                                      *
                 ********************************************************************************
                 */

                System.Collections.Generic.List<EnemyTemplate> enemies = gameSimulation.getMap().getEnemies(); // All enemies
                
                for (int count = enemies.Count - 1; count >= 0; count--)
                {
                    // ENEMIES MOVE

                    // Follows player: Direction and distance to player is calculated

                    EnemyTemplate enemy = enemies[count];
                    Vector2 initPos = enemy.getPosition();

                    if (enemy.getType() != EnemyType.Joker || !enemy.getJokerTimer().runTimer(deltaTime))
                    {
                        Vector2 directionToPlayer = enemy.getPosition() - player.getPosition();
                        float distanceToPlayer = Geometry.AbsoluteValue(directionToPlayer);
                        directionToPlayer.Normalize();
                        Vector2 direction = Geometry.AngleToDirection(enemy.getAngle());

                        Movement movement = enemy.getMovement();
                        float angle = enemy.getAngle();
                        enemy.getMovement().setRotationSpeed(enemy.getRotationSpeed());

                        // Turns slowly. Calculation which decides which direction the nenmy should turn to fastest go to player

                        if (direction.X > 0 && directionToPlayer.X > 0)
                        {

                            if (direction.Y > directionToPlayer.Y) { angle = movement.turnRight(enemy.getAngle(), deltaTime); }
                            else { angle = movement.turnLeft(enemy.getAngle(), deltaTime); }
                        }
                        else if (direction.X < 0 && directionToPlayer.X < 0)
                        {
                            if (direction.Y > directionToPlayer.Y) { angle = movement.turnLeft(enemy.getAngle(), deltaTime); }
                            else { angle = movement.turnRight(enemy.getAngle(), deltaTime); }
                        }
                        else if (direction.X > 0 && directionToPlayer.X < 0)
                        {
                            if (direction.Y > -directionToPlayer.Y) { angle = movement.turnLeft(enemy.getAngle(), deltaTime); }
                            else { angle = movement.turnRight(enemy.getAngle(), deltaTime); }
                        }
                        else if (direction.X < 0 && directionToPlayer.X > 0)
                        {
                            if (direction.Y > -directionToPlayer.Y) { angle = movement.turnRight(enemy.getAngle(), deltaTime); }
                            else { angle = movement.turnLeft(enemy.getAngle(), deltaTime); }
                        }
                        enemy.setAngle(angle);

                        // Updating position coordinates. Position is not updated if distance to player is too large. (It then stands still.)
                        // Star Destroyer always follows.
                        if (distanceToPlayer < 0.7f || enemy.getType() == EnemyType.Destroyer || enemy.getType() == EnemyType.BattleShip || enemy.getType() == EnemyType.Carrier)
                        {
                            Vector2 enemyPosition = enemy.getMovement().move(enemy.getPosition(), enemy.getSpeed(), direction, gameSimulation.getMap().getBorderRadius(), deltaTime);
                            enemy.setPosition(enemyPosition);
                        }
                        // Special case: If an enemy is near a carrier, and player is not near, it moves to a random position near the carrier.
                        else
                        {
                            foreach (EnemyTemplate carrier in enemies)
                            {
                                if (carrier.getType() == EnemyType.Carrier)
                                {
                                    float distanceToCarrier = Geometry.AbsoluteValue(carrier.getPosition() - enemy.getPosition());

                                    if (distanceToCarrier < 0.5)
                                    {
                                        enemy.setPosition(carrier.getPosition() + new Vector2(((float)Geometry.rand.NextDouble() - 0.5f) * 0.2f, ((float)Geometry.rand.NextDouble() - 0.5f) * 0.2f));
                                    }
                                }
                            }
                        }
                    }

                    // JOKER
                    else if (enemy.getType() == EnemyType.Joker && enemy.getJokerTimer().runTimer(deltaTime))
                    {
                        if (!enemy.getJokerDurationTimer().runTimer(deltaTime))
                        {
                            enemy.moveJoker(gameSimulation.getMap().getBorderRadius(), deltaTime);
                        }
                        else
                        {
                            enemy.newJokerDirection();
                        }
                    }

                    if (enemy.getType() == EnemyType.Class1)
                    {
                        if (Geometry.AbsoluteValue(enemy.startPosition - enemy.getPosition()) > 0.3f)
                        {
                            enemy.setPosition(initPos);
                        }
                    }

                    // TRACTOR
                    if (enemy.getType() == EnemyType.Tractor)
                    {
                        enemy.pullPlayer();
                    }

                    // CARRIER
                    if (enemy.getType() == EnemyType.Carrier)
                    {
                        Class1Enemy interceptor = enemy.createInterceptor(deltaTime);
                        if (interceptor != null)
                        {
                            enemies.Add(interceptor);
                        }
                    }

                    // ENEMIES SHOOT BEAMS

                    if (enemy.shootBeams(gameSimulation.getMap().getEnemyBeams(), deltaTime))
                    {
                        switch (enemy.getType())
                        {
                            case EnemyType.Class1:
                                eventListener.playEnemy1BeamSound();
                                break;
                            case EnemyType.Joker:
                                eventListener.playEnemy1BeamSound();
                                break;
                            case EnemyType.Class2:
                                eventListener.playEnemy2BeamSound();
                                break;
                            case EnemyType.Teleporter:
                                eventListener.playEnemyTeleporterBeamSound();
                                break;
                            case EnemyType.Lurker:
                                if (enemy.getBeamDamage() != 0)
                                {
                                    eventListener.playEnemyLurkerBeamSound();
                                }
                                break;
                            case EnemyType.Tractor:
                                eventListener.playEnemyTractorBeamSound();
                                break;
                            case EnemyType.DefenceStation:
                                eventListener.playEnemyStationBeamSound();
                                break;
                            case EnemyType.Destroyer:
                                eventListener.playEnemyBossBeamSound();
                                break;
                            case EnemyType.BattleShip:
                                eventListener.playEnemyBossBeamSound();
                                break;
                            case EnemyType.Carrier:
                                eventListener.playEnemyBossBeamSound();
                                break;
                        }
                    }

                    // ENEMIES SMOKE

                    float D = enemy.getDiameter();

                    if ((float)enemy.getHitPoints() / enemy.getMaxHitPoints() > 0.3f && (float)enemy.getHitPoints() / enemy.getMaxHitPoints() < 0.7f)
                    {
                        eventListener.MakeSmoke(enemy.getPosition(), 15.0f, 50 * D, 250 * D);
                    }
                    // More smoke if more damaged
                    else if ((float)enemy.getHitPoints() / enemy.getMaxHitPoints() > 0 && (float)enemy.getHitPoints() / enemy.getMaxHitPoints() < 0.3f)
                    {
                        eventListener.MakeSmoke(enemy.getPosition(), 15.0f, 100 * D, 500 * D);
                    }

                    // ENEMIES CRASH

                    if (enemy.getType() == EnemyType.BattleShip)
                    {
                        if (Geometry.IsInsideCircle(player.getPosition(), Player.DIAMETER, enemy.getPosition(), enemy.getDiameter() / 2))
                        {
                            enemy.crash();
                            player.crash();
                        }
                    }
                    else
                    {
                        if (Geometry.IsInsideCircle(player.getPosition(), Player.DIAMETER, enemy.getPosition(), enemy.getDiameter()))
                        {
                            enemy.crash();
                            player.crash();
                        }
                    }

                    // ENEMIES DIE

                    if (enemy.getHitPoints() <= 0)
                    {
                        enemies.Remove(enemy);
                        eventListener.removeSmoke();

                        // Larger explosions for larger enemies
                        switch (enemy.getType())
                        {
                            case EnemyType.Class1:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 0.3f, 5.0f, 10.0f, 50.0f, 0.1f, 5.0f);
                                eventListener.playExplosionSmallSound();
                                break;
                            case EnemyType.Class2:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 0.5f, 5.0f, 15.0f, 75.0f, 0.2f, 5.0f);
                                eventListener.playExplosionSound();
                                break;
                            case EnemyType.Class3:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 0.5f, 5.0f, 15.0f, 75.0f, 0.2f, 5.0f);
                                eventListener.playExplosionBigSound();
                                break;
                            case EnemyType.DefenceStation:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 1.0f, 5.0f, 20.0f, 100.0f, 0.3f, 10.0f);
                                eventListener.playExplosionBigSound();
                                break;
                            case EnemyType.Destroyer:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 1.5f, 5.0f, 20.0f, 100.0f, 0.5f, 15.0f);
                                eventListener.playExplosionBigSound();
                                break;
                            case EnemyType.BattleShip:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 1.5f, 5.0f, 20.0f, 100.0f, 0.5f, 15.0f);
                                eventListener.playExplosionBigSound();
                                break;
                            case EnemyType.Carrier:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 1.5f, 5.0f, 20.0f, 100.0f, 0.5f, 15.0f);
                                eventListener.playExplosionBigSound();
                                break;
                            case EnemyType.Teleporter:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 0.3f, 5.0f, 10.0f, 50.0f, 0.1f, 5.0f);
                                eventListener.playExplosionSmallSound();
                                break;
                            case EnemyType.Lurker:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 0.3f, 5.0f, 10.0f, 50.0f, 0.1f, 5.0f);
                                eventListener.playExplosionSmallSound();
                                break;
                            case EnemyType.Joker:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 0.3f, 5.0f, 10.0f, 50.0f, 0.1f, 5.0f);
                                eventListener.playExplosionSmallSound();
                                break;
                            case EnemyType.Tractor:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 1.0f, 5.0f, 20.0f, 100.0f, 0.3f, 10.0f);
                                eventListener.playExplosionBigSound();
                                break;
                        }
                        
                    }
                }

                // MOVE ENEMY BEAMS

                for (int index = gameSimulation.getMap().getEnemyBeams().Count - 1; index >= 0; index--)
                {
                    BeamModel beam = gameSimulation.getMap().getEnemyBeams()[index];
                    Vector2 beamPosition = beam.getPosition() + beam.getSpeed() * beam.getDirection() * deltaTime;
                    beam.setPosition(beamPosition);

                    // PLAYER IS HIT

                    if (Geometry.IsInsideCircle(beam.getPosition(), 0, player.getPosition(), Player.DIAMETER * 1.5f))
                    {
                        player.isHit(beam.getBeamDamage()); // Player is hit
                        eventListener.StartShieldAnimation();
                        eventListener.playPlayerHitSound(); // Plays soft sound
                        gameSimulation.getMap().getEnemyBeams().Remove(beam);
                        eventListener.MakeExplosion(player.getPosition(), gameTime, 0.1f, 10.0f, 0.0f, 10.0f, 0.3f, 3.0f);
                    }
                }

                /*
                 ********************************************************************************
                 * OVERALL GAME FUNCTIONS                                                       *
                 ********************************************************************************
                 */

                // DEFENCE STATION warning

                if (gameSimulation.getTutorialState() == TutorialState.True &&
                    !gameSimulation.getHasShownMessage()[(int)Message.DefenceStationWarning] &&
                    gameSimulation.getLevel() == 1 &&
                    Player.MISSILE_WEAPON.getMissileState() == MissileState.OffPlayer)
                {
                    Planet stationPlanet = gameSimulation.getMap().getPlanets()[6];
                    float distanceToStationPlanet = Geometry.AbsoluteValue(player.getPosition() - stationPlanet.getPosition());

                    if (distanceToStationPlanet < 0.6)
                    {
                        gameSimulation.setMessage(Message.DefenceStationWarning);
                    }
                }

                // NEW LEVEL MESSAGE

                // If tutorial mode:

                if (gameSimulation.getTutorialState() == TutorialState.True)
                {
                    if (!gameSimulation.getHasShownMessage()[(int)Message.Opening] && gameSimulation.getLevel() == 1)
                    {
                        gameSimulation.setMessage(Message.Opening);
                    }
                }

                // If normal mode:

                else
                {
                    // Different messages for different levels
                    switch (gameSimulation.getLevel())
                    {
                        case 1:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL1Start] && gameSimulation.getLevel() == 1)
                            {
                                gameSimulation.setMessage(Message.MapL1Start);
                            }
                            break;
                        case 2:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL2Start] && gameSimulation.getLevel() == 2)
                            {
                                gameSimulation.setMessage(Message.MapL2Start);
                            }
                            break;
                        case 3:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL3Start] && gameSimulation.getLevel() == 3)
                            {
                                gameSimulation.setMessage(Message.MapL3Start);
                            }
                            break;
                        case 4:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL4Start] && gameSimulation.getLevel() == 4)
                            {
                                gameSimulation.setMessage(Message.MapL4Start);
                            }
                            break;
                        case 5:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL5Start] && gameSimulation.getLevel() == 5)
                            {
                                gameSimulation.setMessage(Message.MapL5Start);
                            }
                            break;
                        case 6:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL6Start] && gameSimulation.getLevel() == 6)
                            {
                                gameSimulation.setMessage(Message.MapL6Start);
                            }
                            break;
                        case 7:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL7Start] && gameSimulation.getLevel() == 7)
                            {
                                gameSimulation.setMessage(Message.MapL7Start);
                            }
                            break;
                        case 8:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL8Start] && gameSimulation.getLevel() == 8)
                            {
                                gameSimulation.setMessage(Message.MapL8Start);
                            }
                            break;

                        case 9:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL9Start] && gameSimulation.getLevel() == 9)
                            {
                                gameSimulation.setMessage(Message.MapL9Start);
                            }
                            break;
                        case 10:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL10Start] && gameSimulation.getLevel() == 10)
                            {
                                gameSimulation.setMessage(Message.MapL10Start);
                            }
                            break;
                    }
                }

                // GAMEOVER: Testing if player is dead
                if (player.getHitPoints() < player.getMinHitPoints())
                {
                    gameSimulation.setMessage(Message.GameOver);
                }

                // ADVANCE LEVEL
                if (gameSimulation.getNumberOfVisitedPlanets() == gameSimulation.getTotalNumberOfPlanets())
                {
                    if (gameSimulation.getLevel() == 10)
                    {
                        gameSimulation.setMessage(Message.Finished);
                    }
                    else
                    {
                        gameSimulation.setMessage(Message.LevelComplete);
                    }
                }

                // SKIP LEVEL
                if (skipLevelActivator.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.H))) // || currentState.IsConnected && currentState.DPad.Right == ButtonState.Pressed))
                {
                    gameSimulation.skipLevel();
                }
                // GO BACK TO LEVEL
                if (reverseLevelActivator.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.G))) // || currentState.IsConnected && currentState.DPad.Left == ButtonState.Pressed) && gameSimulation.getLevel() >= 2)
                {
                    gameSimulation.reverseLevel();
                }
                gameSimulation.advanceLevel();
                gameSimulation.restartLevel();

                // CHEAT (stays until reloading game)
                
                if (Keyboard.GetState().IsKeyDown(Keys.L))
                {
                    player.setMinHitPoints(-10000);
                    player.setMovement( new Movement(Player.ACCELERATION, Player.MIN_SPEED, 0.5f, Player.ROTATION_SPEED));
                    Player.BEAM_WEAPON.setAutoFireState(AutoFireState.NotLoaded);
                    Player.MISSILE_WEAPON.setMissileState(MissileState.NotLoaded);
                    Player.SHIELD.setShieldState(ShieldState.Unpowered);
                    Player.FURY_MODE.setFuryState(FuryState.NotLoaded);
                }
                if (Keyboard.GetState().IsKeyDown(Keys.K))
                {
                    player.setMinHitPoints(-10000);
                    player.setMovement(new Movement(Player.ACCELERATION, Player.MIN_SPEED, 0.5f, Player.ROTATION_SPEED));
                    Player.BEAM_WEAPON.setAutoFireState(AutoFireState.NotLoaded);
                    Player.MISSILE_WEAPON.setMissileState(MissileState.OffPlayer);
                    Player.FURY_MODE.setFuryState(FuryState.OffPlayer);
                }
                
            }
        }
    }
}

