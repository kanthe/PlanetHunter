﻿/*******************************************************************************************************/
// File:    GameView.cs
// Summary: Triggered by MasterControllers "Draw" method. Creates view elements, used for drawing 
// certain features. Then triggeres their draw methods.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    /// <summary>
    /// Creating visual representation of the game.
    /// </summary>
    class GameView
    {
        public static readonly Vector2 WINDOWSIZE = new Vector2(1250, 1000); // Size of game window.

        GameSimulation gameSimulation; // Model representation of the game.
        int scale; // One model unit in pixels.
        GraphicsDevice device;
        ContentManager content;
        public static Camera camera;
        EventListener eventListener; // Reakts on events, i.e. playing sound when a button is pressed
        Messages messages; // All messages in the game is made here

        PlayerView playerView; // Visual representation of the player.
        EnemyView enemyView; // Visual representation of an enemy
        BeamView beamsView; // Visual representation of fire beams
        MissileView missileView; // Visual representation of a missile
        ShieldView shieldView;
        MapView mapView; // Visual representation of the Map
        SideBar sideBar; // Area on left side having HP-bar och count down circles

        public GameView(GameSimulation gameSimulation, GraphicsDevice device, ContentManager content, EventListener eventListener, Messages messages)
        {
            this.gameSimulation = gameSimulation;
            this.scale = (int)WINDOWSIZE.Y; // Hight of the window is used as scale
            this.device = device;
            this.content = content;
            this.eventListener = eventListener;
            this.messages = messages;
            camera = new Camera(scale);

            playerView = new PlayerView(scale, device, content);
            enemyView = new EnemyView(scale, device, content);
            beamsView = new BeamView(scale, device, content);
            missileView = new MissileView(scale, device, content);
            shieldView = new ShieldView(scale, device, content, eventListener.shieldNumberOfFrames);
            mapView = new MapView(gameSimulation.getMap(), scale, device, content, gameSimulation.getMap().getMusicTitle());
            sideBar = new SideBar(device, content);
            
            foreach (EnemyTemplate enemy in gameSimulation.getMap().getEnemies()) {

                if (enemy.getType() == EnemyType.Teleporter || enemy.getType() == EnemyType.Lurker)
                {
                    enemy.visibleListener = new EventListener(scale, device, content, messages);
                }
            }
        }

        //DRAWS GAME

        public void DrawGame(GameTime gameTime, SpriteBatch spriteBatch)
        {
            // The gametime step in seconds
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // BACKGROUND

            // Setting background color
            device.Clear(Color.Black);
            
            // MAP

            // MapView has methods to draw most game elements, including planets, asteroids, background stars, border around map
            mapView.drawMap(spriteBatch, gameSimulation.getMap());

            // Draws ASTEROIDS

            foreach (Asteroid asteroid in gameSimulation.getMap().getAsteroids())
            {
                mapView.drawAsteroid(asteroid, spriteBatch);
            }
            
            // ---------
            // PLAYER
            // ---------

            Player player = gameSimulation.getPlayer();
            // The View is centered on the player
            // Everything drawn below will be drawn with respect to player
            camera.centerOn(player.getPosition() - new Vector2(Player.DIAMETER / 2, Player.DIAMETER / 2));

            // Position on view (screen) coordinates
            Vector2 playerViewPosition = camera.modelPositionToViewPosition(player.getPosition());

            // Draws PLANETS and LAND INDICATOR on a planet if player is over it and it is landable
            foreach (Planet planet in gameSimulation.getMap().getPlanets())
            {
                mapView.DrawPlanet(planet, spriteBatch);
                
                if (planet.getLandingStatus() == LandingStatus.PlayerOverPlanet || planet.getLandingStatus() == LandingStatus.PlayerIsLanding)
                {
                    mapView.drawLandIndicator(planet, spriteBatch);
                }
            }
            
            // Draws PLAYER

            playerView.DrawPlayer(player, scale, spriteBatch);

            // Draws BEAMS (using the "DrawBeams" method in "beamView", which draws all players beams).

            beamsView.DrawBeams(Player.BEAM_WEAPON.getBeams(), scale, spriteBatch);

            // Draws MISSILES

            missileView.DrawMissiles(Player.MISSILE_WEAPON.getMissiles(), scale, spriteBatch);

            // Draws SHIELD

            if (Player.SHIELD.getShieldState() == ShieldState.Powered)
            {
                shieldView.DrawShield(player, eventListener.shieldFrameNumber, spriteBatch);
            }

            // ENEMIES

            // Draws enemies
            System.Collections.Generic.List<EnemyTemplate> enemies = gameSimulation.getMap().getEnemies();
            enemyView.DrawEnemies(enemies, spriteBatch);

            // Draws beams (using the "DrawBeams" method in "beamView", which draws all enemies beams).
            
            beamsView.DrawBeams(gameSimulation.getMap().getEnemyBeams(), scale, spriteBatch);
            
            // SPECIAL ENEMY ABILITIES

            foreach(EnemyTemplate enemy in enemies) {
                if (enemy.getType() == EnemyType.Tractor)
                {
                    enemyView.DrawTractorBeam(scale, spriteBatch, enemy, player, deltaTime);
                }

                // LURKER

                
                if (enemy.getType() == EnemyType.Lurker)
                {
                    enemy.setInvisible(deltaTime);
                    // Draws visibilityanimation for enemy type Teleporter or Lurker
                    enemyView.DrawVisibility(enemy, spriteBatch);
                }
                // TELEPORTER teleport regularly
                if (enemy.getType() == EnemyType.Teleporter)
                {
                    enemy.teleport(deltaTime);
                    // Draws visibilityanimation for enemy type Teleporter or Lurker
                    enemyView.DrawVisibility(enemy, spriteBatch);
                }
            }
            
             

            
            
            // EXPLOSIONS AND SMOKE

            eventListener.UpdateExplosions(gameTime, spriteBatch, deltaTime);
            eventListener.UpdateSmoke(spriteBatch, deltaTime);

            // SIDEBAR
            // Draws sidebar and with it everything that is on it

            sideBar.Draw(player, messages.getPauseForMessage(), spriteBatch, deltaTime);

            sideBar.DrawMinimap(player, gameSimulation.getMap().getPlanets(), gameSimulation.getMap().getBorderRadius(), spriteBatch, deltaTime);
            
            foreach (Planet planet in gameSimulation.getMap().getPlanets())
            {
                if (planet.getLandingStatus() == LandingStatus.PlayerIsLanding)
                {
                    sideBar.DrawLandingBar(planet, messages.getPauseForMessage(), spriteBatch, deltaTime);
                    camera.zoom(99.0f);
                }
                else if (planet.getLandingStatus() == LandingStatus.PlayerHasLanded)
                {
                    scale = (int)WINDOWSIZE.Y;
                    camera.setScale(scale);
                    camera.setDisplacementFactor(2.0f);
                    planet.setLandingStatus(LandingStatus.NotLandable);
                }
                else if(player.interuptLanding)
                {
                    scale = (int)WINDOWSIZE.Y;
                    camera.setScale(scale);
                    camera.setDisplacementFactor(2.0f);
                    player.interuptLanding = false;
                }
            }
            
            // SHOW MESSAGE

            if (eventListener.DisplayMessage(playerViewPosition, gameSimulation.getMessage(), spriteBatch, deltaTime))
            {
                gameSimulation.setHasShownMessage(gameSimulation.getMessage(), true);
                gameSimulation.setMessage(Message.None);
            }
        }
    }
}
