﻿/*******************************************************************************************************/
// File:    Camera.cs
// Summary: Interface between model and view. Tranlating model coordinates/lengths to view 
// coordinates/lengths and vice versa. 
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace View
{
    /// <summary>
    /// Transforming model coordinates to coordinates of viewing window
    /// </summary>
    class Camera
    {
        float scale;
        Vector2 viewDisplacement;
        float displacementFactor;
        
        public Camera(int scale)
        {
            // One model unit i pixels. The window height is used as scale in this simulation
            this.scale = (float)scale;
            displacementFactor = 2.0f;
        }
        /// <summary>
        /// Calculating the displacement when centering view on a certain position.
        /// Used in methods below to calculate model and view positions.
        /// </summary>
        public void centerOn(Vector2 modelPosition) 
        {
            // Calculating displacement when moving a position to centre of the screen and adding the side bar.
            viewDisplacement = new Vector2(scale / displacementFactor, scale / displacementFactor) - modelPosition * scale + new Vector2(SideBar.SIDEBAR_WIDTH, 0);
        }

        public void zoom(float percent)
        {
            scale = scale / percent * 100.0f;
            displacementFactor = displacementFactor * 100.0f / percent;
        }

        /// <summary>
        /// Transforming model coordinates to view coordinates
        /// </summary>
        /// <param name="modelPosition">Position in model coordinates</param>
        /// <returns>Position in view coordinates</returns>
        public Vector2 modelPositionToViewPosition(Vector2 modelPosition)
        {
            Vector2 viewPosition = modelPosition * scale + viewDisplacement;

            return viewPosition;
        }

        /// <summary>
        /// Transforming view coordinates to model coordinates
        /// </summary>
        /// <param name="viewPosition">Position in view coordinates</param>
        /// <returns>Position in model coordinates</returns>
        public Vector2 viewPositionToModelPosition(Vector2 viewPosition) 
        {
            Vector2 modelPosition = viewPosition / (viewPosition - viewDisplacement) / scale;

            return modelPosition;
        }
        
        /// <summary>
        /// Transforming a length in model coordinates to view coordinates
        /// </summary>
        public int scaleObject(float length)
        {
            int scaledObject = (int)(length * scale);

            return scaledObject;
        }
        public float getScale() { return scale; }
        public void setScale(int scale) { this.scale = (float)scale; }
        public void setDisplacementFactor(float displacementFactor) { this.displacementFactor = (float)displacementFactor; }
    }
}
