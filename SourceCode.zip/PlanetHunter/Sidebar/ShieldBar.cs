﻿/*******************************************************************************************************/
// File:    ShieldBar.cs
// Summary: Creates and draws missilebar (text and a countdownbar)
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Model;

namespace View
{
    class ShieldBar
    {
        CountDownCircle countDownView;
        Vector2 textPosition = new Vector2(30, 600);
        Vector2 textSize = new Vector2(105, 30);
        Vector2 textureCoords = new Vector2(0, 0);
        Vector2 countDownCirclePosition;

        public ShieldBar(GraphicsDevice device)
        {
            countDownCirclePosition = new Vector2(90, textPosition.Y + 40);
            countDownView = new CountDownCircle(countDownCirclePosition, device);
        }
        // GET method
        public CountDownCircle getCountDownView() { return countDownView; }
        // Draws text and countdownbar
        public void Draw(Player player, SpriteBatch spriteBatch, float deltaTime)
        {
            float loadTime = Player.SHIELD.SHIELD_LOADTIME;
            countDownView.setLoadTimer(loadTime);

            spriteBatch.Draw(
                SideBar.TextCollectionTexture,
                new Rectangle((int)textPosition.X, (int)textPosition.Y, (int)textSize.X, (int)textSize.Y),
                new Rectangle((int)textureCoords.X, (int)textureCoords.Y, (int)textSize.X, (int)textSize.Y),
                    Color.White
                    );
            countDownView.Draw(Player.SHIELD.getShieldState() == ShieldState.NotLoaded, spriteBatch, deltaTime);
        }
    }
}
