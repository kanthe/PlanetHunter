﻿/*******************************************************************************************************/
// File:    Minimap.cs
// Summary: Creates and draws sidebar and its elements
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class Minimap
    {
        public static readonly float MINIMAP_SIZE = HitPointsBar.HP_BAR_WIDTH;

        GraphicsDevice device;
        ContentManager content;
        Camera camera;
        Vector2 position;
        Texture2D mapTexture;

        public Minimap(GraphicsDevice device, ContentManager content)
        {
            this.device = device;
            this.content = content;
            camera = GameView.camera;
            position = new Vector2(
                (SideBar.SIDEBAR_WIDTH - MINIMAP_SIZE) / 2,
                SideBar.SIDEBAR_HEIGHT - MINIMAP_SIZE - (SideBar.SIDEBAR_WIDTH - MINIMAP_SIZE) / 2
                );
            mapTexture = new Texture2D(device, 1, 1);
            mapTexture.SetData(new[] { Color.White });
        }

        public void Draw(Player player, System.Collections.Generic.List<Planet> planets, float mapSize, SpriteBatch spriteBatch, float deltaTime)
        {
            Vector2 playerPosition = position + new Vector2(MINIMAP_SIZE, MINIMAP_SIZE) / 2 + player.getPosition() * MINIMAP_SIZE / mapSize / 2;

            

            spriteBatch.Draw(mapTexture, new Rectangle((int)position.X, (int)position.Y, (int)MINIMAP_SIZE, (int)MINIMAP_SIZE), Color.Black);
            spriteBatch.Draw(mapTexture, new Rectangle((int)playerPosition.X, (int)playerPosition.Y, 5, 5), Color.Green);

            foreach (Planet planet in planets)
            {
                Vector2 planetPosition = position + new Vector2(MINIMAP_SIZE, MINIMAP_SIZE) / 2 + planet.getPosition() * MINIMAP_SIZE / mapSize / 2;
                spriteBatch.Draw(mapTexture, new Rectangle((int)planetPosition.X, (int)planetPosition.Y, 5, 5), Color.Yellow);
            }
        }
    }
}
