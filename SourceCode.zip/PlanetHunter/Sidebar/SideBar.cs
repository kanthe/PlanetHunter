﻿/*******************************************************************************************************/
// File:    SideBar.cs
// Summary: Creates and draws sidebar and its elements
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class SideBar
    {
        public static readonly int SIDEBAR_WIDTH = 250;
        public static readonly int SIDEBAR_HEIGHT = (int)GameView.WINDOWSIZE.Y;
        public static readonly int TEXT_HEIGHT = 30;
        public static readonly int SPACE_BETWEEN_BARS = 15;
        public static readonly int SPACE_UNDER_TEXT = 10;

        GraphicsDevice device;
        ContentManager content;
        Camera camera;
        static Texture2D SideBarBackgroundTexture;
        public static Texture2D SideBarCollectionTexture;

        HitPointsBar hpBar;
        HitPointsBar shieldHpBar;
        CountDownBar autoFireBar;
        CountDownBar missileBar;
        CountDownBar furyBar;
        public CountDownBar landingBar;
        Timer landingTimer;
        Activator activator = new Activator(0);
        Minimap minimap;

        public SideBar(GraphicsDevice device, ContentManager content)
        {
            this.device = device;
            this.content = content;
            camera = GameView.camera;
            landingTimer = new Timer(Player.LANDING_TIME);
            SideBarBackgroundTexture = content.Load<Texture2D>("sidebar_backGround");
            SideBarCollectionTexture = content.Load<Texture2D>("sidebar_text");
            // Draws HITPOINTS bar
            float yStartDisplacementHpBar = 20.0f;
            hpBar = new HitPointsBar(yStartDisplacementHpBar, new Vector2(120, 0), 100, Color.Green, device);
            // Draws SHIELD hitpoints bar
            float yStartDisplacementShieldHpBar = yStartDisplacementHpBar + TEXT_HEIGHT + SPACE_BETWEEN_BARS + SPACE_UNDER_TEXT + HitPointsBar.HP_BAR_HEIGHT;
            shieldHpBar = new HitPointsBar(yStartDisplacementShieldHpBar, new Vector2(0, 0), 80, Color.Blue, device);
            // Draws AUTOFIRE bar
            float yStartDisplacementAutofireBar = yStartDisplacementShieldHpBar + TEXT_HEIGHT + SPACE_BETWEEN_BARS + SPACE_UNDER_TEXT + HitPointsBar.HP_BAR_HEIGHT;
            autoFireBar = new CountDownBar(yStartDisplacementAutofireBar, new Vector2(0, 30), new Vector2(135, TEXT_HEIGHT), device);
            // Draws MISSILE bar
            float yStartDisplacementMissileBar = yStartDisplacementAutofireBar + TEXT_HEIGHT + SPACE_BETWEEN_BARS + SPACE_UNDER_TEXT + CountDownBar.COUNTDOWN_TEXTURE_SIZE;
            missileBar = new CountDownBar(yStartDisplacementMissileBar, new Vector2(0, 60), new Vector2(100, TEXT_HEIGHT), device);
            // Draws FURY bar
            float yStartDisplacementFuryBar = yStartDisplacementMissileBar + TEXT_HEIGHT + SPACE_BETWEEN_BARS + SPACE_UNDER_TEXT + CountDownBar.COUNTDOWN_TEXTURE_SIZE;
            furyBar = new CountDownBar(yStartDisplacementFuryBar, new Vector2(120, 90), new Vector2(150, TEXT_HEIGHT), device);

            // LANDING bar
            float yStartDisplacementLandingBar = yStartDisplacementFuryBar + TEXT_HEIGHT + SPACE_BETWEEN_BARS + SPACE_UNDER_TEXT + CountDownBar.COUNTDOWN_TEXTURE_SIZE;
            landingBar = new CountDownBar(yStartDisplacementLandingBar, new Vector2(0, 90), new Vector2(105, TEXT_HEIGHT), device);

            // MINIMAP
            minimap = new Minimap(device, content);
        }
        /*
        public void resetLandingBar()
        {
            landingBar.getCountDownCircle().setCountDown(0);
        }
        */
        /// <summary>
        /// Draws different countdown bars and the HP-bar and shieldHP bar
        /// </summary>
        public void Draw(Player player, bool pauseForMessage, SpriteBatch spriteBatch, float deltaTime)
        {
            // Half transparant background
            spriteBatch.Draw(SideBarBackgroundTexture, new Vector2(0, 0), Color.White);
            // Hitpoints bar
            hpBar.DrawHitPointsBar(player.getHitPoints(), Player.STARTING_HITPOINTS, spriteBatch);

            if (!pauseForMessage)
            {
                // Shield hitpoints bar
                if (Player.SHIELD.getShieldState() == ShieldState.Unpowered || Player.SHIELD.getShieldState() == ShieldState.Powered)
                {
                    shieldHpBar.DrawHitPointsBar(Player.SHIELD.getHitPoints(), Player.SHIELD.STARTING_HITPOINTS, spriteBatch);
                }
                // Autofirebar if autofire is activated
                if (Player.BEAM_WEAPON.getAutoFireState() != AutoFireState.OffPlayer)
                {
                    autoFireBar.Draw(spriteBatch, Player.BEAM_WEAPON.getCountDownState());
                }
                // Missilebar if missile is activated
                if (Player.MISSILE_WEAPON.getMissileState() != MissileState.OffPlayer)
                {
                    missileBar.Draw(spriteBatch, Player.MISSILE_WEAPON.getCountDownState());
                }
                // Fury if fury device is activated
                if (Player.FURY_MODE.getFuryState() != FuryState.OffPlayer)
                {
                    if (Player.FURY_MODE.getFuryState() != FuryState.Active)
                    {
                        autoFireBar.setColor(Color.White);
                        missileBar.setColor(Color.White);
                        furyBar.setColor(Color.White);
                        furyBar.Draw(spriteBatch, Player.FURY_MODE.getCountDownState());
                    }
                    else
                    {
                        autoFireBar.setColor(Color.Red);
                        missileBar.setColor(Color.Red);
                        furyBar.setColor(Color.Red);
                        furyBar.Draw(spriteBatch, Player.FURY_MODE.getCountDownState());
                    }
                }
            }
        }
        /// <summary>
        /// Draws landingbar. Triggered if player is landing (landing key pressed on landable planet).
        /// </summary>
        public void DrawLandingBar(Planet planet, bool pauseForMessage, SpriteBatch spriteBatch, float deltaTime)
        {
            landingBar.Draw(spriteBatch, planet.countDownState);
        }
        
        /// <summary>
        /// Draws minimap
        /// </summary>
        public void DrawMinimap(Player player, System.Collections.Generic.List<Planet> planets, float mapSize, SpriteBatch spriteBatch, float deltaTime)
        {
            minimap.Draw(player, planets, mapSize, spriteBatch, deltaTime);
        }
    }
}
