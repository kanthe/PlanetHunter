﻿/*******************************************************************************************************/
// File:    CountDownView.cs
// Summary: Creates and draws a countdown circle.
// Also handles when circle will "turn" one quarter
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class CountDownCircle
    {
        
        GraphicsDevice device;
        Vector2[] countDownTextureCoords;
        Timer loadTimer = new Timer(0); // Timer which are used to count down to when countdown will increase one quarter
        int textureNumber = 0;

        public CountDownCircle(float loadTime)
        {
            setLoadTimer(loadTime);
        }
        public float getCountDownTime() { return loadTimer.getResetTime(); }
        public float getTextureNumber() { return textureNumber; }
        // SETS loadtime
        public void setLoadTimer(float loadTime)
        {
            loadTimer.setTimer(loadTime / 4); // After loadtime / 4, circle has to turn one quarter
        }
        public void resetLoadTimer()
        {
            loadTimer.resetTimer();
            textureNumber = 0;
        }
        // Each texturenumber shows the countdown at different times. This sets the texturenumber
        public void setTextureNumber(int number) { textureNumber = number; }
        /// <summary>
        /// Determining the right texture and draws the countdown circle
        /// </summary>
        public void Draw(SpriteBatch spriteBatch, float deltaTime, bool loaded, Color color)
        {
            bool reachedResetTime = loadTimer.runTimer(deltaTime);

            if (!loaded)
            {
                

                if (reachedResetTime)
                {
                    textureNumber++;
                    loadTimer.resetTimer();

                    if (textureNumber == 5)
                    {
                        textureNumber = 0;
                    }
                }
            }
            else
            {
                resetLoadTimer();
            }

        }
    }
}
