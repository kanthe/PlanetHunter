﻿/*******************************************************************************************************/
// File:    HitPointsBar.cs
// Summary: Creates and draws HP-bar
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Model;

namespace View
{
    /// <summary>
    /// Creating and drawing a border in a square
    /// </summary>
    class HitPointsBar
    {
        public static readonly int HP_BAR_HEIGHT = 20;
        public static readonly float HP_BAR_WIDTH = SideBar.SIDEBAR_WIDTH * 0.8f;

        Vector2 hpBarPosition;
        Texture2D hpBarTexture;
        Vector2 textPosition;
        Vector2 textSize;
        Texture2D textCollectionTexture = SideBar.SideBarCollectionTexture;
        Vector2 textCollectionCoords;
        Color color;

        public HitPointsBar(float yDisplacement, Vector2 textCollectionCoords, float textWidth, Color color, GraphicsDevice device)
        {
            textPosition.Y = yDisplacement;
            hpBarPosition.X = (SideBar.SIDEBAR_WIDTH - HP_BAR_WIDTH) / 2;
            hpBarPosition.Y = textPosition.Y + SideBar.TEXT_HEIGHT + SideBar.SPACE_UNDER_TEXT;
            textSize = new Vector2(textWidth, SideBar.TEXT_HEIGHT);
            textPosition.X = hpBarPosition.X + HP_BAR_WIDTH / 2 - textWidth / 2;
            this.color = color;
            hpBarTexture = new Texture2D(device, 1, 1);
            hpBarTexture.SetData(new[] { Color.White });
            this.textCollectionCoords = textCollectionCoords;
        }
        /// <summary>
        /// Draws the border, with 4 rectangles
        /// </summary>
        /// <param name="scale">One model unit (square width)</param>
        public void DrawHitPointsBar(int hitPoints, int STARTING_HITPOINTS, SpriteBatch spriteBatch)
        {
            int posX = (int)hpBarPosition.X;
            int posY = (int)hpBarPosition.Y;
            spriteBatch.Draw(hpBarTexture, new Rectangle(posX, posY, (int)HP_BAR_WIDTH, HP_BAR_HEIGHT), color);
            spriteBatch.Draw(hpBarTexture, new Rectangle(posX + (int)(HP_BAR_WIDTH / STARTING_HITPOINTS * hitPoints), posY, (int)(HP_BAR_WIDTH / STARTING_HITPOINTS * (STARTING_HITPOINTS - hitPoints)), HP_BAR_HEIGHT), Color.Red);

            spriteBatch.Draw(
                SideBar.SideBarCollectionTexture,
                new Rectangle((int)textPosition.X, (int)textPosition.Y, (int)textSize.X, (int)textSize.Y),
                new Rectangle((int)textCollectionCoords.X, (int)textCollectionCoords.Y, (int)textSize.X, (int)textSize.Y),
                    Color.White
                );
        }
    }
}
