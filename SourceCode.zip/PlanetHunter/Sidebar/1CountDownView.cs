﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class CountDownView
    {
        Vector2 position;
        Vector2 size = new Vector2(70, 70);
        GraphicsDevice device;
        Timer loadTimer = new Timer(0);
        int textureNumber;

        Vector2[] countDownTextureCoords = new Vector2[] {
                new Vector2(230, 0), // countDownTextureCoordsFull
                new Vector2(0, 130), // countDownTextureCoordsQuarter1
                new Vector2(74, 130), // countDownTextureCoordsQuarter2
                new Vector2(147, 130), // countDownTextureCoordsQuarter3
                new Vector2(222, 130) // countDownTextureCoordsQuarter4
            };

        public CountDownView(Vector2 position, GraphicsDevice device)
        {
            this.position = position;
            this.device = device;
        }
        public int getTextureNumber() { return textureNumber; }
        public Timer getLoadTimer() { return loadTimer; }
        public void resetTextureNumber() { textureNumber = 0; }

        public void Draw(float loadTime, SpriteBatch spriteBatch, float deltaTime)
        {
            loadTimer.setTimer(loadTime / 5);

            if (textureNumber < 4)
            {
                if (loadTimer.runTimer(deltaTime))
                {
                    textureNumber++;
                    loadTimer.resetTimer();
                }
            }
            Rectangle positionRectangle = new Rectangle((int)position.X, (int)position.Y, (int)size.X, (int)size.Y);
            Rectangle textureRectangle = new Rectangle((int)countDownTextureCoords[textureNumber].X, (int)countDownTextureCoords[textureNumber].Y, (int)size.X, (int)size.Y);
            spriteBatch.Draw(SideBar.textCollectionTexture, positionRectangle, textureRectangle, Color.White);
        }
    }
}
