﻿/*******************************************************************************************************/
// File:    CountDownCircle.cs
// Summary: Creates and draws a countdown circle with headline text over it.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Model;

namespace View
{
    class CountDownBar
    {
        public static readonly int COUNTDOWN_TEXTURE_SIZE = 70;

        GraphicsDevice device;

        Vector2 countDownCircleSize;
        Vector2 countDownCirclePosition;
        Color countDownCircleColor = Color.White;
        Vector2[] countDownTextureCoords;

        Vector2 textPosition;
        Vector2 textSize;
        Vector2 textCollectionCoords; 

        public CountDownBar(float yDisplacement, Vector2 textCollectionCoords, Vector2 textSize, GraphicsDevice device)
        {
            this.device = device;
            textPosition.Y = yDisplacement;
            countDownCircleSize = new Vector2(COUNTDOWN_TEXTURE_SIZE, COUNTDOWN_TEXTURE_SIZE);
            countDownCirclePosition.X = (SideBar.SIDEBAR_WIDTH - COUNTDOWN_TEXTURE_SIZE) / 2;
            countDownCirclePosition.Y = textPosition.Y + SideBar.TEXT_HEIGHT + SideBar.SPACE_UNDER_TEXT;
            this.textSize = textSize;
            textPosition.X = countDownCirclePosition.X + COUNTDOWN_TEXTURE_SIZE / 2 - textSize.X / 2;
            this.textCollectionCoords = textCollectionCoords;

            countDownTextureCoords = new Vector2[] {
                new Vector2(0, 130), // countDownTextureCoordsQuarterEmpty
                new Vector2(74, 130), // countDownTextureCoordsQuarter1
                new Vector2(147, 130), // countDownTextureCoordsQuarter2
                new Vector2(222, 130), // countDownTextureCoordsQuarter3
                new Vector2(230, 0) // countDownTextureCoordsFull
            };
        }
        /// <summary>
        /// SET METHODS
        /// </summary>
        public void setColor(Color color) { countDownCircleColor = color; }

        /// <summary>
        /// Draws text and countdown circle
        /// </summary>
        public void Draw(SpriteBatch spriteBatch, int countDownTextureNumber)
        {
            // Draws text
            spriteBatch.Draw(
                SideBar.SideBarCollectionTexture,
                new Rectangle((int)textPosition.X, (int)textPosition.Y, (int)textSize.X, (int)textSize.Y),
                new Rectangle((int)textCollectionCoords.X, (int)textCollectionCoords.Y, (int)textSize.X, (int)textSize.Y),
                Color.White
                );
            // Draws countdown circle
            Rectangle positionRectangle = new Rectangle(
                (int)countDownCirclePosition.X, (int)countDownCirclePosition.Y, (int)countDownCircleSize.X, (int)countDownCircleSize.Y);
            Rectangle textureRectangle = new Rectangle(
                (int)countDownTextureCoords[countDownTextureNumber].X, (int)countDownTextureCoords[countDownTextureNumber].Y, (int)countDownCircleSize.X, (int)countDownCircleSize.Y);
            spriteBatch.Draw(SideBar.SideBarCollectionTexture, positionRectangle, textureRectangle, countDownCircleColor);
        }
    }
}
