﻿/*******************************************************************************************************/
// File:    CountDownView.cs
// Summary: Creates and draws the autofirebar.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class AutoFireBar
    {
        CountDownCircle countDownCircle;
        Vector2 textPosition = new Vector2(55, 200);
        Vector2 textSize = new Vector2(135, 30);
        Vector2 textureCoords = new Vector2(0, 30);
        Vector2 countDownPosition;

        public AutoFireBar(float yDisplacement, GraphicsDevice device)
        {
            countDownPosition = new Vector2(90, yDisplacement);
            countDownCircle = new CountDownCircle(Player.BEAM_WEAPON.getAutoFireLoadTime());
        }
        public CountDownCircle getCountDownView() { return countDownCircle; }
        /// <summary>
        /// Draws autofire bar
        /// </summary>
        public void Draw(Player player, SpriteBatch spriteBatch, float deltaTime)
        {
            float loadTime = Player.BEAM_WEAPON.getAutoFireLoadTime();
            countDownCircle.setLoadTimer(loadTime);

            spriteBatch.Draw(
                SideBar.SideBarCollectionTexture, 
                new Rectangle((int)textPosition.X, (int)textPosition.Y, (int)textSize.X, (int)textSize.Y),
                new Rectangle((int)textureCoords.X, (int)textureCoords.Y, (int)textSize.X, (int)textSize.Y),
                    Color.White
                );
            countDownCircle.Draw(spriteBatch, deltaTime, true, Color.White);
        }
    }
}
