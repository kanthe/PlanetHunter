﻿/*******************************************************************************************************/
// File:    MissileWeapon.cs
// Summary: Creates shoots missile on command from gameController via player
// Version: Version 1.0 - 2016-05-13
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-05-13 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

public enum MissileState { OffPlayer, NotLoaded, Loaded }

namespace Model
{
    class MissileWeapon
    {
        System.Collections.Generic.List<MissileModel> missiles = new System.Collections.Generic.List<MissileModel>();

        readonly float SPEED = 0.5f;
        readonly int SIZE = 20;
        readonly Color COLOR = Color.Green;
        readonly int DAMAGE = 200;

        MissileState missileState;
        float missileLoadTime;
        Timer missileLoadTimer; // Counts down load time
        Activator missileLoadActivator; // Used to fire missile at one key stroke
        int countDownState = 0; // Determines which circle section should be drawn in the countdown bar

        public MissileWeapon()
        {
            missileState = MissileState.OffPlayer;
            missileLoadTime = 5.0f;
            missileLoadTimer = new Timer(missileLoadTime);
            missileLoadActivator = new Activator(0);
        }
        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        public System.Collections.Generic.List<MissileModel> getMissiles() { return missiles; }
        public float getSpeed() { return SPEED; }
        public int getSize() { return SIZE; }
        public Color getColor() { return COLOR; }
        public int getDamage() { return DAMAGE; }
        public float getMissileLoadTime() { return missileLoadTime; }
        public MissileState getMissileState() { return missileState; }
        public int getCountDownState() { return countDownState; }
        

        /// <summary>
        /// SET METHODS
        /// </summary>
        public void setMissileLoadTime(float missileLoadTime)
        {
            this.missileLoadTime = missileLoadTime;
            missileLoadTimer.setTimer(missileLoadTime);
        }
        public void setMissileState(MissileState missileState) { this.missileState = missileState; }

        /// <summary>
        /// FIRE
        /// </summary>
        public bool launch(bool fireButtonPressed, float deltaTime, Vector2 position, float angle)
        {
            missileState = MissileState.NotLoaded;
            bool loaded = missileLoadTimer.runTimer(deltaTime);

            if (missileLoadTimer.getTimer() > (countDownState + 1) * missileLoadTime / 4)
            {
                countDownState++;
            }

            bool fireMissile = false;
            Vector2 direction = Geometry.AngleToDirection(angle);
            // Fires one beam if firebutton is pressed
            if (loaded)
            {
                countDownState = 4;
                missileState = MissileState.Loaded;

                if (missileLoadActivator.activeOneTimeStep(fireButtonPressed))
                {
                    missiles.Add(new MissileModel(position, angle));
                    missileLoadTimer.resetTimer();
                    missileState = MissileState.NotLoaded;
                    fireMissile = true;
                    countDownState = 0;
                }
            }

            return fireMissile; // returns true if beam is fired
        }
    }
}

