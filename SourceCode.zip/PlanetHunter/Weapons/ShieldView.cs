﻿/*******************************************************************************************************/
// File:    ShieldView.cs
// Summary: Draws the shield
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    /// <summary>
    /// Creating visual representation of a missile
    /// </summary>
    class ShieldView
    {
        Camera camera;
        Texture2D[] shieldTextures;

        public ShieldView(int scale, GraphicsDevice device, ContentManager content, int numberOfFrames)
        {
            camera = GameView.camera;
            shieldTextures = new Texture2D[numberOfFrames]; // Texture of beamshot from file

            shieldTextures[0] = content.Load<Texture2D>("shield"); // Texture for the shield
            shieldTextures[1] = content.Load<Texture2D>("shield1"); // Texture for the shield
            shieldTextures[2] = content.Load<Texture2D>("shield1a"); // Texture for the shield
            shieldTextures[3] = content.Load<Texture2D>("shield1aa"); // Texture for the shield
            shieldTextures[4] = content.Load<Texture2D>("shield1aaa"); // Texture for the shield
            shieldTextures[5] = content.Load<Texture2D>("shield1aaaa"); // Texture for the shield
            shieldTextures[6] = content.Load<Texture2D>("shield2"); // Texture for the shield
            shieldTextures[7] = content.Load<Texture2D>("shield2a"); // Texture for the shield
            shieldTextures[8] = content.Load<Texture2D>("shield2aa"); // Texture for the shield
            shieldTextures[9] = content.Load<Texture2D>("shield2aaa"); // Texture for the shield
            shieldTextures[10] = content.Load<Texture2D>("shield2aaaa"); // Texture for the shield
            shieldTextures[11] = content.Load<Texture2D>("shield3"); // Texture for the shield
            shieldTextures[12] = content.Load<Texture2D>("shield3a"); // Texture for the shield
            shieldTextures[13] = content.Load<Texture2D>("shield3aa"); // Texture for the shield
            shieldTextures[14] = content.Load<Texture2D>("shield3aaa"); // Texture for the shield
            shieldTextures[15] = content.Load<Texture2D>("shield3aaaa"); // Texture for the shield
            shieldTextures[16] = content.Load<Texture2D>("shield4"); // Texture for the shield
            shieldTextures[17] = content.Load<Texture2D>("shield4a"); // Texture for the shield
            shieldTextures[18] = content.Load<Texture2D>("shield4aa"); // Texture for the shield
            shieldTextures[19] = content.Load<Texture2D>("shield4aaa"); // Texture for the shield
            shieldTextures[20] = content.Load<Texture2D>("shield5"); // Texture for the shield
            shieldTextures[21] = content.Load<Texture2D>("shield5a"); // Texture for the shield
            shieldTextures[22] = content.Load<Texture2D>("shield5aa"); // Texture for the shield
            shieldTextures[23] = content.Load<Texture2D>("shield5aaa"); // Texture for the shield
        }
        /// <summary>
        /// Draws the shield. Activated each gametime step.
        /// </summary>
        public void DrawShield(Player player, int frameNumber, SpriteBatch spriteBatch)
        {
            Vector2 viewPosition = camera.modelPositionToViewPosition(player.getPosition());

            int size = camera.scaleObject(3 * Player.DIAMETER);
            Color color = Player.SHIELD.COLOR;
            Rectangle rect = new Rectangle((int)viewPosition.X, (int)viewPosition.Y, size, size);

            float angle = player.getAngle();

            // Drawing the missile
            spriteBatch.Draw(shieldTextures[frameNumber], rect, null, color, angle, new Vector2(size, size), SpriteEffects.None, 0);
        }
    }
}


