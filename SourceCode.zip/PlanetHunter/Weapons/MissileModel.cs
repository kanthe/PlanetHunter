﻿/*******************************************************************************************************/
// File:    MissileModel.cs
// Summary: Creates shoots missile on command from gameController via player
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class MissileModel
    {
        Vector2 position;
        Vector2 direction;
        float angle;

        public MissileModel(Vector2 position, float angle)
        {
            this.position = position;
            this.angle = angle;
            direction = new Vector2((float)System.Math.Cos(angle), (float)System.Math.Sin(angle));
        }

        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        public Vector2 getPosition() { return position; }
        public Vector2 getDirection() { return direction; }
        public float getAngle() { return angle; }

        /// <summary>
        /// SET METHODS
        /// </summary>
        public void setPosition(Vector2 position) { this.position = position; }
    }
}