﻿/*******************************************************************************************************/
// File:    Shield.cs
// Summary: 
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
// Log:2016-05-13 Shield load timer removed. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

public enum ShieldState { OffPlayer, Unpowered, Powered }

namespace Model
{
    class Shield
    {
        public readonly int STARTING_HITPOINTS = Player.STARTING_HITPOINTS;
        public readonly Color COLOR = Color.Purple;

        int hitPoints;
        Activator shieldLoadActivator;
        ShieldState shieldState = ShieldState.OffPlayer;

        public Shield()
        {
            hitPoints = STARTING_HITPOINTS;
            shieldLoadActivator = new Activator(0);
        }

        // GET methods

        public int getHitPoints() { return hitPoints; }
        public ShieldState getShieldState() { return shieldState; }

        // SET methods

        public void setShieldState(ShieldState shieldState) { this.shieldState = shieldState; }
        public void setHitPoints(int hitPoints) { this.hitPoints = hitPoints; }

        /// <summary>
        /// HITPOINTS is reduced with damage
        /// </summary>
        public void isHit(int damage)
        {

            if(hitPoints <= 0)
            {
                shieldState = ShieldState.Unpowered;
            }
            else
            {
                hitPoints -= damage;
            }
        }

        /// <summary>
        /// POWER SHIELD
        /// </summary>
        public bool powerShield(bool shieldButtonPressed, float deltaTime)
        {

            if (shieldState == ShieldState.Unpowered || shieldState == ShieldState.Powered)
            {
                // If player presses shield button
                if (shieldLoadActivator.activateDeactivateOnRelease(shieldButtonPressed))
                {
                    shieldState = ShieldState.Unpowered; // Shield activates
                    return true;
                }
                else
                {
                    shieldState = ShieldState.Powered;
                }
            }
            return false;
        }
    }
}
