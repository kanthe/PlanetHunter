﻿/*******************************************************************************************************/
// File:    FuryMode.cs
// Summary: 
// Version: Version 1.0 - 2016-05-13
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-05-13 Created by Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using System;

namespace Model
{
    public enum FuryState { OffPlayer, NotLoaded, Loaded, Active }

    class FuryMode
    {
        float furyLoadTime = 5.0f;
        float furyDurationTime = 10.0f;

        FuryState furyState;
        Timer furyLoadTimer; // Counts down load time
        Timer furyDurationTimer;
        Activator furyActivator; // Used to fire missile at one key stroke
        public bool sound = false;
        int countDownState = 0; // Determines which circle section should be drawn in the countdown bar

        public FuryMode()
        {
            // furyState = FuryState.OffPlayer;
            furyState = FuryState.OffPlayer;
            furyLoadTimer = new Timer(furyLoadTime);
            furyDurationTimer = new Timer(furyDurationTime);
            furyActivator = new Activator(0);
        }

        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        public FuryState getFuryState() { return furyState; }
        public float getFuryLoadTime() { return furyLoadTime; }
        public float getFuryDurationTime() { return furyDurationTime; }
        public int getCountDownState() { return countDownState; }

        /// <summary>
        /// SET METHODS
        /// </summary>
        /// 
        public void setFuryLoadTime(float furyLoadTime) { this.furyLoadTime = furyLoadTime; }
        public void setFuryLoadTimer()
        {
            furyLoadTimer.setTimer(furyLoadTime);
        }
        public void setFuryState(FuryState furyState) { this.furyState = furyState; }

        /// <summary>
        /// POWER FURYMODE
        /// </summary>
        public bool powerFuryMode(bool furyButtonPressed, float deltaTime)
        {
            if (furyState != FuryState.OffPlayer)
            {

                switch (furyState)
                {
                    case FuryState.NotLoaded:
                        bool loaded = furyLoadTimer.runTimer(deltaTime);

                        if (furyLoadTimer.getTimer() > (countDownState + 1) * furyLoadTime / 4)
                        {
                            countDownState++;
                        }
                        if (loaded)
                        {
                            countDownState = 4;
                            furyState = FuryState.Loaded;
                            furyLoadTimer.resetTimer();
                        }
                        break;
                    case FuryState.Loaded:
                        if (furyActivator.activeOneTimeStep(furyButtonPressed))
                        {
                            countDownState = 0;
                            furyState = FuryState.Active;
                        }
                        break;
                    case FuryState.Active:
                        bool timesUp = furyDurationTimer.runTimer(deltaTime);

                        if (furyDurationTimer.getTimer() > (countDownState + 1) * furyDurationTime / 4)
                        {
                            countDownState++;
                        }
                        if (timesUp)
                        {
                            countDownState = 0;
                            furyState = FuryState.NotLoaded;
                            furyDurationTimer.resetTimer();
                        }
                        else
                        {
                            return true;
                        }
                        break;
                }
            }
            return false;
        }
    }
}
