﻿/*******************************************************************************************************/
// File:    StarDestroyer.cs
// Summary: Boss
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class StarDestroyer : EnemyTemplate
    {
        
        /// <summary>
        /// CONSTRUCTOR: Setting all fields, implemented in base class.
        /// </summary>
        /// <param name="player">The player</param>
        /// <param name="position">Position of enemy</param>
        public StarDestroyer(Player player, Vector2 position)
        {
            setPlayer(player);
            // DESTROYER
            setPosition(position);
            setRotationSpeed(0.01f);
            setSpeed(0.08f);
            setDiameter(0.5f);
            setColor(Color.Gray);
            setType(EnemyType.Destroyer);
            setHitPoints(5000);
            setMaxHitPoints(hitPoints);
            // BEAM
            setBeamSpeed(0.3f);
            setBeamDiameter(25);
            setBeamColor(Color.YellowGreen);
            // Setting a beam interval slightly random so that it is qnique for every enemy, 
            // preventing high noise because many enemies fire in unison
            setBeamInterval(0.5f + 0.5f / 10 * ((float)Geometry.rand.NextDouble()));
            setBeamActivator(beamInterval);
            setBeamDamage(20);

        }

        // IMPLENEMTING SET METHODS FROM BASE CLASS

        public override void setPlayer(Player player) { this.player = player; }
        // ENEMY
        public override void setPosition(Vector2 position) { this.position = position; }
        public override void setAngle(float angle) { this.angle = angle; } // Set in base class to random number between 0 and 2 * PI
        public override void setRotationSpeed(float rotationSpeed) { this.rotationSpeed = rotationSpeed; }
        public override void setSpeed(float speed) { this.speed = speed; }
        public override void setDiameter(float diameter) { this.diameter = diameter; }
        public override void setColor(Color color) { this.color = color; } // Set in base class to gray
        public override void setType(EnemyType type) { this.type = type; }
        public override void setHitPoints(int hitpoints) { this.hitPoints = hitpoints; }
        public override void setMaxHitPoints(int maxHitpoints) { this.maxHitPoints = maxHitpoints; }
        // BEAMS
        public override void setBeamSpeed(float beamSpeed) { this.beamSpeed = beamSpeed; } // Set in base class to 0.5
        public override void setBeamDiameter(int beamSize) { this.beamDiameter = beamSize; }
        public override void setBeamColor(Color beamColor) { this.beamColor = beamColor; }
        public override void setBeamInterval(float beamInterval) { this.beamInterval = beamInterval; }
        public override void setBeamActivator(float beamInterval) { beamActivator.getTimer().setTimer(beamInterval); }
        public override void setBeamDamage(int beamDamage) { this.beamDamage = beamDamage; }
    }
}
