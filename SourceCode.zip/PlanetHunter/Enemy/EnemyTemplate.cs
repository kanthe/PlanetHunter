﻿/*******************************************************************************************************/
// File:    EnemyTemplate.cs
// Summary: Abstract class used as base class for all enemy types. Defining abstract set methods, 
// ensuring certain properties of an enemy type.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
// Log:2016-06-04 - 2016-06-05 Added EnemyType: Teleporter, Lurker, Joker and Tractor. Robin Kanthe
// Log:2016-06-12 Refined functionality for EnemyType: Teleporter. Robin Kanthe
// Log:2016-06-13 Added EnemyType: Carrier and BattleShip. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using View;
using System;

namespace Model
{
    public enum EnemyType { Class1, Class2, Class3, Teleporter, Lurker, Joker, Tractor, DefenceStation, Destroyer, BattleShip, Carrier }

    abstract class EnemyTemplate
    {
        // 
        protected Player player;
        protected Vector2 position; // Position of the enemy in model coordinates
        public Vector2 startPosition = new Vector2(0, 0);
        protected float angle = 0; // Angle for Enemy's direction in radians
        protected float rotationSpeed;
        protected float speed; // Speed in pixels per gametime step
        protected float diameter = 0.1f; // Radius of the enemy
        protected Color color = Color.Gray; // Color of the enemy
        protected EnemyType type;
        protected int hitPoints; // Enemies hitpoints
        protected int maxHitPoints;
        protected bool didEnemyCrash = false; // True if Player collides with this enemy
        protected Movement movement = new Movement();

        // BEAMS
        protected float beamSpeed = 0.2f; // Speed of beams in modelunits per second
        protected int beamDiameter = 5; // Size of beams in pixels
        protected Color beamColor; // Color of beams
        protected int beamDamage; // Damage caused by the beam
        protected float beamInterval = 1.0f; // Time interval between each fire
        protected Activator beamActivator = new Activator(0);
        protected float timeSinceLastBeam = 0;

        // TELEPORTER
        protected Timer teleportTimer = new Timer(2.0f);
        public EventListener visibleListener;

        // JOKER
        protected Timer jokerTimer = new Timer(1.0f);
        protected Timer jokerDurationTimer = new Timer(0.5f);
        protected float jokerAngle = (float)Geometry.rand.NextDouble() * 2 * Geometry.PI;
        protected Vector2 jokerDirection;

        // LURKER
        protected float lurkerDiameter = 0.075f;
        protected float lurkerSpeed = 0.05f;
        protected int lurkerBeamDiameter = 15;
        protected int lurkerBeamDamage = 20;
        protected float lurkerTime = (float)Geometry.rand.NextDouble() * 1.0f + 3.0f;
        protected float lurkerDurationTime = (float)Geometry.rand.NextDouble() * 2.0f + 2.0f;
        protected Timer lurkerTimer = new Timer(0);
        protected Timer lurkerDurationTimer = new Timer(0);

        // TRACTOR
        protected float pullFactor = 0.0005f;

        // CARRIER
        protected Timer carrierTimer = new Timer((float)Geometry.rand.NextDouble() + 4.0f);
        
        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        public Vector2 getPosition() { return position; }
        public float getAngle() { return angle; }
        public float getRotationSpeed() { return rotationSpeed; }
        public float getSpeed() { return speed; }
        public float getDiameter() { return diameter; }
        public Color getColor() { return color; }
        public EnemyType getType() { return type; }
        public int getHitPoints() { return hitPoints; }
        public int getMaxHitPoints() { return maxHitPoints; }
        public Movement getMovement() { return movement; }
        public bool getDidPlayerCrash() { return didEnemyCrash; }

        public int getBeamDamage() { return beamDamage; }

        public Timer getJokerDurationTimer() { return jokerDurationTimer; }
        public Timer getJokerTimer() { return jokerTimer; }

        /// </summary>
        /// SET METHODS. Abstract methods that sets all parameters not implemented in this abstract base class.
        /// </summary>
        public abstract void setPlayer(Player player);
        // ENEMY
        public abstract void setPosition(Vector2 position);
        public abstract void setAngle(float angle);
        public abstract void setRotationSpeed(float rotationSpeed);
        public abstract void setSpeed(float speed);
        public abstract void setDiameter(float radius);
        public abstract void setColor(Color color);
        public abstract void setHitPoints(int hitpoints);
        public abstract void setMaxHitPoints(int maxHitpoints);
        // BEAMS
        public abstract void setBeamSpeed(float beamSpeed);
        public abstract void setBeamDiameter(int beamSize);
        public abstract void setBeamColor(Color beamColor);
        public abstract void setType(EnemyType type);
        public abstract void setBeamDamage(int beamDamage);
        public abstract void setBeamInterval(float beamInterval);
        public abstract void setBeamActivator(float beamInterval);

        // WEAPONS

        // Fireing one beam and reseting beam timer, 
        // if timer reaches the interval between each beam
        public bool shootBeams(System.Collections.Generic.List<BeamModel> enemyBeams, float deltaTime)
        {
            bool didEnemyShootBeam = false;
            Vector2 beamPosition = position;
            Vector2 directionToPlayer = -new Vector2(beamPosition.X - player.getPosition().X, beamPosition.Y - player.getPosition().Y);
            float distanceToPlayer = Geometry.AbsoluteValue(directionToPlayer);
            directionToPlayer.Normalize();

            if (distanceToPlayer < 1.0f) {
                if (beamActivator.activeOnInterval(true, deltaTime))
                {
                    enemyBeams.Add(new BeamModel(beamPosition, directionToPlayer, beamSpeed, beamDiameter, beamColor, beamDamage));

                    // BattleShip and Carrier fires extra beams
                    if (type == EnemyType.BattleShip || type == EnemyType.Carrier)
                    {
                        enemyBeams.Add(new BeamModel(beamPosition + new Vector2(-Geometry.AngleToDirection(angle).X, Geometry.AngleToDirection(angle).Y) * 0.1f, directionToPlayer, beamSpeed, beamDiameter, Color.Red, beamDamage));
                        enemyBeams.Add(new BeamModel(beamPosition + new Vector2(Geometry.AngleToDirection(angle).X, -Geometry.AngleToDirection(angle).Y) * 0.1f, directionToPlayer, beamSpeed, beamDiameter, Color.Red, beamDamage));
                    }
                    didEnemyShootBeam = true;
                }
            }
            return didEnemyShootBeam;
        }

        /// <summary>
        /// ENEMY DAMAGED/DESTROYED
        /// </summary>
        public void crash()
        {
            hitPoints -= 50;
        }

        public void isHit(int damage)
        {
            hitPoints -= damage;
        }

        /// <summary>
        /// TELEPORT
        /// </summary>
        public void teleport(float deltaTime)
        {
            float xDisp = 0;
            float yDisp = 0;
            float distanceToPlayer = 0;


            if (teleportTimer.runTimer(deltaTime) && Geometry.AbsoluteValue(player.getPosition() - position) < 0.5f)
            {
                while (distanceToPlayer < 0.05 || distanceToPlayer > 0.5)
                {
                    // Values between -0.5 and 0.5
                    xDisp = (float)Geometry.rand.NextDouble() - 0.5f;
                    yDisp = (float)Geometry.rand.NextDouble() - 0.5f;
                    Vector2 displacement = new Vector2(xDisp, yDisp);
                    position = player.getPosition() + displacement;
                    distanceToPlayer = Geometry.AbsoluteValue(displacement);
                }
                visibleListener.StartVisibilityAnimation();
                this.setPosition(position);
                teleportTimer.resetTimer();
            }
            visibleListener.AnimateVisibility();
        }

        /// <summary>
        /// JOKER
        /// </summary>
        public void moveJoker(float borderRadius, float deltaTime)
        {
            angle = jokerAngle;
            position = movement.move(position, speed, jokerDirection, borderRadius, deltaTime);
        }

        public void newJokerDirection()
        {
            jokerAngle = (float)Geometry.rand.NextDouble() * 2 * Geometry.PI;
            jokerDirection = Geometry.AngleToDirection(jokerAngle);
            jokerDirection.Normalize();
            jokerTimer.resetTimer();
            jokerTimer.setTimer((float)Geometry.rand.NextDouble() * 2 + 1.0f);
            jokerDurationTimer.resetTimer();
            jokerDurationTimer.setTimer((float)Geometry.rand.NextDouble() * 1.0f);
        }

        /// <summary>
        /// LURKER
        /// </summary>
        public void setInvisible(float deltaTime)
        {
            if (lurkerTimer.runTimer(deltaTime))
            {
                setDiameter(0);
                setSpeed(0);
                setBeamDiameter(0);
                setBeamDamage(0);

                if (lurkerDurationTimer.runTimer(deltaTime))
                {
                    setVisible();
                }
            }
            visibleListener.AnimateVisibility();
        }
        public void setVisible()
        {
            setDiameter(lurkerDiameter);
            setSpeed(lurkerSpeed);
            setBeamDiameter(lurkerBeamDiameter);
            setBeamDamage(lurkerBeamDamage);
            lurkerTimer.resetTimer();
            lurkerTimer.setTimer(lurkerTime);
            lurkerDurationTimer.resetTimer();
            lurkerDurationTimer.setTimer(lurkerDurationTime);
            visibleListener.StartVisibilityAnimation();
        }

        /// <summary>
        /// TRACTOR
        /// </summary>
        public void pullPlayer()
        {
            if (Geometry.AbsoluteValue(player.getPosition() - position) < 0.5f)
            {
                Vector2 direction = player.getPosition() - position;
                direction.Normalize();
                player.setPosition(player.getPosition() - direction * pullFactor);
            }
        }
        /// <summary>
        /// CARRIER
        /// </summary>
        public Class1Enemy createInterceptor(float deltaTime)
        {
            if (carrierTimer.runTimer(deltaTime))
            {
                Vector2 interceptorStartPosition = position + new Vector2(((float)Geometry.rand.NextDouble() - 0.5f) * 0.2f, ((float)Geometry.rand.NextDouble() - 0.5f) * 0.2f);
                carrierTimer.resetTimer();
                return new Class1Enemy(player, interceptorStartPosition);
            }
            else
            {
                return null;
            }
        }
    }
}