﻿/*******************************************************************************************************/
// File:    EnemyView.cs
// Summary: Drawing enemies
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
// Log:2016-06-10 Added drawVisibility method. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class EnemyView
    {
        Camera camera;
        GraphicsDevice device;
        Texture2D class1EnemyTexture;
        Texture2D class2EnemyTexture;
        Texture2D class3EnemyTexture;
        Texture2D destroyerTexture;
        Texture2D defenceStationTexture;
        Texture2D teleporterTexture;
        Texture2D lurkerTexture;
        Texture2D jokerTexture;
        Texture2D tractorTexture;
        Texture2D carrierTexture;
        Texture2D battleShipTexture;

        Vector2 textureSize = new Vector2(128.0f, 128.0f);

        // TRACTOR: Beam
        public static readonly int beamThickness = 15;
        Color beamColor = Color.White;
        Texture2D tractorBeamTexture;
        System.Collections.Generic.List<Vector2> beamFlashPositions = new System.Collections.Generic.List<Vector2>();
        Timer beamFlashTimer = new Timer(10.0f);

        // LURKER and TELEPORTER: Animation
        Texture2D visibilityTextures;
        Vector2[] visibilityTiles;
        int visibilityTileWidth = 182;

        public EnemyView(int scale, GraphicsDevice device, ContentManager content)
        {
            camera = GameView.camera;

            // Images used below are made by C-TOY
            // h ttp://opengameart.org/content/126-2d-spaceships Thanks C-TOY
            class1EnemyTexture = content.Load<Texture2D>("Class1Enemy"); // Texture for the class 1 type enemies
            class2EnemyTexture = content.Load<Texture2D>("Class2Enemy"); // Texture for the class 2 type enemies
            class3EnemyTexture = content.Load<Texture2D>("Class3Enemy"); // Texture for the class 3 type enemies
            destroyerTexture = content.Load<Texture2D>("Destroyer"); // Texture for the destroyer type enemies
            defenceStationTexture = content.Load<Texture2D>("Defence_station"); // Texture for the defence station type enemies
            jokerTexture = content.Load<Texture2D>("Joker"); // Texture for the defence station type enemies
            tractorTexture = content.Load<Texture2D>("Tractor"); // Texture for the defence station type enemies
            carrierTexture = content.Load<Texture2D>("Carrier"); // Texture for the carrier type enemies
            battleShipTexture = content.Load<Texture2D>("Battle_ship"); // Texture for the carrier type enemies
            // h ttp://findicons.com/icon/132532/battlestar_galactica
            teleporterTexture = content.Load<Texture2D>("battlestar_galactica"); // Texture for the defence station type enemies
            // h ttp://findicons.com/icon/132532/battlestar_galactica
            lurkerTexture = content.Load<Texture2D>("battlestar_galactica"); // Texture for the defence station type enemies

            visibilityTextures = content.Load<Texture2D>("visibility"); // Texture tiles for the visibility
            visibilityTiles = new Vector2[24];
            int k = 0;
            
            for(int j = 5; j >= 0; j--) {
                for (int i = 3; i >= 0; i--)
                {
                    visibilityTiles[k] = new Vector2(10 + i * 10.0f + i * (float)visibilityTileWidth, 10 + j * 10.0f + j * (float)visibilityTileWidth);
                    k++;
                }
            }

            // TRACTOR beam
            tractorBeamTexture = content.Load<Texture2D>("tractorbeam"); // Texture for the carrier type enemies
            this.device = device;
        }

        /// <summary>
        /// Draws the enemy
        /// </summary>
        public void DrawEnemies(System.Collections.Generic.List<EnemyTemplate> enemies, SpriteBatch spriteBatch)
        {

            foreach (EnemyTemplate enemy in enemies)
            {
                int viewDiameter = camera.scaleObject(enemy.getDiameter()); // Diameter of the enemy
                // The position calculation is done in the camera class
                Vector2 viewPosition = camera.modelPositionToViewPosition(enemy.getPosition());
                EnemyType type = enemy.getType();
                Texture2D texture = class1EnemyTexture;
                float angle = enemy.getAngle();

                switch (type)
                {
                    case EnemyType.Class1:
                        texture = class1EnemyTexture;
                        break;
                    case EnemyType.Class2:
                        texture = class2EnemyTexture;
                        break;
                    case EnemyType.Class3:
                        texture = class3EnemyTexture;
                        break;
                    case EnemyType.DefenceStation:
                        texture = defenceStationTexture;
                        break;
                    case EnemyType.Teleporter:
                        texture = teleporterTexture;
                        break;
                    case EnemyType.Lurker:
                        texture = lurkerTexture;
                        break;
                    case EnemyType.Joker:
                        texture = jokerTexture;
                        break;
                    case EnemyType.Tractor:
                        texture = tractorTexture;
                        break;
                    case EnemyType.Destroyer:
                        texture = destroyerTexture;
                        break;
                    case EnemyType.Carrier:
                        texture = carrierTexture;
                        break;
                    case EnemyType.BattleShip:
                        texture = battleShipTexture;
                        break;
                }
                Color color = Color.Red;
                Rectangle destinationRectangle = new Rectangle((int)viewPosition.X, (int)viewPosition.Y, viewDiameter, viewDiameter);
                Vector2 origin = textureSize / 2;

                if (enemy.getType() == EnemyType.DefenceStation)
                {
                    origin = new Vector2(175, 165);
                }

                // Drawing the enemy

                if ((int)viewPosition.X > -GameView.WINDOWSIZE.X * 0.1f && (int)viewPosition.X < GameView.WINDOWSIZE.X * 1.1f && (int)viewPosition.Y > -GameView.WINDOWSIZE.Y * 0.1f && (int)viewPosition.Y < GameView.WINDOWSIZE.Y * 1.1f)
                {
                    spriteBatch.Draw(texture, destinationRectangle, null, enemy.getColor(), enemy.getAngle(), origin, SpriteEffects.None, 0);
                }
            }
        }

        /// <summary>
        /// TELEPORTER and LURKER: Draws the visibility animation. Activated each gametime step.
        /// </summary>
        public void DrawVisibility(EnemyTemplate enemy, SpriteBatch spriteBatch)
        {
            Vector2 enemyViewPosition = camera.modelPositionToViewPosition(enemy.getPosition());
            int viewDiameter = camera.scaleObject(enemy.getDiameter()); // Diameter of the enemy
            Rectangle destinationRectangle = new Rectangle((int)enemyViewPosition.X, (int)enemyViewPosition.Y, viewDiameter, viewDiameter);
            Vector2 origin = new Vector2(visibilityTileWidth / 2, visibilityTileWidth / 2);
            Vector2 viewPosition = camera.modelPositionToViewPosition(enemy.getPosition());
                    
            spriteBatch.Draw(
                visibilityTextures,
                destinationRectangle,
                new Rectangle((int)visibilityTiles[enemy.visibleListener.visibleFrameNumber].X, (int)visibilityTiles[enemy.visibleListener.visibleFrameNumber].Y, visibilityTileWidth, visibilityTileWidth),
                Color.White,
                enemy.getAngle(),
                origin,
                SpriteEffects.None,
                0
                );
        }

        /// <summary>
        /// TRACTOR: Draws the tractor beam between enemy and player
        /// </summary>
        public void DrawTractorBeam(int scale, SpriteBatch spriteBatch, EnemyTemplate enemy, Player player, float deltaTime)
        {
            float viewDiameter = camera.scaleObject(enemy.getDiameter()); // Diameter of the enemy
            Vector2 enemyPosition = enemy.getPosition() + new Vector2(enemy.getDiameter() / 4, enemy.getDiameter() / 4);
            Vector2 direction = enemyPosition - player.getPosition();
            float distanceToPlayer = Geometry.AbsoluteValue(direction);
            direction.Normalize();
            Vector2 segmentPosition = camera.modelPositionToViewPosition(enemyPosition - new Vector2(enemy.getDiameter() / 2, enemy.getDiameter() / 2));
            Vector2 origin = new Vector2(-285, -107);

            // 
            while (Geometry.AbsoluteValue(segmentPosition - camera.modelPositionToViewPosition(player.getPosition())) > 100 && distanceToPlayer < 0.5f)
            {
                segmentPosition -= direction * 5;

                int colorNumber = (int)(Geometry.rand.NextDouble() * 4);

                switch (colorNumber)
                {
                    case 0:
                        beamColor = Color.White;
                        break;
                    case 1:
                        beamColor = Color.Yellow;
                        break;
                    case 2:
                        beamColor = Color.Red;
                        break;
                    case 3:
                        beamColor = Color.Yellow;
                        break;

                }

                spriteBatch.Draw(
                        tractorBeamTexture,
                        new Rectangle((int)segmentPosition.X, (int)segmentPosition.Y, beamThickness, beamThickness),
                        null,
                        beamColor,
                        0,
                        origin,
                        SpriteEffects.None,
                        0
                        );
            }
            
            
            
        }
        
    }
}
