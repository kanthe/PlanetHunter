﻿/*******************************************************************************************************/
// File:    Player.cs
// Summary: Model representation of the player. Also includes methods for crasching, taking damage and 
// landing on planet
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model 
{
    /// <summary>
    /// The player with properties position, speed, diretion and radius.
    /// 
    /// </summary>
    class Player
    {
        public static readonly int STARTING_HITPOINTS = 100;
        public static readonly float LANDING_TIME = 3.0f;
        public static float ROTATION_SPEED = 0.075f;
        public static float ACCELERATION = 0.01f;
        public static readonly float MAX_SPEED = 0.1f;
        public static readonly float MIN_SPEED = 0.0f;
        public static readonly float DIAMETER = 0.03f; // Diameter of the player
        public static Color COLOR = Color.White;
        public static readonly BeamWeapon BEAM_WEAPON = new BeamWeapon(Color.Yellow);
        public static readonly MissileWeapon MISSILE_WEAPON = new MissileWeapon();
        public static readonly Shield SHIELD = new Shield();
        public static readonly FuryMode FURY_MODE = new FuryMode();
        
        Movement movement; // Object to handle movement including accelerating, turning, etc. (not constant because of cheat)
        Vector2 position; // Position of the player in model coordinates
        float angle; // Angle for the pointing direction in radians
        float speed; // Speed in pixels per gametime step
        Vector2 direction; // Moving direction
        int minHitPoints = 0; // Minimum hitpoints (not constant because of cheat)
        int hitPoints;
        Activator landActivator; // Is activated when player is landing
        public bool interuptLanding = false;
        /// <summary>
        /// Constructor: Sets the fields
        /// </summary>
        public Player(Vector2 position)
        {
            hitPoints = STARTING_HITPOINTS;
            this.position = position;
            angle = (float)(Geometry.rand.NextDouble() * 2 * System.Math.PI);
            speed = MIN_SPEED;
            // Trigonometric calculation of the starting direction
            direction = Geometry.AngleToDirection(angle);
            movement = new Movement(ACCELERATION, MIN_SPEED, MAX_SPEED, ROTATION_SPEED);
            landActivator = new Activator(LANDING_TIME);
        }
        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        /// <returns></returns>
        public Vector2 getPosition() { return position; }
        public Vector2 getDirection() { return direction; }
        public float getSpeed() { return speed; }
        public float getAngle() { return angle; }
        public int getMinHitPoints() { return minHitPoints; }
        public int getHitPoints() { return hitPoints; }
        // Used be gameController to move or turn the player as reaction to a key stroke
        public Movement getMovement() { return movement; }
        
        // SET METHODS
        
        /// <summary>
        /// Setting the position
        /// </summary>
        /// <param name="position"></param>
        public void setMovement(Movement movement) { this.movement = movement; }
        public void setPosition(Vector2 position) { this.position = position; }
        public void setDirection(Vector2 direction) { this.direction = direction; }
        public void setSpeed(float speed) { this.speed = speed; }
        public void setAngle(float angle) { this.angle = angle; }
        public void setHitPoints(int hitPoints) { this.hitPoints = hitPoints; }
        public void setMinHitPoints(int minHitPoints) { this.minHitPoints = minHitPoints; }

        // CRASH

        public void crash()
        {
            hitPoints -= 50;
        }

        // Take DAMAGE

        public void isHit(int damage)
        {
            // Shield damage
            if (SHIELD.getShieldState() == ShieldState.Powered)
            {
                SHIELD.isHit(damage);
            }
            // Normal damage
            else
            {
                hitPoints -= damage;
            }
        }

        // WEAPONS

        // Returns true if beam is fired
        // Used by gameController to activate beam when beam button is pressed
        public bool shootBeams(bool fireButtonPressed, float deltaTime) 
        {
            return BEAM_WEAPON.fire(fireButtonPressed, deltaTime, position, angle);
        }

        // Returns true if missile is fired
        // Used by gameController to activate misslie when missile button is pressed
        public bool launchMissile(bool fireButtonPressed, float deltaTime)
        {
            return MISSILE_WEAPON.launch(fireButtonPressed, deltaTime, position, angle);
        }

        // LAND ON PLANET

        public bool landOnPlanet(Planet planet, bool keyPressed, float deltaTime)
        {
            bool playerOverPlanet = false;
            // If player is over the planet and planet is landable
            if (Geometry.IsInsideCircle(position, DIAMETER, planet.getPosition(), planet.getDiameter()))
            {
                playerOverPlanet = true;
            }
            else
            {
                playerOverPlanet = false;
            }
            switch (planet.getLandingStatus())
            {
                case LandingStatus.NotLandable:
                    break;
                case LandingStatus.Landable:
                    if (playerOverPlanet) { planet.setLandingStatus(LandingStatus.PlayerOverPlanet); }
                    break;
                case LandingStatus.PlayerOverPlanet:

                    if (playerOverPlanet)
                    {
                        if (keyPressed)
                        {
                            planet.setLandingStatus(LandingStatus.PlayerIsLanding);
                        }
                    }
                    else { planet.setLandingStatus(LandingStatus.Landable); }
                    break;
                case LandingStatus.PlayerIsLanding:
                    
                    if (playerOverPlanet && keyPressed)
                    {
                        bool landed = planet.getLandTimer().runTimer(deltaTime);

                        if (planet.getLandTimer().getTimer() > (planet.countDownState + 1) * LANDING_TIME / 4)
                        {
                            planet.countDownState++;
                        }
                        if (landed)
                        {
                            planet.setLandingStatus(LandingStatus.PlayerHasLanded);

                            // Player gets a new ability if such is avilable on the planet
                            switch (planet.getPower())
                            {
                                case PlanetPower.HpRestore:
                                    hitPoints = 100;
                                    break;
                                case PlanetPower.BeamEnhance:
                                    BEAM_WEAPON.setBeamDamage(15);
                                    BEAM_WEAPON.setBeamColor(Color.Orange);
                                    break;
                                case PlanetPower.AutoFire:
                                    BEAM_WEAPON.setAutoFireState(AutoFireState.NotLoaded);
                                    break;
                                case PlanetPower.Missile:
                                    MISSILE_WEAPON.setMissileState(MissileState.NotLoaded);
                                    break;
                                case PlanetPower.Shield:
                                    SHIELD.setShieldState(ShieldState.Unpowered);
                                    break;
                                case PlanetPower.ShieldRestore:
                                    SHIELD.setHitPoints(SHIELD.STARTING_HITPOINTS);
                                    break;
                                case PlanetPower.Fury:
                                    FURY_MODE.setFuryState(FuryState.NotLoaded);
                                    break;
                                case PlanetPower.FuryEnhance:
                                    FURY_MODE.setFuryLoadTime(3.0f);
                                    FURY_MODE.setFuryLoadTimer();
                                    break;
                            }
                            // and true is returned, telling gameController in this case, that player has landed!
                            return true;
                        }
                    }
                    else if (playerOverPlanet)
                    {
                        planet.countDownState = 0;
                        planet.resetLandTimer();
                        planet.setLandingStatus(LandingStatus.PlayerOverPlanet);
                        interuptLanding = true;
                    }
                    else
                    {
                        planet.countDownState = 0;
                        planet.resetLandTimer();
                        planet.setLandingStatus(LandingStatus.Landable);
                        interuptLanding = true;
                    }
                    break;
            }
            return false;
        }
    }
}
