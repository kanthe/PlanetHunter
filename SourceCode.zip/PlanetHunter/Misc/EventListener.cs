﻿/*******************************************************************************************************/
// File:    EventListener.cs
// Summary: Creates and draws the autofirebar.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;
using Model;

namespace View
{
    class EventListener
    {

        int scale;
        GraphicsDevice device;
        ContentManager content;
        Messages messages;
        // ANIMATIONS
        System.Collections.Generic.List<Explosion> explosions; // List of explosions
        float explosionDuration = 1.0f; // The time an explosion flare series is completed.
        int explosionNumber = 0; // Number of explosions.
        int shieldDeltaTimeNumber = 0;
        public int shieldFrameNumber = 0;
        int shieldDeltaTimesPerFrame = 2;
        public int shieldNumberOfFrames = 24;
        int visibleDeltaTimeNumber = 0;
        public int visibleFrameNumber = 23;
        int visibleDeltaTimesPerFrame = 3;
        public int visibleNumberOfFrames = 24;
        System.Collections.Generic.List<SmokeView> smokeViewList; // List of smoke
        System.Collections.Generic.List<SmokeSystem> smokeSystemList; // List of smoke
        // SOUNDS
        SoundEffect messageSound;
        SoundEffectInstance messageSoundInstance;
        SoundEffect explosionSmallSound;
        SoundEffect explosionSound;
        SoundEffect explosionBigSound;
        SoundEffect playerBeamSound;
        SoundEffect playerHitSound;
        SoundEffect enemy1BeamSound;
        SoundEffect enemy2BeamSound;
        SoundEffect enemyTeleporterBeamSound;
        SoundEffect enemyTractorBeamSound;
        SoundEffect enemyLurkerBeamSound;
        SoundEffect enemyStationBeamSound;
        SoundEffect enemyBossBeamSound;
        SoundEffect missileSound;
        SoundEffect playerGasSound;
        SoundEffect shieldSound;
        SoundEffect furySound;
        SoundEffect playerLandingSound;
        SoundEffectInstance playerLandingSoundInstance;
        SoundEffect menuToggleSound;
        SoundEffectInstance menuToggleSoundInstance;

        public EventListener(int scale, GraphicsDevice device, ContentManager content, Messages messages)
        {
            this.scale = scale;
            this.device = device;
            this.content = content;
            this.messages = messages;
            // ANIMATIONS
            explosions = new System.Collections.Generic.List<Explosion>();
            smokeViewList = new System.Collections.Generic.List<SmokeView>(); // List of smoke
            smokeSystemList = new System.Collections.Generic.List<SmokeSystem>(); // List of smoke
            // SOUNDS
            messageSound = content.Load<SoundEffect>("message_signal"); // Sound effect
            messageSoundInstance = messageSound.CreateInstance();
            explosionSmallSound = content.Load<SoundEffect>("Explosion-02"); // Sound effect
            explosionSound = content.Load<SoundEffect>("Explosion-04"); // Sound effect
            explosionBigSound = content.Load<SoundEffect>("Explosion-04-long"); // Sound effect
            playerBeamSound = content.Load<SoundEffect>("playerlaser"); // Sound effect
            playerHitSound = content.Load<SoundEffect>("playerhit"); // Sound effect
            enemy1BeamSound = content.Load<SoundEffect>("enemy1laser"); // Sound effect
            enemy2BeamSound = content.Load<SoundEffect>("enemy2laser"); // Sound effect
            enemyTeleporterBeamSound = content.Load<SoundEffect>("enemyteleporterlaser"); // Sound effect
            enemyLurkerBeamSound = content.Load<SoundEffect>("enemylurkerlaser"); // Sound effect
            enemyTractorBeamSound = content.Load<SoundEffect>("enemytractorlaser"); // Sound effect
            enemyStationBeamSound = content.Load<SoundEffect>("enemystationlaser"); // Sound effect
            enemyBossBeamSound = content.Load<SoundEffect>("enemybosslaser"); // Sound effect
            missileSound = content.Load<SoundEffect>("playermissile"); // Sound effect
            playerGasSound = content.Load<SoundEffect>("gas"); // Sound effect
            shieldSound = content.Load<SoundEffect>("shieldsound"); // Sound effect
            furySound = content.Load<SoundEffect>("furysound"); // Sound effect
            playerLandingSound = content.Load<SoundEffect>("landing"); // Sound effect
            playerLandingSoundInstance = playerLandingSound.CreateInstance();
            menuToggleSound = content.Load<SoundEffect>("menutoggle"); // Sound effect
            menuToggleSoundInstance = menuToggleSound.CreateInstance();
        }

        public Messages getMessages() { return messages; }

        /// <summary>
        /// Creating an explosion object and adding it to a list of such objects. 
        /// </summary>
        public void MakeExplosion(Vector2 position, GameTime explosionStartTime,
            float flareSize, float smokeParticleMaxLifeTime, float smokeParticleMinSize, float smokeParticleMaxSize, float splitterSpeed, float splitterSize)
        {
            explosions.Add(new Explosion(scale, device, content, explosionStartTime, position,
                flareSize, smokeParticleMaxLifeTime, smokeParticleMinSize, smokeParticleMaxSize, splitterSpeed, splitterSize));
            explosionNumber++;
        }
        /// <summary>
        /// Updates explosions.
        /// </summary>
        public void UpdateExplosions(GameTime gameTime, SpriteBatch spriteBatch, float deltaTime)
        {
            // All explosions are updated until the total game time reaches the explosion duration time 
            foreach (Explosion explosion in explosions)
            {
                if ((float)gameTime.TotalGameTime.TotalSeconds - explosion.getExplosionStartTime() < explosionDuration)
                {
                    explosion.Update(deltaTime, spriteBatch);
                }
            }
        }
        public void MakeSmoke(Vector2 position, float smokeParticleMaxLifeTime, float smokeParticleMinSize, float smokeParticleMaxSize)
        {
            SmokeSystem smokeSystem = new SmokeSystem(position, smokeParticleMaxLifeTime, smokeParticleMinSize, smokeParticleMaxSize);
            smokeSystemList.Add(smokeSystem);
            smokeViewList.Add(new SmokeView(smokeSystem, scale, device, content));
        }
        /// <summary>
        /// Updates explosions.
        /// </summary>
        public void UpdateSmoke(SpriteBatch spriteBatch, float deltaTime)
        {
            // All explosions are updated until the total game time reaches the explosion duration time 
            foreach (SmokeSystem smokeSystem in smokeSystemList)
            {
                smokeSystem.updateParticles(deltaTime);
            }
            foreach (SmokeView smokeView in smokeViewList)
            {
                smokeView.DrawSmoke(spriteBatch);
            }
        }
        public void removeSmoke()
        {
            smokeViewList = new System.Collections.Generic.List<SmokeView>();
            smokeSystemList = new System.Collections.Generic.List<SmokeSystem>();
        }
        /// <summary>
        /// GET METHODS
        /// </summary>
        /// <returns></returns>
        public System.Collections.Generic.List<Explosion> getExplosions() { return explosions; }
        public System.Collections.Generic.List<SmokeView> getSmokeViewList() { return smokeViewList; }
        public System.Collections.Generic.List<SmokeSystem> getSmokeSystemList() { return smokeSystemList; }

        // SOUNDS

        public void playMenuToggleSound()
        {
            menuToggleSoundInstance.Volume = 0.25f;
            menuToggleSoundInstance.Play();
        }
        public void playMessageSound()
        {
            messageSoundInstance.Volume = 0.25f;
            messageSoundInstance.Play();
        }
        public void playExplosionSmallSound()
        {
            SoundEffectInstance explosionSmallSoundInstance = explosionSmallSound.CreateInstance();
            explosionSmallSoundInstance.Volume = 0.3f;
            explosionSmallSoundInstance.Play();
        }
        public void playExplosionSound()
        {
            SoundEffectInstance explosionSoundInstance = explosionSound.CreateInstance();
            explosionSoundInstance.Volume = 0.3f;
            explosionSoundInstance.Play();
        }
        public void playExplosionBigSound()
        {
            SoundEffectInstance explosionBigSoundInstance = explosionBigSound.CreateInstance();
            explosionBigSoundInstance.Volume = 0.3f;
            explosionBigSoundInstance.Play();
        }
        public void playPlayerGasSound()
        {
            SoundEffectInstance playerGasSoundInstance = playerGasSound.CreateInstance();
            playerGasSoundInstance.Volume = 0.2f;
            playerGasSoundInstance.Play();
        }
        public void playShieldSound()
        {
            SoundEffectInstance shieldSoundInstance = shieldSound.CreateInstance();
            shieldSoundInstance.Volume = 1.0f;
            shieldSoundInstance.Play();
        }
        public void playFurySound()
        {
            SoundEffectInstance furySoundInstance = furySound.CreateInstance();
            furySoundInstance.Volume = 1.0f;
            furySoundInstance.Play();
        }
        public void playPlayerBeamSound()
        {
            SoundEffectInstance playerBeamSoundInstance = playerBeamSound.CreateInstance();
            playerBeamSoundInstance.Volume = 0.2f;
            playerBeamSoundInstance.Play();
        }

        public void playMissileSound()
        {
            SoundEffectInstance missileSoundInstance = missileSound.CreateInstance();
            missileSoundInstance.Volume = 0.2f;
            missileSoundInstance.Play();
        }
        public void playPlayerHitSound()
        {
            SoundEffectInstance playerHitSoundInstance = playerHitSound.CreateInstance();
            playerHitSoundInstance.Volume = 0.2f;
            playerHitSoundInstance.Play();
        }
        public void playPlayerLandingSound()
        {
            playerLandingSoundInstance.Volume = 0.5f;
            playerLandingSoundInstance.Play();
        }
        public void stopPlayerLandingSound()
        {
            playerLandingSoundInstance.Stop();
        }
        public void playEnemy1BeamSound()
        {
            SoundEffectInstance enemyBeamSoundInstance = enemy1BeamSound.CreateInstance();
            enemyBeamSoundInstance.Volume = 0.15f;
            enemyBeamSoundInstance.Play();
        }
        public void playEnemy2BeamSound()
        {
            SoundEffectInstance enemyBeamSoundInstance = enemy2BeamSound.CreateInstance();
            enemyBeamSoundInstance.Volume = 0.15f;
            enemyBeamSoundInstance.Play();
        }
        public void playEnemyTeleporterBeamSound()
        {
            SoundEffectInstance enemyBeamSoundInstance = enemyLurkerBeamSound.CreateInstance();
            enemyBeamSoundInstance.Volume = 0.15f;
            enemyBeamSoundInstance.Play();
        }
        public void playEnemyLurkerBeamSound()
        {
            SoundEffectInstance enemyBeamSoundInstance = enemyLurkerBeamSound.CreateInstance();
            enemyBeamSoundInstance.Volume = 0.25f;
            enemyBeamSoundInstance.Play();
        }
        public void playEnemyTractorBeamSound()
        {
            SoundEffectInstance enemyBeamSoundInstance = enemyTractorBeamSound.CreateInstance();
            enemyBeamSoundInstance.Volume = 0.25f;
            enemyBeamSoundInstance.Play();
        }
        public void playEnemyStationBeamSound()
        {
            SoundEffectInstance enemyBeamSoundInstance = enemyStationBeamSound.CreateInstance();
            enemyBeamSoundInstance.Volume = 0.15f;
            enemyBeamSoundInstance.Play();
        }
        public void playEnemyBossBeamSound()
        {
            SoundEffectInstance enemyBeamSoundInstance = enemyBossBeamSound.CreateInstance();
            enemyBeamSoundInstance.Volume = 0.1f;
            enemyBeamSoundInstance.Play();
        }

        public bool DisplayMessage(Vector2 position, Message message, SpriteBatch spriteBatch, float deltaTime)
        {
           return messages.show(position, message, spriteBatch, deltaTime);
        }

        public void StartShieldAnimation() 
        {
            shieldFrameNumber = 1;
        }

        public void AnimateShield()
        {
            if (shieldFrameNumber > 0)
            {
                shieldDeltaTimeNumber++;

                if (shieldDeltaTimeNumber == shieldDeltaTimesPerFrame)
                {
                    shieldDeltaTimeNumber = 0;
                    shieldFrameNumber++;
                }

                if (shieldFrameNumber == shieldNumberOfFrames)
                {
                    shieldFrameNumber = 0;
                }
            }
        }

        public void StartVisibilityAnimation()
        {
            visibleFrameNumber = 1;
        }

        public void AnimateVisibility()
        {
            if (visibleFrameNumber > 0)
            {
                visibleDeltaTimeNumber++;

                if (visibleDeltaTimeNumber == visibleDeltaTimesPerFrame)
                {
                    visibleDeltaTimeNumber = 0;
                    visibleFrameNumber++;
                }

                if (visibleFrameNumber == visibleNumberOfFrames)
                {
                    visibleFrameNumber = visibleNumberOfFrames - 1;
                }
            }
        }
    }
}
