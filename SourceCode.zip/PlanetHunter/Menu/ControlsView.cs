﻿/*******************************************************************************************************/
// File:    MenuControls.cs
// Summary: Draws the images which displays info about keyboard controls.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    /// <summary>
    /// Draws the images which displays info about keyboard controls.
    /// </summary>
    class ControlsView
    {
        GraphicsDevice device;
        ContentManager content;
        float scale;
        // Image textures
        Texture2D BackGroundImage;
        Texture2D BackGroundTransparantImage;
        Texture2D HeadlineTexture;
        Texture2D ControlsStearingTexture;
        Texture2D ControlsFireTexture;
        Texture2D ControlsOtherTexture;
        Texture2D ControlsGamePadTexture;
        Texture2D ArrowsTexture;

        public ControlsView(float scale, GraphicsDevice device, ContentManager content)
        {
            // Initiating objects and textures needed to draw the images
            this.device = device;
            this.content = content;
            BackGroundImage = content.Load<Texture2D>("background_image"); // Background image
            BackGroundTransparantImage = content.Load<Texture2D>("background_transparant"); // Background image
            HeadlineTexture = content.Load<Texture2D>("controls_headline");
            // en.wikipedia.org/wiki/Keyboard_layout#/media/File:ANSI_Keyboard_Layout_Diagram_with_Form_Factor.svg
            ControlsStearingTexture = content.Load<Texture2D>("controls_stearing");
            ControlsFireTexture = content.Load<Texture2D>("controls_fire");
            ControlsOtherTexture = content.Load<Texture2D>("skip_level");
            ControlsGamePadTexture = content.Load<Texture2D>("gamepad");
            ArrowsTexture = content.Load<Texture2D>("arrows");
        }
        
        /// <summary>
        /// DRAWING the images. Scale is used so that the menu can look fairly the same in different window sizes
        /// </summary>
        public void Draw( SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            device.Clear(Color.Black); // Setting background color
            spriteBatch.Draw(BackGroundImage, new Vector2(0, 0), Color.White);
            spriteBatch.Draw(BackGroundTransparantImage, new Vector2(0, 0), Color.White);
            spriteBatch.Draw(HeadlineTexture, new Vector2(100, 50), Color.White);
            //Gamepad image
            spriteBatch.Draw(ControlsGamePadTexture, new Vector2(100, 150), Color.White);
            // Stearing image
            spriteBatch.Draw(ControlsStearingTexture, new Vector2(800, 50), Color.White);
            // Fire image
            spriteBatch.Draw(ControlsFireTexture, new Vector2(800, 250), Color.White);
            //Other image
            spriteBatch.Draw(ControlsOtherTexture, new Vector2(800, 500), Color.White);
            spriteBatch.Draw(ArrowsTexture, new Vector2(100, 850), new Rectangle(80, 0, 55, 55), Color.White);
            spriteBatch.End();
        }
    }
}
