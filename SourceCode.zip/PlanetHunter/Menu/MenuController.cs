﻿/*******************************************************************************************************/
// File:    MenuController.cs
// Summary: Initiating the main menu classes menuModel and menuView. Also handles menu choices and players 
// input. It also handles different states of the game before returning it to MaserController.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using View;
using Model;

namespace Controller
{
    class MenuController
    {
        // If menu choice Tutorial Mode is selected. It is handled to masterController and later 
        // gameSimulator, which set it equal to  its own tutorialState
        TutorialState tutorialState = TutorialState.True; 
        GameState gameState = GameState.StartMode; // State of the game (Menu, Continue, ...)
        MenuModel menuModel; // Has some methods MenuController use to handle menu choices
        public MenuView menuView; // Draws the menu
        ControlsView controlsView; // Draws controls screen
        CreditsView creditsView1; // Draws credits screen
        // Activates different keys at one key stroke
        Activator activatorEnter = new Activator(0);
        Activator activatorUp = new Activator(0);
        Activator activatorDown = new Activator(0);
        Activator activatorLeft = new Activator(0);
        Activator activatorRight = new Activator(0);
        SpriteBatch spriteBatch; // Used to draw the menu

        public MenuController(int scale, GraphicsDevice device, ContentManager content)
        {
            menuModel = new MenuModel();
            menuView = new MenuView(menuModel, scale, device, content);
            controlsView = new ControlsView(scale, device, content);
            creditsView1 = new CreditsView(device, content);
            spriteBatch = new SpriteBatch(device);
        }

        // GET METHODS

        public GameState getGameState() { return gameState; }
        public TutorialState getTutorialState() { return tutorialState; }
        public MenuView getMenuView() { return menuView; }

        // SET METHODS

        public void setGameState(GameState gameState) { this.gameState = gameState; }

        // UPDATE

        public GameState Update()
        {
            // Get the current gamepad state.
            GamePadState currentState = GamePad.GetState(PlayerIndex.One);
            // ENTER, UP, and DOWN key uses an Activator to not do a series of actions at one key stroke by user
            bool activateEnter = activatorEnter.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Enter) || currentState.IsConnected && currentState.Buttons.A == ButtonState.Pressed);
            bool activateUp = activatorUp.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Up) || currentState.IsConnected && currentState.ThumbSticks.Left.Y > 0.2f);
            bool activateDown = activatorDown.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Down) || currentState.IsConnected && currentState.ThumbSticks.Left.Y < -0.2f);
            bool activateLeft = activatorLeft.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Left) || currentState.IsConnected && currentState.ThumbSticks.Left.X < -0.2f);
            bool activateRight = activatorRight.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Right) || currentState.IsConnected && currentState.ThumbSticks.Left.X > 0.2f);

            if (activateEnter)
            {
                // Setting gameState and tutorialState in respons to different menu choices
                switch (menuModel.getMenuChoice())
                {
                    case MenuChoice.Continue: //  Return to game
                        gameState = GameState.Continue;
                        menuView.stopMusic();
                        break;
                    case MenuChoice.NewGame: // Start new game
                        gameState = GameState.NewGame;
                        menuModel.setMenuChoice(MenuChoice.Continue);
                        menuView.stopMusic();
                        break;
                    case MenuChoice.Tutorial:

                        if (tutorialState == TutorialState.False)
                        {
                            tutorialState = TutorialState.True;
                        }
                        else
                        {
                            tutorialState = TutorialState.False;
                        }
                        break;
                    case MenuChoice.Controls: // 
                        gameState = GameState.Controls;
                        break;
                    case MenuChoice.Credits: // 
                        gameState = GameState.Credits;
                        break;
                    case MenuChoice.Exit: // Quit game
                        gameState = GameState.Exit;
                        break;
                }
            }
            // Draws Controls screen
            else if (gameState == GameState.Controls)
            {
                activatorUp = new Activator(0);
                activateUp = activatorUp.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Up) || currentState.IsConnected && currentState.ThumbSticks.Left.Y > 0.2f);
                controlsView.Draw(spriteBatch);

                if(activateUp || Keyboard.GetState().IsKeyDown(Keys.Escape))
                {
                    gameState = GameState.Menu;

                    if (activateUp)
                    {
                        menuModel.setMenuChoice(MenuChoice.Credits);
                    }
                }
                
            }
            // Draws Credits screen
            else if (gameState == GameState.Credits)
            {
                activatorUp = new Activator(0);
                activateUp = activatorUp.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Up) || currentState.IsConnected && currentState.ThumbSticks.Left.Y > 0.2f);
                creditsView1.Draw(spriteBatch);

                if (activateUp || Keyboard.GetState().IsKeyDown(Keys.Escape))
                {
                    gameState = GameState.Menu;

                    if (activateUp)
                    {
                        menuModel.setMenuChoice(MenuChoice.Exit);
                    }
                }
                // Uses MenuModel methods to skip to next or previous choice when pressing UP or DOWN
                if (activateLeft)
                {
                    creditsView1.toggleCreditsLeft();
                    menuView.getEventListener().playMenuToggleSound();
                }
                if (activateRight)
                {
                    creditsView1.toggleCreditsRight();
                    menuView.getEventListener().playMenuToggleSound();
                }
            }
            // Draws the menu if ENTER is not pressed
            else
            {
                menuView.DrawMenu(spriteBatch, gameState, tutorialState);
            }
            // Uses MenuModel methods to skip to next or previous choice when pressing UP or DOWN
            if (activateDown)
            {
                menuModel.toggleMenuDown();
                menuView.getEventListener().playMenuToggleSound();

                if (gameState == GameState.StartMode && menuModel.getMenuChoice() == MenuChoice.Continue)
                {
                    menuModel.toggleMenuDown();
                }
            }
            if (activateUp)
            {
                menuModel.toggleMenuUp();
                menuView.getEventListener().playMenuToggleSound();

                if (gameState == GameState.StartMode && menuModel.getMenuChoice() == MenuChoice.Continue)
                {
                    menuModel.toggleMenuUp();
                }
            }
            return gameState; // GameState is returned to MasterController
        }
    }
}
