﻿/*******************************************************************************************************/
// File:    MenuControls.cs
// Summary: Draws the images which displays info about keyboard controls.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;

namespace View
{
    public enum CreditsState { Page1, Page2, Page3, Page4 }
    /// <summary>
    /// Draws the images which displays info about keyboard controls.
    /// </summary>
    class CreditsView
    {
        private static int CREDITS_CHOICE_MAX_NUMBER = (int)CreditsState.Page4;
        GraphicsDevice device;
        ContentManager content;
        public CreditsState creditsState = CreditsState.Page1;
        int creditsStateNumber = (int)CreditsState.Page1;
        // Image textures
        Texture2D backGroundImage;
        Texture2D BackGroundTransparantImage;
        Texture2D[] CreditsTexture;
        Texture2D ArrowsTexture;

        public CreditsView(GraphicsDevice device, ContentManager content)
        {
            // Initiating objects and textures needed to draw the images
            this.device = device;
            this.content = content;
            backGroundImage = content.Load<Texture2D>("background_image"); // Background image
            BackGroundTransparantImage = content.Load<Texture2D>("background_transparant"); // Background image
            ArrowsTexture = content.Load<Texture2D>("background_transparant"); // Background image
            CreditsTexture = new Texture2D[] {
                content.Load<Texture2D>("credits1"),
                content.Load<Texture2D>("credits2"),
                content.Load<Texture2D>("credits3"),
                content.Load<Texture2D>("credits4")
            };
            ArrowsTexture = content.Load<Texture2D>("arrows");

        }
        
        /// <summary>
        /// DRAWING the images. Scale is used so that the menu can look fairly the same in different window sizes
        /// </summary>
        public void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Begin();
            device.Clear(Color.Black); // Setting background color
            spriteBatch.Draw(backGroundImage, new Vector2(0, 0), Color.White);
            spriteBatch.Draw(BackGroundTransparantImage, new Vector2(0, 0), Color.White);

            switch (creditsState)
            {
                case CreditsState.Page1:
                    spriteBatch.Draw(CreditsTexture[0], new Vector2(0, 0), Color.White);
                    break;
                case CreditsState.Page2:
                    spriteBatch.Draw(CreditsTexture[1], new Vector2(0, 0), Color.White);
                    break;
                case CreditsState.Page3:
                    spriteBatch.Draw(CreditsTexture[2], new Vector2(0, 0), Color.White);
                    break;
                case CreditsState.Page4:
                    spriteBatch.Draw(CreditsTexture[3], new Vector2(0, 0), Color.White);
                    break;
            }
            spriteBatch.Draw(ArrowsTexture, new Vector2(100, 850), Color.White);
            spriteBatch.End();
        }

        // 2 methods to increase and decrease the menu choice number. Triggered in MenuController by UP and DOWN keys

        public void toggleCreditsLeft()
        {
            creditsStateNumber--;

            if (creditsStateNumber < 0) // Starts from 0 if max is reached
            {
                creditsStateNumber = CREDITS_CHOICE_MAX_NUMBER;
            }
            creditsState = (CreditsState)creditsStateNumber;
        }

        public void toggleCreditsRight()
        {
            creditsStateNumber++;

            if (creditsStateNumber > CREDITS_CHOICE_MAX_NUMBER) // Starts from max if 0 is reached
            {
                creditsStateNumber = 0;
            }
            creditsState = (CreditsState)creditsStateNumber;
        }
    }
}
