﻿/*******************************************************************************************************/
// File:    MenuButton.cs
// Summary: Drawing menu button and button text using texture, coordinates, color and spritebatch sent 
//          from menuView
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace View
{
    class MenuButton
    {
        GraphicsDevice device;

        public MenuButton(GraphicsDevice device)
        {
            this.device = device;
        }
        /// <summary>
        /// DRAWING the button and its button text
        /// </summary>
        /// <param name="buttonTexture">Texture of button and texts image</param>
        /// <param name="position">Position of button in window</param>
        /// <param name="textPosition">Position of button text in window</param>
        /// <param name="textPositionOnTexture">Position of button text on the image</param>
        /// <param name="size">Size of text on the image</param>
        /// <param name="spriteBatch">Spritebatch used to draw the images</param>
        /// <param name="color">Text color (varies, depending on meny choice)</param>
        public void draw(Texture2D buttonTexture, Vector2 position, Vector2 textPosition, Vector2 textPositionOnTexture, Vector2 size, SpriteBatch spriteBatch, Color color)
        {
            // BUTTON
            spriteBatch.Draw(
                buttonTexture, 
                new Rectangle((int)position.X, (int)position.Y, 600, 90), 
                new Rectangle(240, 75, 600, 90), 
                Color.White
                );

            // TEXT
            spriteBatch.Draw(
                buttonTexture,
                new Rectangle((int)textPosition.X, (int)textPosition.Y + 22, (int)size.X, (int)size.Y),
                new Rectangle((int)textPositionOnTexture.X, (int)textPositionOnTexture.Y, (int)size.X, (int)size.Y),
                color
                );
        }
    }
}
