﻿/*******************************************************************************************************/
// File:    MenuModel.cs
// Summary: Containing different methods, which handles menu choice.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
namespace Model
{
    // All menu choices
    public enum MenuChoice : int { Continue, NewGame, Tutorial, Controls, Credits, Exit }

    class MenuModel
    {
        public static readonly int MENU_CHOICE_MAX_NUMBER = (int)MenuChoice.Exit;
        MenuChoice menuChoice;
        int menuChoiceNumber;

        public MenuModel()
        {
            menuChoice = MenuChoice.NewGame; // New Game is startup choice
            menuChoiceNumber = (int)menuChoice; // Corresponding number in enums order
        }

        // GETS menu choice

        public MenuChoice getMenuChoice()  { return menuChoice; }
        public void setMenuChoice(MenuChoice menuChoice) { this.menuChoice = menuChoice; menuChoiceNumber = (int)menuChoice; }

        // 2 methods to increase and decrease the menu choice number. Triggered in MenuController by UP and DOWN keys

        public void toggleMenuDown()
        {
            menuChoiceNumber++;

            if (menuChoiceNumber > MenuModel.MENU_CHOICE_MAX_NUMBER) // Starts from 0 if max is reached
            {
                menuChoiceNumber = 0;
            }
            menuChoice = (MenuChoice)menuChoiceNumber;
        }

        public void toggleMenuUp()
        {
            menuChoiceNumber--;

            if (menuChoiceNumber < 0) // Starts from max if 0 is reached
            {
                menuChoiceNumber = MenuModel.MENU_CHOICE_MAX_NUMBER;
            }
            menuChoice = (MenuChoice)menuChoiceNumber;
        }
    }

}
