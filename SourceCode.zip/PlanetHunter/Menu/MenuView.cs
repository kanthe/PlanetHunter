﻿/*******************************************************************************************************/
// File:    MenuView.cs
// Summary: Triggered by MenuControllers "Draw" method. Creates view elements, used for drawing 
// certain features in the menu. Then triggeres their draw methods.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;
using Model;

namespace View
{
    /// <summary>
    /// Creating visual representation of the menu.
    /// </summary>
    class MenuView
    {
        int scale;
        GraphicsDevice device;
        ContentManager content;
        Camera camera;
        MenuModel menuModel; // Used to get the current menu choice
        MenuButton menuButton; // Used to draw buttons and button text
        Texture2D backGroundImage;
        Texture2D presentationTexture; // Title texture
        Texture2D buttonTexture; // Texture of image, showing the menu buttons and text on them
        Activator musicActivator = new Activator(0);
        Activator musicStopActivator = new Activator(0);
        SoundEffect music;
        SoundEffectInstance musicInstance;
        EventListener eventListener;

        public MenuView(MenuModel menuModel, int scale, GraphicsDevice device, ContentManager content)
        {
            // Initiating objects and textures needed to draw the images
            this.scale = scale;
            this.device = device;
            this.content = content;
            camera = new Camera(scale);
            eventListener = new EventListener(scale, device, content, null);
            this.menuModel = menuModel;
            // Classes used to draw buttons and buttons text, and display game control keys
            menuButton = new MenuButton(device);
            // Textures used
            backGroundImage = content.Load<Texture2D>("background_image"); // Background image
            presentationTexture = content.Load<Texture2D>("presentation"); // Game title and name
            buttonTexture = content.Load<Texture2D>("buttons"); // www.deviantart.com/art/Two-Metal-Buttons-150326164
            music = content.Load<SoundEffect>("Menu");
            musicInstance = music.CreateInstance();
            musicInstance.IsLooped = true;
        }

        public SoundEffectInstance getMusic() { return musicInstance; }
        public EventListener getEventListener() { return eventListener; }

        public void playMusic()
        {
            if (musicActivator.activeOneTimeStep(true))
            {
                musicInstance.Play();
                musicActivator = new Activator(0);
            }
        }

        public void stopMusic()
        {
            musicInstance.Stop();
        }


        /// <summary>
        /// DRAWING the menu using menuButton and menuControls
        /// </summary>
        public void DrawMenu(SpriteBatch spriteBatch, GameState gameState, TutorialState tutorialState)
        {
            // Drawing the menuButton using spritebatch
            spriteBatch.Begin();

            device.Clear(Color.Black); // Setting background color
            spriteBatch.Draw(backGroundImage, new Vector2(0, 0), Color.White);
            spriteBatch.Draw(presentationTexture, new Vector2(650, 50), Color.Yellow); // Title of the game

            // Toggle through all menu choices to get the right button texts
            for (int count = 0; count <= MenuModel.MENU_CHOICE_MAX_NUMBER; count++)
            {
                int choice = (int)menuModel.getMenuChoice();
                // White color when at menu choice. Else gray color
                Color color = Color.Gray;

                if (choice == count)
                {
                    color = Color.White;
                }
                Color colorTutor = Color.Gray;

                if (choice == count)
                {
                    colorTutor = Color.White;
                }
                
                // Positions depends on scale so that it doesen look strange on smaller window sizes
                Vector2 position = new Vector2( (float)scale / 4, 70 + count * (float)scale / 7);
                Vector2 textPosition;
                textPosition.Y = 70 + count * (float)scale / 7;

                // CONTINUE
                if (count == 0 && gameState != GameState.StartMode)
                {
                    textPosition.X = 95 + (float)scale / 4;
                    menuButton.draw(buttonTexture, position, textPosition, new Vector2(45, 240), new Vector2(200, 50), spriteBatch, color);
                }
                // START
                else if (count == 1)
                {
                    textPosition.X = 85 + (float)scale / 4;
                    menuButton.draw(buttonTexture, position, textPosition, new Vector2(45, 20), new Vector2(300, 50), spriteBatch, color);
                }
                // TUTORIAL MODE
                else if (count == 2)
                {
                    textPosition.X = 30 + (float)scale / 4;
                    textPosition.Y += 5;
                    menuButton.draw(buttonTexture, position, textPosition, new Vector2(45, 170), new Vector2(320, 50), spriteBatch, colorTutor);

                    // Tutorial Mode displays "ON" when activated ...
                    if (tutorialState == TutorialState.True)
                    {
                        spriteBatch.Draw(
                        buttonTexture,
                        new Rectangle((int)textPosition.X + 255, (int)textPosition.Y + 20, 60, 35),
                        new Rectangle(375, 175, 60, 35),
                        color
                        );
                    }
                    // ... and "OFF" when not activated
                    else if (tutorialState == TutorialState.False)
                    {
                        spriteBatch.Draw(
                        buttonTexture,
                        new Rectangle((int)textPosition.X + 255, (int)textPosition.Y + 20, 80, 35),
                        new Rectangle(460, 175, 60, 35),
                        color
                        );
                    }
                }
                // CONTROLS
                else if (count == 3) {
                    textPosition.X = 95 + (float)scale / 4;
                    textPosition.Y += 8;
                    menuButton.draw(buttonTexture, position, textPosition, new Vector2(45, 320), new Vector2(300, 50), spriteBatch, color);
                }
                // CREDITS
                else if (count == 4)
                {
                    textPosition.X = 110 + (float)scale / 4;
                    textPosition.Y += 8;
                    menuButton.draw(buttonTexture, position, textPosition, new Vector2(45, 390), new Vector2(300, 50), spriteBatch, color);
                }
                // EXIT
                else if (count == 5)
                {
                    textPosition.X = 140 + (float)scale / 4;
                    textPosition.Y += 3;
                    menuButton.draw(buttonTexture, position, textPosition, new Vector2(45, 100), new Vector2(150, 50), spriteBatch, color);
                }
            }

            spriteBatch.End();
        }
    }
}
