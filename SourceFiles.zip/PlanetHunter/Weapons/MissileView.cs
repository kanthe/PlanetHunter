﻿/*******************************************************************************************************/
// File:    MissileView.cs
// Summary: Draws the missile
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    /// <summary>
    /// Creating visual representation of a missile
    /// </summary>
    class MissileView
    {
        Camera camera;
        Texture2D missileTexture; // Texture of beamshot from file

        public MissileView(int scale, GraphicsDevice device, ContentManager content)
        {
            camera = GameView.camera;
            // e-young.deviantart.com/
            missileTexture = content.Load<Texture2D>("missile"); // Texture for the beam
        }
        /// <summary>
        /// Calculates the position of the missile in visual coordinates 
        /// and draws it. Activated each gametime step.
        /// </summary>
        public void DrawMissile(Missile missile, int scale, SpriteBatch spriteBatch)
        {
            Vector2 viewPosition = camera.modelPositionToViewPosition(missile.getPosition());

            if (viewPosition.X < SideBar.SIDEBAR_WIDTH || viewPosition.X > scale + SideBar.SIDEBAR_WIDTH || viewPosition.Y < 0 || viewPosition.Y > scale)
            {
                missile.setMissileLaunched(false);
            }
            int size = missile.getSize();
            Color color = missile.getColor();
            Rectangle rect = new Rectangle((int)viewPosition.X, (int)viewPosition.Y, size, size);

            float angle = missile.getAngle();

            // Drawing the missile
            spriteBatch.Draw(missileTexture, rect, null, color, angle + Geometry.PI / 4, new Vector2(size / 2, size / 2), SpriteEffects.None, 0);
        }
    }
}


