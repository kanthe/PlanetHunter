﻿/*******************************************************************************************************/
// File:    Missile.cs
// Summary: Creates shoots missile on command from gameController via player
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class Missile
    {
        Vector2 position;
        Vector2 direction;
        float angle;
        readonly float SPEED = 0.5f;
        readonly int SIZE = 15;
        readonly Color COLOR = Color.White;
        readonly int DAMAGE = 200;
        float missileLoadTime;
        Timer missileLoadTimer; // Counts down load time
        Activator missileLoadActivator; // Used to fire missile at one key stroke
        bool missileLaunched = false;
        bool missileActivated;
        bool resetMissileBar = false;

        public Missile(bool missileActivated)
        {
            this.missileActivated = missileActivated;
            missileLoadTime = 5.0f;
            missileLoadTimer = new Timer(missileLoadTime);
            missileLoadActivator = new Activator(0);
        }
        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        public Vector2 getPosition() { return position; }
        public Vector2 getDirection() { return direction; }
        public float getAngle() { return angle; }
        public float getSpeed() { return SPEED; }
        public int getSize() { return SIZE; }
        public Color getColor() { return COLOR; }
        public int getDamage() { return DAMAGE; }
        public bool getMissileLaunched() { return missileLaunched; }
        public bool getMissileActivated() { return missileActivated; }
        public float getMissileLoadTime() { return missileLoadTime; }
        public bool getResetCircle() { return resetMissileBar;  }

        /// <summary>
        /// SET METHODS
        /// </summary>
        public void setMissileLaunched(bool missileLaunched) { this.missileLaunched = missileLaunched; }
        public void setMissileActivated(bool missileActivated) { this.missileActivated = missileActivated; }
        public void setMissileLoadTime(float missileLoadTime) { this.missileLoadTime = missileLoadTime; }
        public void setPosition(Vector2 position) { this.position = position; }

        /// <summary>
        /// FIRE
        /// </summary>
        public bool launch(bool fireButtonPressed, float deltaTime, Vector2 position, float angle)
        {
            resetMissileBar = false; // True when missile is lauched

            if (missileActivated)
            {
                // Becomes true when missileLoadTimer time has passed
                bool loaded = missileLoadTimer.runTimer(deltaTime);

                // Ensures missile is not launched if player holds down the key until loadtime has passed
                if (missileLoadTime - missileLoadTimer.getTimer() < 2 * deltaTime && fireButtonPressed)
                {
                    missileLoadTimer.reverseOneTimeStep(deltaTime);
                }
                // If player presses missile button after loadtime is passed
                if (loaded && missileLoadActivator.activeOneTimeStep(fireButtonPressed))
                {
                    resetMissileBar = true; // Missilebar in sidebar is reseted
                    missileLaunched = true; // Missile launches
                    this.position = position;
                    this.angle = angle;
                    direction = new Vector2((float)System.Math.Cos(angle), (float)System.Math.Sin(angle));
                    missileLoadTimer.resetTimer(); // Resets loadtimer, to caunt down to next time to fire missile
                    return true;
                }
            }
            return false;
        }
    }
}
