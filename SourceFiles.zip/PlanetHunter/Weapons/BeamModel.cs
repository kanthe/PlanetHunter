﻿/*******************************************************************************************************/
// File:    BeamModel.cs
// Summary: Creating an ordinary gunshot (beam) used by both player and enemies
// and updating position of it.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    /// <summary>
    /// Creating an ordinary gunshot (beam) used by both player and enemies
    /// and updating position of it.
    /// </summary>
    class BeamModel
    {
        Vector2 position;
        Vector2 direction;
        float speed;
        int diameter;
        Color color;
        int damage;

        public BeamModel(Vector2 position, Vector2 direction, float speed, int diameter, Color color, int damage)
        {
            this.position = position;
            this.speed = speed;
            this.direction = direction;
            this.diameter = diameter;
            this.color = color;
            this.damage = damage;
        }
        /// <summary>
        /// GET methods: Returns the beams position, diameter and color
        /// </summary>
        public Vector2 getPosition() { return position; }
        public Vector2 getDirection() { return direction; }
        public float getSpeed() { return speed; }
        public int getDiameter() { return diameter; }
        public Color getColor() { return color; }
        public int getBeamDamage() { return damage; }
        public void setPosition(Vector2 position) { this.position = position; }
    }
}
