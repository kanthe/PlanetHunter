﻿/*******************************************************************************************************/
// File:    BeamWeapon.cs
// Summary: Creates and shoots beams on command from gameController via player and also includes the 
// autofire function.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{

    class BeamWeapon
    {
        // BEAM

        System.Collections.Generic.List<BeamModel> beams = new System.Collections.Generic.List<BeamModel>();
        float beamSpeed;
        int beamSize;
        Color beamColor;
        int beamDamage;

        // AUTOFIRE

        bool hasAutoFire = false;
        Timer autoFireLoadTimer;
        // Activates autofire
        Activator autoFireStartupActivator;
        Activator autoFireIntervalActivator;
        // Timer, that starts when player press and hold fire button and "LOADTIME" is reached since last autofire session.
        Timer autoFireDurationTimer;
        float autoFireLoadTime = 3.0f; // Counts down load time
        readonly float AUTOFIRE_STARTUP_TIME = 0.2f; // Time fire button has to be pressed before autofire starts.
        // Maximum time for and autofire session after "AUTOFIRE_STARTUP_TIME" is reached.
        readonly float AUTOFIRE_DURATION = 1.5f; // Duration in seconds, of one autofire session.
        readonly float AUTOFIRE_INTERVAL = 0.2f; // Time between each beam in an autofire session.
        bool resetAutoFireBar = false;
        
        /// <summary>
        /// CONSTRUCTOR default parameters
        /// </summary>
        public BeamWeapon(Color color, float speed = 0.5f, int size = 10, int damage = 10)
        {
            this.beamSpeed = speed;
            this.beamSize = size;
            this.beamColor = color;
            this.beamDamage = damage;
            autoFireLoadTimer = new Timer(autoFireLoadTime);
            autoFireStartupActivator = new Activator(AUTOFIRE_STARTUP_TIME);
            autoFireIntervalActivator = new Activator(AUTOFIRE_INTERVAL);
            autoFireDurationTimer = new Timer(AUTOFIRE_DURATION);
        }
        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        public System.Collections.Generic.List<BeamModel> getBeams() { return beams; }
        public int getBeamDamage() { return beamDamage; }
        public Timer getAutoFireLoadTimer() { return autoFireLoadTimer; }
        public bool getHasAutoFire() { return hasAutoFire; }
        public float getAutoFireLoadTime() { return autoFireLoadTime; }
        public bool getResetCountDownCircle() { return resetAutoFireBar; }

        public void setHasAutoFire(bool hasAutoFire) { this.hasAutoFire = hasAutoFire; }
        public void setAutoFireLoadTime(float autoFireLoadTime) { this.autoFireLoadTime = autoFireLoadTime; }

        /// <summary>
        /// FIRE
        /// </summary>
        public bool fire(bool fireButtonPressed, float deltaTime, Vector2 position, float angle) 
        {
            bool fireBeam = false;
            Vector2 direction = Geometry.AngleToDirection(angle);
            // Fires one beam if firebutton is pressed
            if (autoFireStartupActivator.activeOneTimeStep(fireButtonPressed))
            {
                beams.Add(new BeamModel(position, direction, beamSpeed, beamSize, beamColor, beamDamage));
                fireBeam = true;
            }
            else if (hasAutoFire)
            {
                // Activates autofire
                fireBeam = autoFire(fireButtonPressed, deltaTime, position, direction);
            }
            return fireBeam; // returns true if beam is fired
        }
        /// <summary>
        /// AUTOFIRE
        /// </summary>
        public bool autoFire(bool fireButtonPressed, float deltaTime, Vector2 position, Vector2 direction) {

            resetAutoFireBar = false; // True if autefire bar should be reseted
            // Loading autofire. If true loadTime has passed and autofire can be fired
            bool autoFireLoaded = autoFireLoadTimer.runTimer(deltaTime);

            // Ensures autofire is not fired if player holds down the key until loadtime has passed
            if (autoFireLoadTime - autoFireLoadTimer.getTimer() < 2 * deltaTime && fireButtonPressed)
            {
                autoFireLoadTimer.reverseOneTimeStep(deltaTime);
            }
            
            if (autoFireLoaded)
            {
                // If player presses fire button after loadtime is passed and hold until startup time is passed
                if (autoFireStartupActivator.activeOnHold(fireButtonPressed, deltaTime) && autoFireStartupActivator.getReachedResetTime())
                {
                    bool timesUp = autoFireDurationTimer.runTimer(deltaTime);

                    if (timesUp)
                    {
                        // If duration time is passed autofire is reseted
                        resetAutoFireBar = true;
                        autoFireLoadTimer.resetTimer();
                        autoFireDurationTimer.resetTimer();
                    }
                    // Beam fires in intervals
                    else if (autoFireIntervalActivator.activeOnInterval(fireButtonPressed, deltaTime)) 
                    {
                        beams.Add(new BeamModel(position, direction, beamSpeed, 15, Color.Red, beamDamage * 3));
                        return true;
                    }
                }
                // Resets autofire if player do not hold fire button
                else if (autoFireDurationTimer.getTimer() > 0)
                {
                    resetAutoFireBar = true;
                    autoFireLoadTimer.resetTimer();
                    autoFireDurationTimer.resetTimer();
                }

            }
            return false;
        }
    }
}
