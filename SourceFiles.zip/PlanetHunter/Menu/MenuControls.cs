﻿/*******************************************************************************************************/
// File:    MenuControls.cs
// Summary: Draws the images which displays info about keyboard controls.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    /// <summary>
    /// Draws the images which displays info about keyboard controls.
    /// </summary>
    class MenuControls
    {
        GraphicsDevice device;
        ContentManager content;
        // Image textures
        Texture2D ControlsStearingTexture;
        Texture2D ControlsFireTexture;
        Texture2D ControlsOtherTexture;

        public MenuControls(GraphicsDevice device, ContentManager content)
        {
            // Initiating objects and textures needed to draw the images
            this.device = device;
            this.content = content;
            // en.wikipedia.org/wiki/Keyboard_layout#/media/File:ANSI_Keyboard_Layout_Diagram_with_Form_Factor.svg
            ControlsStearingTexture = content.Load<Texture2D>("controls_stearing");
            ControlsFireTexture = content.Load<Texture2D>("controls_fire");
            ControlsOtherTexture = content.Load<Texture2D>("skip_level");
        }
        
        /// <summary>
        /// DRAWING the images. Scale is used so that the menu can look fairly the same in different window sizes
        /// </summary>
        public void Draw(Vector2 position, float scale, SpriteBatch spriteBatch)
        {
            // Stearing image
            spriteBatch.Draw(ControlsStearingTexture, position + new Vector2(0, 200), Color.White);
            // Fire image
            spriteBatch.Draw(ControlsFireTexture, position + new Vector2(0, 430), Color.White);
            //Other image
            spriteBatch.Draw(ControlsOtherTexture, new Vector2((float)scale / 4, 150 + 3 * (float)scale / 7), Color.White);
        }
    }
}
