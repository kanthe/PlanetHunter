﻿/*******************************************************************************************************/
// File:    MenuController.cs
// Summary: Initiating the main menu classes menuModel and menuView. Also handles menu choices and players 
// input. It also handles different states of the game before returning it to MaserController.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using View;
using Model;

namespace Controller
{
    class MenuController
    {
        // If menu choice Tutorial Mode is selected. It is handled to masterController and later 
        // gameSimulator, which set it equal to  its own tutorialState
        TutorialState tutorialState = TutorialState.True; 
        GameState gameState = GameState.StartMode; // State of the game (Menu, Continue, ...)
        MenuModel menuModel; // Has some methods MenuController use to handle menu choices
        MenuView menuView; // Draws the menu
        // Activates different keys at one key stroke
        Activator activatorEnter = new Activator(0);
        Activator activatorDown = new Activator(0);
        Activator activatorUp = new Activator(0);
        SpriteBatch spriteBatch; // Used to draw the menu

        public MenuController(int scale, GraphicsDevice device, ContentManager content)
        {
            menuModel = new MenuModel();
            menuView = new MenuView(menuModel, scale, device, content);
            spriteBatch = new SpriteBatch(device);
        }

        // GET METHODS

        public TutorialState getTutorialState() { return tutorialState; }

        // SET METHODS

        public void setGameState(GameState gameState) { this.gameState = gameState; }

        // UPDATE

        public GameState Update()
        {
            // ENTER, UP, and DOWN key uses an Activator to not do a series of actions at one key stroke by user
            bool activateEnter = activatorEnter.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Enter));
            bool activateDown = activatorDown.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Down));
            bool activateUp = activatorUp.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.Up));

            if (activateEnter)
            {
                // Setting gameState and tutorialState in respons to different menu choices
                switch (menuModel.getMenuChoice())
                {
                    case MenuChoice.Continue: //  Return to game
                        gameState = GameState.Continue;
                        break;
                    case MenuChoice.NewGame: // Start new game
                        gameState = GameState.NewGame;
                        break;
                    case MenuChoice.Tutorial:

                        if (tutorialState == TutorialState.False)
                        {
                            tutorialState = TutorialState.True;
                        }
                        else
                        {
                            tutorialState = TutorialState.False;
                        }
                        break;
                    case MenuChoice.Exit: // Quit game
                        gameState = GameState.Exit;
                        break;
                }
            }
            // Draws the menu if ENTER is not pressed
            else
            {
                menuView.DrawMenu(spriteBatch, gameState, tutorialState);
            }
            // Uses MenuModel methods to skip to next or previous choice when pressing UP or DOWN
            if (activateDown)
            {
                menuModel.toggleMenuDown();

                if (gameState == GameState.StartMode && menuModel.getMenuChoice() == MenuChoice.Continue)
                {
                    menuModel.toggleMenuDown();
                }
            }
            if (activateUp)
            {
                menuModel.toggleMenuUp();

                if (gameState == GameState.StartMode && menuModel.getMenuChoice() == MenuChoice.Continue)
                {
                    menuModel.toggleMenuUp();
                }
            }
            return gameState; // GameState is returned to MasterController
        }
    }
}
