﻿/*******************************************************************************************************/
// File:    Messages.cs
// Summary: Loading images, containing all messeges, which will be shown in the game
// Has a method which draws any messag.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{

    class Messages
    {
        float messageTime = 3.0f; // The time the messge is shown
        Timer messageTimer; // Counts down message time
        bool pauseForMessage = false; // Used by GameController to pause during message time
        // All needed textures;
        Texture2D messageTexture;
        Texture2D openingTexture; 
        Texture2D gameOverTexture;
        Texture2D landingSuccessfulTexture;
        Texture2D mapL1StartTexture;
        Texture2D mapL2StartTexture;
        Texture2D mapL3StartTexture;
        Texture2D levelCompleteTexture;
        Texture2D firstLandingTexture;
        Texture2D asteroidWarningTexture;
        Texture2D mapL1DefenceStationTexture;
        Texture2D autoFireTexture;
        Texture2D missileTexture;


        public Messages(ContentManager content)
        {
            messageTimer = new Timer(messageTime);
            // Loading all needed textures
            openingTexture = content.Load<Texture2D>("message_opening");
            gameOverTexture = content.Load<Texture2D>("message_gameOver");
            landingSuccessfulTexture = content.Load<Texture2D>("message_landing_successful");
            mapL1StartTexture = content.Load<Texture2D>("message_level_1");
            mapL2StartTexture = content.Load<Texture2D>("message_level_2");
            mapL3StartTexture = content.Load<Texture2D>("message_level_3");
            levelCompleteTexture = content.Load<Texture2D>("message_level_done");
            firstLandingTexture = content.Load<Texture2D>("message_first_landing");
            asteroidWarningTexture = content.Load<Texture2D>("message_mapL1Asteroids");
            mapL1DefenceStationTexture = content.Load<Texture2D>("message_space_station");
            autoFireTexture = content.Load<Texture2D>("message_autoFire");
            missileTexture = content.Load<Texture2D>("message_missile");
        }

        // GET METHODS

        public float getMessageTime() { return messageTime; }
        public bool getPauseForMessage() { return pauseForMessage; }

        // SET METHODS

        public void setMessageTimer(float messageTime) { messageTimer.setTimer(messageTime); }

        // DRAWS a message

        public bool show(Vector2 position, Message message, SpriteBatch spriteBatch, float deltaTime)
        {
            pauseForMessage = false;
            // Choosing message, called in the method
            switch (message) 
            {
                case Message.Opening:
                    messageTexture = openingTexture;
                    messageTime = 5.0f;
                    break;
                case Message.GameOver:
                    messageTexture = gameOverTexture;
                    messageTime = 2.0f;
                    break;
                case Message.LandingSuccessful:
                    messageTexture = landingSuccessfulTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL1Start:
                    messageTexture = mapL1StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL2Start:
                    messageTexture = mapL2StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.MapL3Start:
                    messageTexture = mapL3StartTexture;
                    messageTime = 2.0f;
                    break;
                case Message.LevelComplete:
                    messageTexture = levelCompleteTexture;
                    messageTime = 2.0f;
                    break;
                case Message.FirstPlanetVisit:
                    messageTexture = firstLandingTexture;
                    messageTime = 5.0f;
                    break;
                case Message.AsteroidWarning:
                    messageTexture = asteroidWarningTexture;
                    messageTime = 2.0f;
                    break;
                case Message.DefenceStationWarning:
                    messageTexture = mapL1DefenceStationTexture;
                    messageTime = 5.0f;
                    break;
                case Message.AutoFire:
                    messageTexture = autoFireTexture;
                    messageTime = 5.0f;
                    break;
                case Message.Missile:
                    messageTexture = missileTexture;
                    messageTime = 5.0f;
                    break;
            }

            if (message != Message.None)
            {
                messageTimer.setTimer(messageTime);
                pauseForMessage = true;
                // Centering message
                position = position - new Vector2(messageTexture.Bounds.Width / 2, messageTexture.Bounds.Height / 2);

                if (!messageTimer.runTimer(deltaTime))
                {
                    spriteBatch.Draw(messageTexture, position, Color.White);
                    return false;
                }
                else
                {
                    messageTimer.resetTimer();
                }
            }
            return true;
        }
    }
}
