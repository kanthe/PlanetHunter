﻿/*******************************************************************************************************/
// File:    MapView.cs
// Summary: MapView has methods to draw most game elements, including planets, the planets land 
// indicator asteroids, background stars, border around map. Also creates background stars and border.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{

    class MapView
    {
        public static readonly int LAND_INDICATOR_WIDTH = 24;

        int scale;
        GraphicsDevice device;
        ContentManager content;
        Camera camera;
        
        Texture2D landIndicatorTexture; // Shows up when player is over the planet if it is landable
        Border border; // The red border around the map
        Texture2D bgStarTextureRed;
        Texture2D bgStarTextureYellow;
        System.Collections.Generic.List<Planet> planets;
        Texture2D asteroidTexture;

        public MapView(MapTemplate mapModel, int scale, GraphicsDevice device, ContentManager content)
        {
            this.scale = scale;
            this.device = device;
            this.content = content;
            camera = GameView.camera;

            // BACKGROUND

            // PLANETS
            planets = mapModel.getPlanets();
            // www.iconfinder.com/bogdanrosu
            landIndicatorTexture = content.Load<Texture2D>("rocket_icon");

            // MISC
            bgStarTextureRed = content.Load<Texture2D>("red_star");
            bgStarTextureYellow = content.Load<Texture2D>("yellow_star");
            // h ttps://commons.wikimedia.org/wiki/File:Asteroidsscale.jpg
            asteroidTexture = content.Load<Texture2D>("Asteroidsscale");
        }

        // MAP
        
        public void drawMap(SpriteBatch spriteBatch, MapTemplate mapModel)
        {
            // BORDER around map

            border = new Border(device, mapModel.getBorderRadius());
            border.DrawBorder(scale, spriteBatch);

            // BACKGROUND STARS

            System.Collections.Generic.List<Star> bgStars = mapModel.getBgStars();
            System.Collections.Generic.List<Star> bgStarsLayer2 = mapModel.getBgStarsLayer2();

            for (int count = 0; count < MapL1.NUMBER_OF_BG_STARS; count++)
            {
                // Faint white stars
                Vector2 position = camera.modelPositionToViewPosition(bgStars[count].getPosition());
                int size = bgStars[count].getSize();
                spriteBatch.Draw(bgStarTextureRed, new Rectangle((int)position.X, (int)position.Y, size, size), Color.White);

                // Near bigger stars
                Vector2 position2 = camera.modelPositionToViewPosition(bgStarsLayer2[count].getPosition());
                int size2 = bgStarsLayer2[count].getSize();
                // Near red stars
                if (count < MapL1.NUMBER_OF_BG_STARS / 2)
                {
                    spriteBatch.Draw(bgStarTextureRed, new Rectangle((int)position2.X, (int)position2.Y, size2, size2), Color.White);
                }
                // Near yellow stars
                else
                {
                    spriteBatch.Draw(bgStarTextureYellow, new Rectangle((int)position2.X, (int)position2.Y, size2, size2), Color.White);
                }
            }
        }

        // PLANETS

        public void DrawPlanet(Planet planet, SpriteBatch spriteBatch)
        {
            Vector2 planetViewPosition = camera.modelPositionToViewPosition(planet.getPosition());
            int planetViewDiameter = (int)camera.scaleObject(planet.getDiameter());
            int posX = (int)planetViewPosition.X;
            int posY = (int)planetViewPosition.Y;
            Texture2D planetTexture = content.Load<Texture2D>("dark");

            switch (planet.getPlanetTexture())
            {
                case PlanetTexture.Dark:
                    planetTexture = content.Load<Texture2D>("dark");
                    break;
                case PlanetTexture.Green:
                    planetTexture = content.Load<Texture2D>("green");
                    break;
                case PlanetTexture.Jupiter_like:
                    planetTexture = content.Load<Texture2D>("jupiter_like");
                    break;
                case PlanetTexture.Methane:
                    planetTexture = content.Load<Texture2D>("methane");
                    break;
                case PlanetTexture.Neptune_like:
                    planetTexture = content.Load<Texture2D>("neptune_like");
                    break;
                case PlanetTexture.Ocean:
                    planetTexture = content.Load<Texture2D>("ocean");
                    break;
                case PlanetTexture.Pink:
                    planetTexture = content.Load<Texture2D>("pink");
                    break;
                case PlanetTexture.Red:
                    planetTexture = content.Load<Texture2D>("red");
                    break;
                case PlanetTexture.Yellow:
                    planetTexture = content.Load<Texture2D>("yellow");
                    break;
                case PlanetTexture.Yellow_Green:
                    planetTexture = content.Load<Texture2D>("yellow_green");
                    break;
            }

            spriteBatch.Draw(
                planetTexture,
                new Rectangle(posX, posY, planetViewDiameter, planetViewDiameter),
                Color.White
                );
        }

        // PLANET LAND INDICATOR

        public void drawLandIndicator(Planet planet, SpriteBatch spriteBatch)
        {
            Vector2 planetViewPosition = camera.modelPositionToViewPosition(planet.getPosition());
            int planetViewDiameter = (int)camera.scaleObject(planet.getDiameter());
            int posX = (int)planetViewPosition.X;
            int posY = (int)planetViewPosition.Y;

            spriteBatch.Draw(
                landIndicatorTexture,
                new Rectangle(posX + planetViewDiameter / 2 - LAND_INDICATOR_WIDTH / 2, posY + planetViewDiameter / 2 - LAND_INDICATOR_WIDTH / 2, LAND_INDICATOR_WIDTH, LAND_INDICATOR_WIDTH),
                Color.White
                );
        }

        // ASTEROIDS

        public void drawAsteroid(Asteroid asteroid, SpriteBatch spriteBatch)
        {
            Vector2 position = camera.modelPositionToViewPosition(asteroid.getPosition());

            spriteBatch.Draw(
                asteroidTexture,
                // Astroids position on map
                new Rectangle((int)position.X, (int)position.Y, asteroid.getSize(), asteroid.getSize()),
                // Astroids position on texture
                new Rectangle(
                    (int)asteroid.getPositionOnTexture().X, 
                    (int)asteroid.getPositionOnTexture().Y, 
                    (int)asteroid.getSizeOnTexture().X, 
                    (int)asteroid.getSizeOnTexture().X
                ), 
                Color.White
                );
        }
    }
}
