﻿/*******************************************************************************************************/
// File:    Asteroid.cs
// Summary: Creates an asteroid
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class Asteroid
    {
        readonly int DAMAGE = 5;

        Vector2 position;
        int size;
        Vector2 positionOnTexture;
        Vector2 sizeOnTexture;
        // Used to avoid a series of collisions (one in everry time step) when encountering an asteroid. 
        // Just the first time step, the astroid causes damage
        public Activator activator = new Activator(0); 

        /// <summary>
        /// Creating an asteroid
        /// </summary>
        public Asteroid(Vector2 position, int size, Vector2 positionOnTexture, Vector2 sizeOnTexture)
        {
            this.position = position;
            this.size = size;
            this.positionOnTexture = positionOnTexture;
            this.sizeOnTexture = sizeOnTexture;
        }

        // GET methods

        public int getDamage() { return DAMAGE; }
        public Vector2 getPosition() { return position; }
        public int getSize() { return size; }
        public Vector2 getPositionOnTexture() { return positionOnTexture; }
        public Vector2 getSizeOnTexture() { return sizeOnTexture;  }
    }
}
