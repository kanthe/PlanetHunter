﻿/*******************************************************************************************************/
// File:    Planet.cs
// Summary: Creates a planet
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    // Abilities obtained from the planet
    public enum PlanetPower { None, AutoFire, Missile, Shield, Fury}
    // Names of all planets
    public enum PlanetTexture { Dark, Green, Jupiter_like, Methane, Neptune_like, Ocean, Pink, Red, Yellow, Yellow_Green }

    class Planet
    {
        Vector2 position;
        float diameter;
        bool isLandable;
        PlanetPower power;
        bool playerOverPlanet = false;
        bool showLandingCircle = false;
        PlanetTexture planetTexture;

        public Planet(Vector2 position, float radius, bool islandable, PlanetPower power, PlanetTexture planetTexture)
        {
            this.position = position;
            this.diameter = radius;
            this.isLandable = islandable;
            this.power = power;
            this.planetTexture = planetTexture;
        }

        // GET METHODS

        public Vector2 getPosition() { return position; }
        public float getDiameter() { return diameter; }
        public bool getIsLandable() { return isLandable; }
        public PlanetPower getPower() { return power; }
        public PlanetTexture getPlanetTexture() { return planetTexture; }
        public bool getPlayerOverPlanet() { return playerOverPlanet;  }
        public bool getShowLandingCircle() { return showLandingCircle; }

        // SET METHODS

        public void setPlayerOverPlanet(bool playerOverPlanet) { this.playerOverPlanet = playerOverPlanet; }
        public void setShowLandingCircle(bool showLandingCircle) { this.showLandingCircle = showLandingCircle; }

        // LAND on planet

        public void land(Player player)
        {
            player.setHitPoints(player.STARTING_HITPOINTS);
            isLandable = false;
        }
    }
}
