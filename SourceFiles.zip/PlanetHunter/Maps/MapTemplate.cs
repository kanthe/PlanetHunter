﻿/*******************************************************************************************************/
// File:    MapTemplate.cs
// Summary: Astract class containing methods used in the maps
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    abstract class MapTemplate
    {
        protected float borderRadius;
        /// <summary>
        /// GET METHODS
        /// </summary>
        public abstract System.Collections.Generic.List<Star> getBgStars();
        public abstract System.Collections.Generic.List<Star> getBgStarsLayer2();
        public abstract System.Collections.Generic.List<Planet> getPlanets();
        public abstract System.Collections.Generic.List<Asteroid> getAsteroids();
        public abstract System.Collections.Generic.List<EnemyTemplate> getEnemies();
        public float getBorderRadius() { return borderRadius; }
    }
}
