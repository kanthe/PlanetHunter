﻿/*******************************************************************************************************/
// File:    Star.cs
// Summary: Creating a star
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class Star
    {
        Vector2 position;
        int size;
        Movement movement = new Movement();

        public Star(Vector2 position, int size)
        {
            this.position = position;
            this.size = size;
        }
        /// <summary>
        /// GET methods
        /// </summary>
        public Vector2 getPosition() { return position; }
        public int getSize() { return size; }
        public Movement getMovement() { return movement; }
        /// <summary>
        /// SETS position
        /// </summary>
        public void setPosition(Vector2 position) { this.position = position;  }
    }
}
