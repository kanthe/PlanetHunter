﻿/*******************************************************************************************************/
// File:    EventListener.cs
// Summary: Creates and draws the autofirebar.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.Audio;
using Model;

namespace View
{
    class EventListener
    {

        int scale;
        GraphicsDevice device;
        ContentManager content;
        Messages messages;
        // ANIMATIONS
        System.Collections.Generic.List<Explosion> explosions; // List of explosions
        float explosionDuration = 1.0f; // The time an explosion flare series is completed.
        int explosionNumber = 0; // Number of explosions.
        System.Collections.Generic.List<SmokeView> smokeViewList; // List of smoke
        System.Collections.Generic.List<SmokeSystem> smokeSystemList; // List of smoke
        // SOUNDS
        SoundEffect messageSound;
        SoundEffectInstance messageSoundInstance;
        SoundEffect explosionSmallSound;
        SoundEffect explosionSound;
        SoundEffect explosionBigSound;
        SoundEffect playerBeamSound;
        SoundEffect playerHitSound;
        SoundEffect enemyBeamSound;
        SoundEffect missileSound;

        public EventListener(int scale, GraphicsDevice device, ContentManager content, Messages messages)
        {
            this.scale = scale;
            this.device = device;
            this.content = content;
            this.messages = messages;
            // ANIMATIONS
            explosions = new System.Collections.Generic.List<Explosion>();
            smokeViewList = new System.Collections.Generic.List<SmokeView>(); // List of smoke
            smokeSystemList = new System.Collections.Generic.List<SmokeSystem>(); // List of smoke
            // SOUNDS
            messageSound = content.Load<SoundEffect>("message_signal"); // Sound effect
            messageSoundInstance = messageSound.CreateInstance();
            explosionSmallSound = content.Load<SoundEffect>("Explosion-02"); // Sound effect
            explosionSound = content.Load<SoundEffect>("Explosion-04"); // Sound effect
            explosionBigSound = content.Load<SoundEffect>("Explosion-04-long"); // Sound effect
            playerBeamSound = content.Load<SoundEffect>("Laser-Gun"); // Sound effect
            playerHitSound = content.Load<SoundEffect>("enemy_beam"); // Sound effect
            enemyBeamSound = content.Load<SoundEffect>("Space-Gun-09"); // Sound effect
            missileSound = content.Load<SoundEffect>("laserbeam"); // Sound effect
        }

        public Messages getMessages() { return messages; }

        /// <summary>
        /// Creating an explosion object and adding it to a list of such objects. 
        /// </summary>
        public void MakeExplosion(Vector2 position, GameTime explosionStartTime,
            float flareSize, float smokeParticleMaxLifeTime, float smokeParticleMinSize, float smokeParticleMaxSize, float splitterSpeed, float splitterSize)
        {
            explosions.Add(new Explosion(scale, device, content, explosionStartTime, position,
                flareSize, smokeParticleMaxLifeTime, smokeParticleMinSize, smokeParticleMaxSize, splitterSpeed, splitterSize));
            explosionNumber++;
        }
        /// <summary>
        /// Updates explosions.
        /// </summary>
        public void UpdateExplosions(GameTime gameTime, SpriteBatch spriteBatch, float deltaTime)
        {
            // All explosions are updated until the total game time reaches the explosion duration time 
            foreach (Explosion explosion in explosions)
            {
                if ((float)gameTime.TotalGameTime.TotalSeconds - explosion.getExplosionStartTime() < explosionDuration)
                {
                    explosion.Update(deltaTime, spriteBatch);
                }
            }
        }
        public void MakeSmoke(Vector2 position, float smokeParticleMaxLifeTime, float smokeParticleMinSize, float smokeParticleMaxSize)
        {
            SmokeSystem smokeSystem = new SmokeSystem(position, smokeParticleMaxLifeTime, smokeParticleMinSize, smokeParticleMaxSize);
            smokeSystemList.Add(smokeSystem);
            smokeViewList.Add(new SmokeView(smokeSystem, scale, device, content));
        }
        /// <summary>
        /// Updates explosions.
        /// </summary>
        public void UpdateSmoke(SpriteBatch spriteBatch, float deltaTime)
        {
            // All explosions are updated until the total game time reaches the explosion duration time 
            foreach (SmokeSystem smokeSystem in smokeSystemList)
            {
                smokeSystem.updateParticles(deltaTime);
            }
            foreach (SmokeView smokeView in smokeViewList)
            {
                smokeView.DrawSmoke(spriteBatch);
            }
        }
        public void removeSmoke()
        {
            smokeViewList = new System.Collections.Generic.List<SmokeView>();
            smokeSystemList = new System.Collections.Generic.List<SmokeSystem>();
        }
        /// <summary>
        /// GET METHODS
        /// </summary>
        /// <returns></returns>
        public System.Collections.Generic.List<Explosion> getExplosions() { return explosions; }
        public System.Collections.Generic.List<SmokeView> getSmokeViewList() { return smokeViewList; }
        public System.Collections.Generic.List<SmokeSystem> getSmokeSystemList() { return smokeSystemList; }

        // SOUNDS

        public void playMessageSound()
        {
            messageSoundInstance.Play();
        }
        public void playExplosionSmallSound()
        {
            SoundEffectInstance explosionSmallSoundInstance = explosionSmallSound.CreateInstance();
            explosionSmallSoundInstance.Volume = 0.6f;
            explosionSmallSoundInstance.Play();
        }
        public void playExplosionSound()
        {
            SoundEffectInstance explosionSoundInstance = explosionSound.CreateInstance();
            explosionSoundInstance.Play();
        }
        public void playExplosionBigSound()
        {
            SoundEffectInstance explosionBigSoundInstance = explosionBigSound.CreateInstance();
            explosionBigSoundInstance.Play();
        }
        public void playPlayerBeamSound()
        {
            SoundEffectInstance playerBeamSoundInstance = playerBeamSound.CreateInstance();
            playerBeamSoundInstance.Volume = 0.5f;
            playerBeamSoundInstance.Play();
        }
        public void playPlayerHitSound()
        {
            SoundEffectInstance playerHitSoundInstance = playerHitSound.CreateInstance();
            playerHitSoundInstance.Volume = 0.4f;
            playerHitSoundInstance.Play();
        }
        public void playEnemyBeamSounds()
        {
            SoundEffectInstance enemyBeamSoundInstance = enemyBeamSound.CreateInstance();
            enemyBeamSoundInstance.Volume = 0.5f;
            enemyBeamSoundInstance.Play();
        }
        public void playMissileSound()
        {
            SoundEffectInstance missileSoundInstance = missileSound.CreateInstance();
            missileSoundInstance.Volume = 0.4f;
            missileSoundInstance.Play();
        }

        public bool DisplayMessage(Vector2 position, Message message, SpriteBatch spriteBatch, float deltaTime)
        {
           return messages.show(position, message, spriteBatch, deltaTime);
        }
    }
}
