﻿/*******************************************************************************************************/
// File:    Movement.cs
// Summary: Handles different kind of movement and turning
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    class Movement
    {
        float acceleration;
        float minSpeed;
        float maxSpeed;
        float rotationSpeed;

        public Movement()
        {

        }
        public Movement(float acceleration, float minSpeed, float maxSpeed, float rotationSpeed)
        {
            this.acceleration = acceleration;
            this.minSpeed = minSpeed;
            this.maxSpeed = maxSpeed;
            this.rotationSpeed = rotationSpeed;
        }
        public void setRotationSpeed(float rotationSpeed) { this.rotationSpeed = rotationSpeed; }

        public Vector2 move(Vector2 position, float speed, Vector2 direction, float borderRadius, float deltaTime)
        {
            position += speed * direction * deltaTime;
            position = Geometry.keepPositionInsideCircle(position, borderRadius);

            return position;
        }
        /// <summary>
        /// Gas (accelerate) with the acceleration
        /// </summary>
        /// <param name="deltaTime">Game time step</param>
        public float gas(float speed, float deltaTime)
        {
            // No acceleration if max speed is reached
            if (speed < maxSpeed)
            {
                // New speed increases with acceleration each gametime step
                speed += acceleration;
            }
            return speed;
        }
        /// <summary>
        /// Breake (decelerate) with the acceleration
        /// </summary>
        /// <param name="deltaTime">Game time step</param>
        public float break_(float speed, float deltaTime)
        {
            if (speed > minSpeed) // No deceleration if speed is 0
            {
                // New speed decreases with acceleration each gametime step
                speed -= acceleration;
            }
            return speed;
        }
        /// <summary>
        /// Turns left. Changing the direction counter clockwise with the rotation speed.
        /// </summary>
        /// <param name="deltaTime">Game time step</param>
        public float turnLeft(float angle, float deltaTime)
        {
            // Rotation angle is decreased each game time step
            angle -= rotationSpeed;

            return angle;
        }
        /// <summary>
        /// Turns right. Turns left. Changing the direction clockwise with the rotation speed.
        /// </summary>
        /// <param name="deltaTime">Game time step</param>
        public float turnRight(float angle, float deltaTime)
        {
            // Rotation angle is increased each game time step
            angle += rotationSpeed;

            return angle;
        }
    }
}
