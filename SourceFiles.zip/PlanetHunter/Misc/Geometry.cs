﻿/*******************************************************************************************************/
// File:    Geometry.cs
// Summary: Performs some mathematical operations.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using System;
using Microsoft.Xna.Framework;

namespace Model
{
    static class Geometry
    {
        // Defines some constants, used in the game.
        public static readonly Random rand = new System.Random();
        public static readonly float PI = (float)Math.PI;

        /// <summary>
        /// Returns the absolute value (length) of a vector
        /// </summary>
        public static float AbsoluteValue(Vector2 vector)
        {
            return (float)Math.Sqrt(vector.X * vector.X + vector.Y * vector.Y);
        }
        /// <summary>
        /// Calculating the angle from the direction
        /// </summary>
        public static Vector2 AngleToDirection(float angle)
        {
            Vector2 direction = new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle));
            direction.Normalize();

            return direction;
        }
        /// <summary>
        /// Calculating the direction from the angle
        /// </summary>
        public static float DirectionToAngel(Vector2 direction)
        {
            float angle = 0; // new Vector2((float)Math.Cos(angle), (float)Math.Sin(angle));

            return angle;
        }
        /// <summary>
        /// Determines if Two circles intersect or (if one diameter is set to 0, if something is inside a circle
        /// </summary>
        public static bool IsInsideCircle(Vector2 positionOfObject, float diameterOfObject, Vector2 positionOfCircle, float diameterOfCircle) 
        {
            positionOfObject = positionOfObject + new Vector2(diameterOfObject / 2, diameterOfObject / 2);
            positionOfCircle = positionOfCircle + new Vector2(diameterOfCircle / 2, diameterOfCircle / 2);
            return AbsoluteValue(positionOfObject - positionOfCircle) < diameterOfObject + diameterOfCircle;
        }
        /// <summary>
        /// Returns a position inside a circle
        /// </summary>
        public static Vector2 PlaceEvenInCircle()
        {
            Vector2 position = new Vector2();
            float angle = (float)(2.0 * Geometry.PI * Geometry.rand.NextDouble());
            position.X = (float)Math.Cos(angle);
            position.Y = (float)Math.Sin(angle);

            return position;
        }
        /// <summary>
        /// Returns a random position, inside a given circle
        /// </summary>
        public static Vector2 PlaceRandomInCircle()
        {
            Vector2 position = new Vector2();
            float angle = (float)(2.0 * Geometry.PI * Geometry.rand.NextDouble());
            position.X = (float)Math.Cos(angle);
            position.Y = (float)Math.Sin(angle);

            return position;
        }
        /// <summary>
        /// Determines if a position is inside a circle. Holding the position inside this circle if it is trying to come out.
        /// </summary>
        public static Vector2 keepPositionInsideCircle(Vector2 position, float radius)
        {
            float angle;
            float distanceFromCentre = (float)Math.Sqrt(position.X * position.X + position.Y * position.Y);

            if (distanceFromCentre != 0)
            {
                angle = (float)Math.Asin(position.Y / distanceFromCentre);
            }
            else
            {
                angle = 0;
            }
            if (distanceFromCentre > radius)
            {
                distanceFromCentre = radius;
            }

            if (position.X > 0)
            {
                position.X = distanceFromCentre * (float)Math.Cos(angle);
            }
            else
            {
                position.X = -distanceFromCentre * (float)Math.Cos(angle);
            }
            position.Y = distanceFromCentre * (float)Math.Sin(angle);

            return position;
        }
    }
}
