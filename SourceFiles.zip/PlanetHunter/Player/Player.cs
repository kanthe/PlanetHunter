﻿/*******************************************************************************************************/
// File:    Player.cs
// Summary: Model representation of the player. Also includes methods for crasching, taking damage and 
// landing on planet
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model 
{
    /// <summary>
    /// The player with properties position, speed, diretion and radius.
    /// 
    /// </summary>
    class Player
    {
        public readonly int STARTING_HITPOINTS = 100;
        public static readonly float LANDING_TIME = 3.0f;
        readonly float ROTATION_SPEED = 0.075f;
        readonly float ACCELERATION = 0.01f;
        float maxSpeed = 0.1f;
        readonly float MIN_SPEED = 0.0f;

        Vector2 position; // Position of the player in model coordinates
        float angle; // Angle for the pointing direction in radians
        float speed; // Speed in pixels per gametime step
        Vector2 direction; // Moving direction
        float diameter = 0.03f; // Diameter of the player
        Color color = Color.White;
        int hitPoints;
        public int MIN_HP = 0; // Minimum hitpoints
        Movement movement; // Object to handle movement including accelerating, turning, etc.
        BeamWeapon beamWeapon; 
        Missile missile;
        bool playerIsLanding; // True if player is over a landable planet and holds land button 
        Activator landActivator; // Is activated when player is landing
        bool showLandingCircle = false; // Indicating that player is over a landable planet
        bool resetLandingBar = false; // Used to tell gameView that the landing bar at sidebar should be reset
        /// <summary>
        /// Constructor: Sets the fields
        /// </summary>
        public Player(Vector2 position)
        {
            hitPoints = STARTING_HITPOINTS;
            this.position = position;
            angle = (float)(Geometry.rand.NextDouble() * 2 * System.Math.PI);
            speed = MIN_SPEED;
            // Trigonometric calculation of the starting direction
            direction = Geometry.AngleToDirection(angle);
            movement = new Movement(ACCELERATION, MIN_SPEED, maxSpeed, ROTATION_SPEED);
            beamWeapon = new BeamWeapon(Color.Yellow);
            missile = new Missile(false);;
            landActivator = new Activator(LANDING_TIME);
        }
        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        /// <returns></returns>
        public Vector2 getPosition() { return position; }
        public Vector2 getDirection() { return direction; }
        public float getSpeed() { return speed; }
        public float getAngle() { return angle; }
        public float getDiameter() { return diameter; }
        public Color getColor() {return color; }
        public int getHitPoints() { return hitPoints; }
        // Used be gameController to move or turn the player as reaction to a key stroke
        public Movement getMovement() { return movement; }
        public BeamWeapon getBeamWeapon() { return beamWeapon; }
        public Missile getMissile() { return missile; } 
        public bool getPlayerIsLanding() { return playerIsLanding; }
        public bool getShowLandingCircle() { return showLandingCircle; }
        public bool getResetLandingBar() { return resetLandingBar; }
        
        // SET METHODS
        
        /// <summary>
        /// Setting the position
        /// </summary>
        /// <param name="position"></param>
        public void setPosition(Vector2 position) { this.position = position; }
        public void setDirection(Vector2 direction) { this.direction = direction; }
        public void setSpeed(float speed) { this.speed = speed; }
        public void setAngle(float angle) { this.angle = angle; }
        public void setHitPoints(int newHitPoints) { hitPoints = newHitPoints; }
        public void setMAX_SPEED(float MAX_SPEED) { this.maxSpeed = MAX_SPEED; }
        public void setColor(Color newColor) { color = newColor; }

        // CRASH

        public void crash()
        {
            hitPoints -= 50;
        }

        // Take DAMAGE

        public void isHit(int damage)
        {
            hitPoints -= damage;
        }

        // WEAPONS

        // Returns true if beam is fired
        // Used by gameController to activate beam when beam button is pressed
        public bool shootBeams(bool fireButtonPressed, float deltaTime) 
        {
            return beamWeapon.fire(fireButtonPressed, deltaTime, position, angle);
        }

        // Returns true if missile is fired
        // Used by gameController to activate misslie when missile button is pressed
        public bool launchMissile(bool fireButtonPressed, float deltaTime)
        {
            return missile.launch(fireButtonPressed, deltaTime, position, angle);
        }

        // LAND ON PLANET

        public bool landOnPlanet(Planet planet, bool keyPressed, float deltaTime)
        {
            playerIsLanding = false; // True if landing process is happening
            planet.setShowLandingCircle(false); // True if Landing circle should be shown
            float planetRadius = planet.getDiameter(); // Radius of the planet

            // If player is over the planet and planet is landable
            if (Geometry.IsInsideCircle(position, diameter, planet.getPosition(), planet.getDiameter()) 
                && planet.getIsLandable())
            {
                planet.setPlayerOverPlanet(true); // Then playerOverPlanet = true
                playerIsLanding = landActivator.activeOnHold(keyPressed, deltaTime); // True if landing button is pressed

                if( playerIsLanding ) // Then landingbar is NOT reseted and LANDING CIRCLE is shown
                {
                    planet.setShowLandingCircle(true);
                    resetLandingBar = false;
                }
                else
                {
                    resetLandingBar = true; // Else reset landingbar
                }

                // If landingbar loadtime is reached
                if (playerIsLanding && landActivator.getReachedResetTime())
                {
                    planet.land(this); // Player lands
                    resetLandingBar = true; // Landingbar is reset

                    // Player gets a new ability if such is avilable on the planet
                    switch(planet.getPower()) 
                    {
                        case PlanetPower.AutoFire:
                            beamWeapon.setHasAutoFire(true);
                            break;
                        case PlanetPower.Missile:
                            missile.setMissileActivated(true);
                            break;
                    }
                    // ...and true is returned, telling gameController in this case, that player has landed!
                    return true; 
                }
            }
            // If player is not over a planet:
            else
            {
                planet.setPlayerOverPlanet(false);
            }
            return false;
         }
            

    }
}
