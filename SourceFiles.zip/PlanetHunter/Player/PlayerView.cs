﻿/*******************************************************************************************************/
// File:    PlayerView.cs
// Summary: Drawing the player
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    /// <summary>
    /// Creating visual representation of the player, the engine sound, the player´s fired beams
    /// and other assets accosiated with the player.
    /// </summary>
    class PlayerView
    {
        Camera camera;
        Texture2D playerTexture; // Texture of Player´s ship
        
        public PlayerView(int scale, GraphicsDevice device, ContentManager content)
        {
            camera = GameView.camera;
            // www.iconfinder.com/aha-soft
            playerTexture = content.Load<Texture2D>("player");
        }

        /// <summary>
        /// Translating the position of the player to visual coordinates 
        /// and draws the player. Activated each gametime step.
        /// </summary>
        public void DrawPlayer(Player player, int scale, SpriteBatch spriteBatch)
        {
            int viewDiameter = (int)camera.scaleObject(player.getDiameter()); // Radius of the player
            // The position calculation is done in the camera class
            Vector2 centreViewPosition = camera.modelPositionToViewPosition(player.getPosition());
            int centreViewPositionX = (int)centreViewPosition.X;
            int centreViewPositionY = (int)centreViewPosition.Y;
            // The position and the diameter (radius * 2) is used when drawing the player texture
            Rectangle destinationRectangle = new Rectangle(centreViewPositionX, centreViewPositionY, viewDiameter * 2, viewDiameter);
            Vector2 origin = new Vector2(viewDiameter * 3 / 4, viewDiameter * 3 / 8);
            // Drawing the player
            spriteBatch.Draw(playerTexture, destinationRectangle, null, player.getColor(), player.getAngle(), origin, SpriteEffects.None, 0);
        }
        
        

        
    }
}
