﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using View;

namespace Model 
{
    /// <summary>
    /// The player with properties position, speed, diretion and radius.
    /// 
    /// </summary>
    class Player
    {
        public readonly int STARTING_HITPOINTS = 100;
        public static readonly float LANDING_TIME = 3.0f;
        readonly float ROTATION_SPEED = 0.075f;
        readonly float ACCELERATION = 0.01f;
        float maxSpeed = 0.1f;
        readonly float MIN_SPEED = 0.0f;

        Vector2 position; // Position of the player in model coordinates
        float angle; // Angle for Player's direction in radians
        float speed; // Speed in pixels per gametime step
        Vector2 direction;
        float diameter = 0.03f; // Diameter of the player
        Color color = Color.White;
        int hitPoints;
        public int MIN_HP = 0;
        bool playerIsLanding = false;

        Movement movement;
        Activator landActivator;
        BeamWeapon beamWeapon;
        Missile missile;
        /// <summary>
        /// Constructor: Sets the fields
        /// </summary>
        public Player(Vector2 position)
        {
            hitPoints = STARTING_HITPOINTS;
            this.position = position;
            angle = (float)(Geometry.rand.NextDouble() * 2 * System.Math.PI);
            speed = MIN_SPEED;
            // Trigonometric calculation of the starting direction
            direction = Geometry.AngleToDirection(angle);
            movement = new Movement(ACCELERATION, MIN_SPEED, maxSpeed, ROTATION_SPEED);
            beamWeapon = new BeamWeapon(Color.Yellow);
            missile = new Missile(false);
            landActivator = new Activator(LANDING_TIME);
        }
        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        /// <returns></returns>
        public Vector2 getPosition() { return position; }
        public Vector2 getDirection() { return direction; }
        public float getSpeed() { return speed; }
        public float getAngle() { return angle; }
        public float getDiameter() { return diameter; }
        public Color getColor() {return color; }
        public int getHitPoints() { return hitPoints; }

        public Movement getMovement() { return movement; }

        public BeamWeapon getBeamWeapon() { return beamWeapon; }
        public Missile getMissile() { return missile; }
        
        // SET METHODS
        
        /// <summary>
        /// Setting the position
        /// </summary>
        /// <param name="position"></param>
        public void setPosition(Vector2 position) { this.position = position; }
        public void setDirection(Vector2 direction) { this.direction = direction; }
        public void setSpeed(float speed) { this.speed = speed; }
        public void setAngle(float angle) { this.angle = angle; }
        public void setHitPoints(int newHitPoints) { hitPoints = newHitPoints; }
        public void setMAX_SPEED(float MAX_SPEED) { this.maxSpeed = MAX_SPEED; }
        public void setColor(Color newColor) { color = newColor; }

        // CRASH

        public void crash()
        {
            hitPoints -= 50;
        }

        // Take DAMAGE

        public void isHit(int damage)
        {
            hitPoints -= damage;
        }

        // WEAPONS

        public bool shootBeams(bool fireButtonPressed, float deltaTime) 
        {
            return beamWeapon.fire(fireButtonPressed, deltaTime, position, angle);
        }

        public bool launchMissile(bool fireButtonPressed, float deltaTime)
        {
            return missile.launch(fireButtonPressed, deltaTime, position, angle);
        }

        // LAND

        public bool landOnPlanet(Planet planet, bool keyPressed, float deltaTime)
        {
            float planetDiameter = planet.getDiameter();

            if (Geometry.IsInsideCircle(position, diameter, planet.getPosition(), planet.getDiameter()) 
                && planet.getPlanetState() != PlanetState.Dead && planet.getPlanetState() != PlanetState.Visited)
            {
                planet.setPlanetState(PlanetState.PlayerOverPlanet);
                playerIsLanding = landActivator.activeOnHold(keyPressed, deltaTime);

                if (playerIsLanding)
                {
                    planet.setPlanetState(PlanetState.PlayerLanding);

                    if(landActivator.getReachedResetTime()) {
                        hitPoints = STARTING_HITPOINTS;
                        planet.setPlanetState(PlanetState.Visited);

                        switch(planet.getPower()) 
                        {
                            case PlanetPower.AutoFire:
                                beamWeapon.setHasAutoFire(true);
                                break;
                            case PlanetPower.Missile:
                                missile.setMissileActivated(true);
                                break;
                        }
                        return true;
                    }
                }
            }
            return false;
         }
            

    }
}
