﻿/*******************************************************************************************************/
// File:    EnemyView.cs
// Summary: Drawing enemies
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class EnemyView
    {
        Camera camera;
        Texture2D class1EnemyTexture;
        Texture2D class2EnemyTexture;
        Texture2D destroyerTexture;
        Texture2D defenceStationTexture;

        public EnemyView(int scale, GraphicsDevice device, ContentManager content)
        {
            camera = GameView.camera;
        

            

            

            // h ttp://findicons.com/icon/132535/raptor
            class1EnemyTexture = content.Load<Texture2D>("raptor"); // Texture for the class 1 type enemies
            // h ttp://findicons.com/icon/132533/viper_mark_vii
            class2EnemyTexture = content.Load<Texture2D>("viper_mark_vii"); // Texture for the class 2 type enemies
            // h ttp://findicons.com/icon/132532/battlestar_galactica
            destroyerTexture = content.Load<Texture2D>("battlestar_galactica"); // Texture for the destroyer type enemies
            // h ttp://mightymec.deviantart.com/art/Federation-Starbase-K-15-2-301834945
            defenceStationTexture = content.Load<Texture2D>("defence_station"); // Texture for the defence station type enemies
        }

        public void DrawEnemies(System.Collections.Generic.List<EnemyTemplate> enemies, SpriteBatch spriteBatch)
        {

            foreach (EnemyTemplate enemy in enemies)
            {
                int viewDiameter = (int)camera.scaleObject(enemy.getDiameter()); // Diameter of the player
                // The position calculation is done in the camera class
                Vector2 centreViewPosition = camera.modelPositionToViewPosition(enemy.getPosition());
                int centreViewPositionX = (int)centreViewPosition.X;
                int centreViewPositionY = (int)centreViewPosition.Y;
                EnemyType type = enemy.getType();
                Texture2D texture = class1EnemyTexture;
                float angle = enemy.getAngle();

                switch (type)
                {
                    case EnemyType.Class1:
                        texture = class1EnemyTexture;
                        break;
                    case EnemyType.Class2:
                        texture = class2EnemyTexture;
                        break;
                    case EnemyType.Destroyer:
                        texture = destroyerTexture;
                        break;
                    case EnemyType.DefenceStation:
                        texture = defenceStationTexture;
                        break;
                }
                Rectangle destinationRectangle;
                Vector2 origin;

                // The StarDestroyer has to be drawn with other parameters to move smoothly
                if (enemy.getType() == EnemyType.Destroyer)
                {
                    origin = new Vector2(viewDiameter / 4, viewDiameter / 4);
                    destinationRectangle = new Rectangle(centreViewPositionX + viewDiameter / 4, centreViewPositionY + viewDiameter / 4, viewDiameter, viewDiameter);
                }
                else
                {
                    origin = new Vector2(viewDiameter, viewDiameter);
                    destinationRectangle = new Rectangle(centreViewPositionX + viewDiameter * 1 / 8, centreViewPositionY + viewDiameter / 8, viewDiameter, viewDiameter);
                }

                // Drawing the enemy

                if (centreViewPositionX > SideBar.SIDEBAR_WIDTH && centreViewPositionX < GameView.WINDOWSIZE.X && centreViewPositionY > 0 && centreViewPositionY < GameView.WINDOWSIZE.Y)
                {
                    spriteBatch.Draw(texture, destinationRectangle, null, enemy.getColor(), angle, origin, SpriteEffects.None, 0);
                }
            }
        }
        
    }
}
