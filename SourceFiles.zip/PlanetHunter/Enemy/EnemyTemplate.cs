﻿/*******************************************************************************************************/
// File:    EnemyTemplate.cs
// Summary: Abstract class used as base class for all enemy types. Defining abstract set methods, 
// ensuring certain properties of an enemy type.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using View;
using System;

namespace Model
{
    public enum EnemyType { Class1, Class2, Destroyer, DefenceStation }

    abstract class EnemyTemplate
    {
        // 
        protected Player player;
        protected Vector2 position; // Position of the enemy in model coordinates
        protected float angle = 0;//(float)(2 * Geometry.PI * (float)Geometry.rand.NextDouble()); // Angle for Enemy's direction in radians
        protected float rotationSpeed;
        protected float speed; // Speed in pixels per gametime step
        protected float diameter = 0.1f; // Radius of the enemy
        protected Color color = Color.Gray; // Color of the enemy
        protected EnemyType type;
        protected int hitPoints; // Enemies hitpoints
        protected int maxHitPoints;
        protected bool didEnemyCrash = false; // True if Player collides with this enemy
        protected Movement movement = new Movement();

        // BEAMS
        protected System.Collections.Generic.List<BeamModel> enemyBeams = new System.Collections.Generic.List<BeamModel>();
        protected float beamSpeed = 0.2f; // Speed of beams in modelunits per se´cond
        protected int beamDiameter = 10; // Size of beams in pixels
        protected Color beamColor; // Color of beams
        protected int beamDamage; // Damage caused by the beam
        protected float beamInterval = 1.0f; // Time interval between each fire
        protected Activator beamActivator = new Activator(0);
        protected float timeSinceLastBeam = 0;
        
        /// <summary>
        /// GET METHODS. Returning parameters for public access
        /// </summary>
        public Vector2 getPosition() { return position; }
        public float getAngle() { return angle; }
        public float getRotationSpeed() { return rotationSpeed; }
        public float getSpeed() { return speed; }
        public float getDiameter() { return diameter; }
        public Color getColor() { return color; }
        public EnemyType getType() { return type; }
        public int getHitPoints() { return hitPoints; }
        public int getMaxHitPoints() { return maxHitPoints; }
        public Movement getMovement() { return movement; }
        public System.Collections.Generic.List<BeamModel> getEnemyBeams() { return enemyBeams; }
        public bool getDidPlayerCrash() { return didEnemyCrash; }

        /// </summary>
        /// SET METHODS. Abstract methods that sets all parameters not implemented in this abstract base class.
        /// </summary>
        public abstract void setPlayer(Player player);
        // ENEMY
        public abstract void setPosition(Vector2 position);
        public abstract void setAngle(float angle);
        public abstract void setRotationSpeed(float rotationSpeed);
        public abstract void setSpeed(float speed);
        public abstract void setDiameter(float radius);
        public abstract void setColor(Color color);
        public abstract void setHitPoints(int hitpoints);
        public abstract void setMaxHitPoints(int maxHitpoints);
        // BEAMS
        public abstract void setBeamSpeed(float beamSpeed);
        public abstract void setBeamDiameter(int beamSize);
        public abstract void setBeamColor(Color beamColor);
        public abstract void setType(EnemyType type);
        public abstract void setBeamDamage(int beamDamage);
        public abstract void setBeamInterval(float beamInterval);
        public abstract void setBeamActivator(float beamInterval);
        
        // WEAPONS

        // Fireing one beam and reseting beam timer, 
        // if timer reaches the interval between each beam
        public bool shootBeams(float deltaTime)
        {
            Vector2 centrePosition = position;
            bool didEnemyShootBeam = false;
            Vector2 directionToPlayer = -new Vector2(centrePosition.X - player.getPosition().X, centrePosition.Y - player.getPosition().Y);
            float distanceToPlayer = Geometry.AbsoluteValue(directionToPlayer);
            directionToPlayer.Normalize();

            if (distanceToPlayer < 0.7f)
            {
                if (beamActivator.activeOnInterval(true, deltaTime))
                {
                    enemyBeams.Add(new BeamModel(centrePosition, directionToPlayer, beamSpeed, beamDiameter, beamColor, beamDamage));
                    didEnemyShootBeam = true;
                }
            }
            return didEnemyShootBeam;
        }

        /// <summary>
        /// ENEMY DAMAGED/DESTROYED
        /// </summary>
        public void crash()
        {
            hitPoints -= 50;
        }

        public void isHit(int damage)
        {
            hitPoints -= damage;
        }
    }
}