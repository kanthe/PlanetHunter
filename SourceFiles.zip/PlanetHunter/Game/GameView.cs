﻿/*******************************************************************************************************/
// File:    GameView.cs
// Summary: Triggered by MasterControllers "Draw" method. Creates view elements, used for drawing 
// certain features. Then triggeres their draw methods.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    /// <summary>
    /// Creating visual representation of the game.
    /// </summary>
    class GameView
    {
        public static readonly Vector2 WINDOWSIZE = new Vector2(1250, 1000); // Size of game window.

        GameSimulation gameSimulation; // Model representation of the game.
        int scale; // One model unit in pixels.
        GraphicsDevice device;
        ContentManager content;
        public static Camera camera;
        EventListener eventListener; // Reakts on events, i.e. playing sound when a button is pressed
        Messages messages; // All messages in the game is made here

        PlayerView playerView; // Visual representation of the player.
        EnemyView enemyView; // Visual representation of an enemy
        BeamView beamsView; // Visual representation of fire beams
        MissileView missileView; // Visual representation of a missile
        MapView mapView; // Visual representation of the Map
        SideBar sideBar; // Area on left side having HP-bar och count down circles

        public GameView(GameSimulation gameSimulation, GraphicsDevice device, ContentManager content, EventListener eventListener, Messages messages)
        {
            this.gameSimulation = gameSimulation;
            this.scale = (int)WINDOWSIZE.Y; // Hight of the window is used as scale
            this.device = device;
            this.content = content;
            this.eventListener = eventListener;
            this.messages = messages;
            camera = new Camera(scale);

            playerView = new PlayerView(scale, device, content);
            enemyView = new EnemyView(scale, device, content);
            beamsView = new BeamView(scale, device, content);
            missileView = new MissileView(scale, device, content);
            mapView = new MapView(gameSimulation.getMap(), scale, device, content);
            sideBar = new SideBar(device, content);
        }

        //DRAWS GAME
        
        public void DrawGame(GameTime gameTime, SpriteBatch spriteBatch)
        {
            // The gametime step in seconds
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // BACKGROUND

            // Setting background color
            device.Clear(Color.Black);
            
            // MAP

            // MapView has methods to draw most game elements, including planets, asteroids, background stars, border around map
            mapView.drawMap(spriteBatch, gameSimulation.getMap());

            // Draws ASTEROIDS

            foreach (Asteroid asteroid in gameSimulation.getMap().getAsteroids())
            {
                mapView.drawAsteroid(asteroid, spriteBatch);
            }

            // PLAYER

            Player player = gameSimulation.getPlayer();
            // The View is centered on the player
            // Everything drawn below will be drawn with respect to player
            camera.centerOn(player.getPosition() - new Vector2(player.getDiameter() / 2, player.getDiameter() / 2));

            // Position on view (screen) coordinates
            Vector2 playerViewPosition = camera.modelPositionToViewPosition(player.getPosition());

            // Draws PLANETS and LAND INDICATOR on a planet if player is over it and it is landable
            foreach (Planet planet in gameSimulation.getMap().getPlanets())
            {
                mapView.DrawPlanet(planet, spriteBatch);
                
                if (planet.getPlayerOverPlanet())
                {
                    mapView.drawLandIndicator(planet, spriteBatch);
                }
            }
            
            // Draws player
            playerView.DrawPlayer(player, scale, spriteBatch);
            // Draws BEAMS (using the "DrawBeams" method in "beamView", which draws all players beams).
            beamsView.DrawBeams(player.getBeamWeapon().getBeams(), scale, spriteBatch);
            // Draws MISSILE
            if (player.getMissile().getMissileLaunched() == true)
            {
                missileView.DrawMissile(player.getMissile(), scale, spriteBatch);
            }

            // ENEMIES

            // Draws enemies
            enemyView.DrawEnemies(gameSimulation.getMap().getEnemies(), spriteBatch);

            // Draws beams (using the "DrawBeams" method in "beamView", which draws all enemies beams).
            foreach (EnemyTemplate enemy in gameSimulation.getMap().getEnemies())
            {
                beamsView.DrawBeams(enemy.getEnemyBeams(), scale, spriteBatch);
            }

            // EXPLOSIONS AND SMOKE

            eventListener.UpdateExplosions(gameTime, spriteBatch, deltaTime);
            eventListener.UpdateSmoke(spriteBatch, deltaTime);

            // SIDEBAR

            // Setting tiimers for the missile and autofire countdown circles
            sideBar.setMissileLoadTimer(player.getMissile().getMissileLoadTime());
            sideBar.setAutoFireLoadTimer(player.getBeamWeapon().getAutoFireLoadTime());
            // Draws sidebar and with it everything that is on it
            sideBar.Draw(player, spriteBatch, deltaTime);

            if (player.getResetLandingBar())
            {
                sideBar.resetLandingBar();
            }
            
            foreach (Planet planet in gameSimulation.getMap().getPlanets())
            {
                if (planet.getShowLandingCircle())
                {
                    sideBar.DrawLandingBar(spriteBatch, deltaTime);
                }
            }

            // SHOW MESSAGE

            if (eventListener.DisplayMessage(playerViewPosition, gameSimulation.getMessage(), spriteBatch, deltaTime))
            {
                if (gameSimulation.getMessage() == Message.GameOver || gameSimulation.getMessage() == Message.LevelComplete)
                {
                    gameSimulation.setGameState(GameState.NewGame);
                }
                gameSimulation.setTrueHasShownMessage(gameSimulation.getMessage());
                gameSimulation.setMessage(Message.None);
            }
        }
    }
}
