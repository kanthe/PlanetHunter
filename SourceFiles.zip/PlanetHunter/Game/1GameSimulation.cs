﻿/*******************************************************************************************************/
// File:    GameSimulation.cs
// Summary: Creates the player and maps and thus setting up initial condition of the game. Also reseting
// initial conditions when restarting game and keep track of current level.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    public enum TutorialState { True, False }
    public enum GameState { StartMode, Menu, NewGame, Continue, Exit }
    public enum Message
    {
        None,
        Opening,
        MapL1Start,
        MapL2Start,
        MapL3Start,
        LevelComplete,
        GameOver,
        FirstPlanetVisit,
        AsteroidWarning,
        DefenceStationWarning,
        LandingSuccessful,
        AutoFire,
        Missile
    }
    
    /// <summary>
    /// Creating the main object models, which are visual in the game (map, player, enemies, planets)
    /// </summary>
    class GameSimulation
    {
        TutorialState tutorialState = TutorialState.False;
        GameState gameState;
        Message message = Message.None;
        bool[] hasShownMessage = new bool[] { false, false, false, false, false, false, false, false, false, false, false, false, false, false, false };
        public int level;
        Player player; // The model representation of the player.
        MapTemplate map; // The model representation of the map.

        public GameSimulation() {
            // Initial conditions
            level = 1;
            Vector2 playerPosition = new Vector2(0.01f, 0.01f);
            player = new Player(playerPosition);
            map = new MapL1(player);
        }

        // GET METHODS

        public TutorialState getTutorialState() { return tutorialState; }
        public GameState getGameState() { return gameState; }
        public Message getMessage() { return message; }
        public bool[] getHasShownMessage() { return hasShownMessage; }
        public int getLevel() { return level; }
        public Player getPlayer() { return player; }
        public MapTemplate getMap() { return map; }

        // SET METHODS

        public void setTutorialState(TutorialState tutorialState) { this.tutorialState = tutorialState; }
        public void setGameState(GameState gameState) { this.gameState = gameState; }
        public void setMessage(Message message) { this.message = message; }
        public void setTrueHasShownMessage(Message message) { hasShownMessage[(int)message] = true; }
        public void setLevel(int level) { this.level = level; }

        // ADVANCE LEVEL

        public void advanceLevel()
        {
            level++;
        }

        public void goBackLevel()
        {
            level--;
        }

        public void reset()
        {
            gameState = GameState.Continue;
            message = Message.None;
            hasShownMessage[(int)Message.MapL1Start] = false;
            hasShownMessage[(int)Message.MapL2Start] = false;
            hasShownMessage[(int)Message.MapL3Start] = false;

            player = new Player(new Vector2(0.01f, 0.01f));

            switch (level)
            {
                case 1:
                    map = new MapL1(player);
                    break;
                case 2:
                    player.getBeamWeapon().setHasAutoFire(true);
                    player.getMissile().setMissileActivated(true);
                    map = new MapL2(player);
                    break;
                case 3:
                    player.getBeamWeapon().setHasAutoFire(true);
                    player.getMissile().setMissileActivated(true);
                    map = new MapL3(player);
                    break;
                case 4:
                    level = 1;
                    map = new MapL1(player);
                    break;
            }
        }
    }
}
