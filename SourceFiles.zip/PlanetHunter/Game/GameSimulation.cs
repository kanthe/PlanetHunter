﻿/*******************************************************************************************************/
// File:    GameSimulation.cs
// Summary: Creates the player and maps and thus setting up initial condition of the game. Also reseting
// initial conditions when restarting game and keep track of current level.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;

namespace Model
{
    public enum TutorialState { True, False }
    public enum GameState { StartMode, Menu, NewGame, Continue, Exit } // All different states of the game
    // Every message gets its own enum Message value
    public enum Message
    {
        None,
        Opening,
        MapL1Start,
        MapL2Start,
        MapL3Start,
        LevelComplete,
        GameOver,
        FirstPlanetVisit,
        AsteroidWarning,
        DefenceStationWarning,
        LandingSuccessful,
        AutoFire,
        Missile,
        Shield,
        Fury
    }
    
    /// <summary>
    /// Creating the main object models, which are visual in the game, map and player. 
    /// Map creates Enemies, planets asteroids...
    /// </summary>
    class GameSimulation
    {
        TutorialState tutorialState = TutorialState.False; // Determines if a lot of messeges will be show in game or not
        GameState gameState; // State of the game
        Message message = Message.None; // Class containing all messages shown in the game
        // Keeping track of messages so they are not shown many times (if they should'n do that)
        bool[] hasShownMessage = new bool[] { false, false, false, false, false, false, false, false, false, false, false, false, false, false, false };
        public int level;
        int numberOfVisitedPlanets = 0; // Counting visited planets. At a certain amount, players should go to another level
        Player player; // The model representation of the player.
        MapTemplate map; // The model representation of the map.

        public GameSimulation() {
            // Initial conditions
            level = 1;
            player = new Player(new Vector2(0.01f, 0.01f)); // The player
            map = new MapL1(player); // The Map (initially first level)
        }

        // GET METHODS

        public TutorialState getTutorialState() { return tutorialState; }
        public GameState getGameState() { return gameState; }
        public Message getMessage() { return message; }
        public bool[] getHasShownMessage() { return hasShownMessage; }
        public int getLevel() { return level; }
        public int getNumberOfVisitedPlanets() { return numberOfVisitedPlanets; }
        public Player getPlayer() { return player; }
        public MapTemplate getMap() { return map; }

        // SET METHODS

        public void setTutorialState(TutorialState tutorialState) { this.tutorialState = tutorialState; }
        public void setGameState(GameState gameState) { this.gameState = gameState; }
        public void setMessage(Message message) { this.message = message; }
        public void setTrueHasShownMessage(Message message) { hasShownMessage[(int)message] = true; }
        public void setNumberOfVisitedPlanets(int numberOfVisitedPlanets) { this.numberOfVisitedPlanets = numberOfVisitedPlanets; }
        public void setLevel(int level) { this.level = level; }

        // ADVANCE LEVEL

        public void advanceLevel()
        {
            level++;
        }

        public void goBackLevel() // (Triggered by key)
        {
            level--;
        }
        /// <summary>
        /// Sets game back to initial conditions (except possibly a new level)
        /// </summary>
        public void reset()
        {
            gameState = GameState.Continue; // Game continues right after Game Over or Level Done
            message = Message.None;
            // So that the leveel introduction i the beginning is showing again
            hasShownMessage[(int)Message.MapL1Start] = false;
            hasShownMessage[(int)Message.MapL2Start] = false;
            hasShownMessage[(int)Message.MapL3Start] = false;

            player = new Player(new Vector2(0.01f, 0.01f));

            switch (level)
            {
                case 1:
                    map = new MapL1(player);
                    break;
                case 2:
                    // Player does not lose its weapons and abilities at the new level
                    player.getBeamWeapon().setHasAutoFire(true);
                    player.getMissile().setMissileActivated(true);
                    map = new MapL2(player);
                    break;
                case 3:
                    player.getBeamWeapon().setHasAutoFire(true);
                    player.getMissile().setMissileActivated(true);
                    map = new MapL3(player);
                    break;
                case 4:
                    level = 1;
                    map = new MapL1(player);
                    break;
            }
        }
    }
}
