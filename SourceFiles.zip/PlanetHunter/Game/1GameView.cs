﻿/*******************************************************************************************************/
// File:    GameView.cs
// Summary: Triggered by MasterControllers "Draw" method. Creates view elements, used for drawing 
// certain features. Then triggeres their draw methods.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    /// <summary>
    /// Creating visual representation of the game.
    /// </summary>
    class GameView
    {
        public static readonly Vector2 WINDOWSIZE = new Vector2(1250, 1000); // Size of game window.

        GameSimulation gameSimulation; // Model representation of the game.
        int scale; // One model unit in pixels.
        GraphicsDevice device;
        ContentManager content;
        EventListener eventListener;
        Messages messages;
        public static Camera camera;

        PlayerView playerView; // Visual representation of the player.
        EnemyView enemyView;
        BeamView beamsView;
        MissileView missileView;
        MapView mapView;
        SideBar sideBar;
        Texture2D autoFireLoadTexture;

        /// <summary>
        /// CONSTRUCTOR
        /// </summary>
        /// <param name="gameSimulation"></param>
        /// <param name="device"></param>
        /// <param name="content"></param>
        /// <param name="eventListener"></param>
        public GameView(GameSimulation gameSimulation, GraphicsDevice device, ContentManager content, EventListener eventListener, Messages messages)
        {
            this.gameSimulation = gameSimulation;
            this.scale = (int)WINDOWSIZE.Y;
            this.device = device;
            this.content = content;
            this.eventListener = eventListener;
            this.messages = messages;
            camera = new Camera(scale);

            playerView = new PlayerView(scale, device, content);
            enemyView = new EnemyView(scale, device, content);
            beamsView = new BeamView(scale, device, content);
            missileView = new MissileView(scale, device, content);
            mapView = new MapView(gameSimulation.getMap(), scale, device, content);
            sideBar = new SideBar(device, content);
            
            autoFireLoadTexture = new Texture2D(device, 1, 1);
            autoFireLoadTexture.SetData(new[] { Color.White });
        }

        // GET METHODS

        public PlayerView getPlayerView() { return playerView; }
        public EnemyView getEnemyView() { return enemyView; }

        /// DRAW GAME
        
        public void DrawGame(GameTime gameTime, SpriteBatch spriteBatch)
        {
            // The gametime step in seconds
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // BACKGROUND

            // Setting background color
            device.Clear(Color.Black);
            
            // MAP

            mapView.drawMap(spriteBatch, gameSimulation.getMap());

            // Draws ASTEROIDS

            foreach (Asteroid asteroid in gameSimulation.getMap().getAsteroids())
            {
                mapView.drawAsteroid(asteroid, spriteBatch);
            }

            // PLAYER

            Player player = gameSimulation.getPlayer();

            camera.centerOn(player.getPosition() - new Vector2(player.getDiameter() / 2, player.getDiameter() / 2));

            Vector2 playerViewPosition = camera.modelPositionToViewPosition(player.getPosition());

            // Draws PLANETS and LAND INDICATOR on a planet if player is over it and it is landable

            foreach (Planet planet in gameSimulation.getMap().getPlanets())
            {
                mapView.DrawPlanet(planet, spriteBatch);

                if (planet.getPlanetState() == PlanetState.PlayerOverPlanet || planet.getPlanetState() == PlanetState.PlayerLanding)
                {
                    mapView.drawLandIndicator(planet, spriteBatch);
                }
            }
            
            // Draws PLAYER
            playerView.DrawPlayer(player, scale, spriteBatch);
            // Draws BEAMS (using the "DrawBeams" method in "beamView", which draws all players beams).
            beamsView.DrawBeams(player.getBeamWeapon().getBeams(), scale, spriteBatch);
            // Draws MISSILE
            if (player.getMissile().getMissileLaunched() == true)
            {
                missileView.DrawMissile(player.getMissile(), scale, spriteBatch);
            }

            // ENEMIES

            // Draws enemies
            enemyView.DrawEnemies(gameSimulation.getMap().getEnemies(), spriteBatch);

            // Draws enemies beams (using the "DrawBeams" method in "beamView")
            foreach (EnemyTemplate enemy in gameSimulation.getMap().getEnemies())
            {
                beamsView.DrawBeams(enemy.getEnemyBeams(), scale, spriteBatch);
            }

            // EXPLOSIONS AND SMOKE

            eventListener.UpdateExplosions(gameTime, spriteBatch, deltaTime);
            eventListener.UpdateSmoke(spriteBatch, deltaTime);

            // SIDEBAR
            /*
            sideBar.setMissileLoadTimer(player.getMissile().getMissileLoadTime());
            sideBar.setAutoFireLoadTimer(player.getBeamWeapon().getAutoFireLoadTime());
             */
            sideBar.Draw(player, spriteBatch, deltaTime);

            foreach (Planet planet in gameSimulation.getMap().getPlanets())
            {
                if (planet.getPlanetState() == PlanetState.PlayerLanding)
                {
                    sideBar.DrawLandingBar(spriteBatch, deltaTime);

                    if (sideBar.getLandingBar().getCountDownView().getTextureNumber() == 4)
                    {
                        sideBar.getLandingBar().getCountDownView().resetTextureNumber();
                    }
                }
            }

            // SHOW MESSAGE

            if (eventListener.DisplayMessage(playerViewPosition, gameSimulation.getMessage(), spriteBatch, deltaTime))
            {
                if (gameSimulation.getMessage() == Message.GameOver || gameSimulation.getMessage() == Message.LevelComplete)
                {
                    gameSimulation.setGameState(GameState.NewGame);
                }
                gameSimulation.setTrueHasShownMessage(gameSimulation.getMessage());
                gameSimulation.setMessage(Message.None);
            }
        }
    }
}
