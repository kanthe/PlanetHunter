﻿/*******************************************************************************************************/
// File:    GameController.cs
// Summary: GameController is the "motor" of the game. When updated from MasterController it controls 
// the movement and actions of player and enemies. AAlso controlls when messages and shown and all 
// actions in game, triggered by the keyboard.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using View;
using Model;

namespace Controller
{
    /// <summary>
    /// Handles input from player and updates game.
    /// </summary>
    class GameController
    {
        public static bool messageDisplayed = false;
        GameSimulation gameSimulation; // Model representation of the game
        EventListener eventListener;  // Drawing things and/or playing sounds in respons to events
        Activator pauseActivator = new Activator(0); // Controls that game is paused and released when Space is hit
        Messages messages; // Containing all messages shown in the game
        // Activates the levels at one key stroke
        Activator skipLevelActivator = new Activator(0); 
        Activator goBackLevelActivator = new Activator(0);

        public GameController(GameSimulation gameSimulation, EventListener eventListener, Messages messages)
        {
            this.messages = messages;
            gameSimulation.setGameState(GameState.Continue);
            this.gameSimulation = gameSimulation;
            this.eventListener = eventListener;
        }
        /// <summary>
        /// Updates the players AND enemies movement and actions.
        /// </summary>
        /// <param name="gameTime">GameTime object containing total time of game, time since last update, etc.</param>
        /// 
        public void Update(GameTime gameTime)
        {
            // The gametime step in seconds
            float deltaTime = (float)gameTime.ElapsedGameTime.TotalSeconds;

            // Esc: Go to MENU

            bool escapeButtonPressed = Keyboard.GetState().IsKeyDown(Keys.Escape);

            if (escapeButtonPressed)
            {
                gameSimulation.setGameState(GameState.Menu);
            }

            // Space: PAUSE

            bool pauseButtonPressed = Keyboard.GetState().IsKeyDown(Keys.Space);
            bool pause = pauseActivator.activateDeactivateOnRelease(pauseButtonPressed);

            // Makes all the updates if pause is not activated or if the message object do not give pause intructions when playing a message
            if (!pause && !messages.getPauseForMessage()) 
            {
                /*
                 ********************************************************************************
                 * CONTROLS PLAYER                                                             *
                 ********************************************************************************
                 */
                Player player = gameSimulation.getPlayer();

                // MOVE player in current speed and direction using the Movement class
                Vector2 position = player.getMovement().move(player.getPosition(), player.getSpeed(), player.getDirection(), gameSimulation.getMap().getBorderRadius(), deltaTime);
                player.setPosition(position);

                // BACKGROUND STARS movement
                // using slower speeds to create an illusion of deapth

                System.Collections.Generic.List<Star> bgStars = gameSimulation.getMap().getBgStars();
                System.Collections.Generic.List<Star> bgStarsLayer2 = gameSimulation.getMap().getBgStarsLayer2();

                foreach (Star star in bgStars) 
                {
                    Vector2 starPosition = star.getPosition();
                    starPosition = star.getMovement().move(starPosition, player.getSpeed() / 2, player.getDirection(), 1000.0f, deltaTime);
                    star.setPosition(starPosition);
                }
                foreach (Star star in bgStarsLayer2)
                {
                    Vector2 starPosition = star.getPosition();
                    starPosition = star.getMovement().move(starPosition, player.getSpeed() / 3, player.getDirection(), 1000.0f, deltaTime);
                    star.setPosition(starPosition);
                }
                
                //
                // GAS (accelerate)
                //
                if (Keyboard.GetState().IsKeyDown(Keys.Up))
                {
                    float speed = player.getMovement().gas(player.getSpeed(), deltaTime);
                    player.setSpeed(speed);
                    player.setDirection(Geometry.AngleToDirection(player.getAngle()));
                    // Exposions makes illusion of rocket exhause
                    eventListener.MakeExplosion(player.getPosition() - player.getDirection() * player.getDiameter() * 3 / 4, gameTime, 0.2f, 10.0f, 10.0f, 50.0f, 0.1f, 3.0f);
                }
                //
                // BREAK (decelerate)
                //
                if (Keyboard.GetState().IsKeyDown(Keys.Down))
                {
                    float speed = player.getMovement().break_(player.getSpeed(), deltaTime);
                    player.setSpeed(speed);
                }
                //
                // Turn LEFT
                //
                if (Keyboard.GetState().IsKeyDown(Keys.Left))
                {
                    float angle = player.getMovement().turnLeft(player.getAngle(), deltaTime);
                    player.setAngle(angle);
                }
                //
                // Turn RIGHT
                //
                if (Keyboard.GetState().IsKeyDown(Keys.Right))
                {
                    float angle = player.getMovement().turnRight(player.getAngle(), deltaTime);
                    player.setAngle(angle);
                }
                //
                // Shoot BEAM
                //
                // True if player presses the fire button. That does not mean a beam is fired, since 
                // beam is only fired once when pressing the fire button, not one every time step, "deltaTime".
                bool fireButtonPressed = Keyboard.GetState().IsKeyDown(Keys.Q);
                bool playerShootBeams = player.shootBeams(fireButtonPressed, deltaTime);
                // Beam sound
                if (playerShootBeams)
                {
                    eventListener.playPlayerBeamSound();
                }

                // Moving PLAYERS BEAMS. All beams are stored in the BeamWeapon object until deleted (at window boundaries or if it hits an enemy)

                for (int index = player.getBeamWeapon().getBeams().Count - 1; index >= 0; index--)
                {
                    BeamModel beam = player.getBeamWeapon().getBeams()[index];
                    Vector2 beamPosition = player.getMovement().move(beam.getPosition(), beam.getSpeed(), beam.getDirection(), gameSimulation.getMap().getBorderRadius(), deltaTime);
                    beam.setPosition(beamPosition);

                    // ENEMY IS HIT by players beam. 

                    for (int count = gameSimulation.getMap().getEnemies().Count - 1; count >= 0; count--)
                    {
                        EnemyTemplate enemy = gameSimulation.getMap().getEnemies()[count];

                        if (Geometry.IsInsideCircle(beam.getPosition(), 0, enemy.getPosition(), enemy.getDiameter() * 3 / 8))
                        {
                            enemy.isHit(beam.getBeamDamage());
                            player.getBeamWeapon().getBeams().Remove(beam);
                        }
                    }
                }

                // LAUNCH MISSILE

                bool missileButtonPressed = Keyboard.GetState().IsKeyDown(Keys.W);
                bool playerLaunchMissile = player.launchMissile(missileButtonPressed, deltaTime);
                Missile missile = player.getMissile();
                // Missile sound
                if (playerLaunchMissile)
                {
                    eventListener.playMissileSound();
                }
                // Missile moves
                if(player.getMissile().getMissileLaunched() == true) 
                {
                    Vector2 missilePosition = player.getMovement().move(missile.getPosition(), missile.getSpeed(), missile.getDirection(), gameSimulation.getMap().getBorderRadius(), deltaTime);
                    missile.setPosition(missilePosition);
                }

                // Missile HITS ENEMY

                foreach (EnemyTemplate enemy in gameSimulation.getMap().getEnemies())
                {

                    if (missile.getMissileLaunched() && Geometry.IsInsideCircle(missile.getPosition(), 0, enemy.getPosition(), enemy.getDiameter() / 2))
                    {
                        enemy.isHit(missile.getDamage());
                        eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 0.1f, 5.0f, 20.0f, 100.0f, 0.2f, 10.0f);
                        eventListener.playExplosionSound();
                        missile.setMissileLaunched(false);
                    }
                }
                
                // LAND ON PLANET

                System.Collections.Generic.List<Planet> planets = gameSimulation.getMap().getPlanets(); // All planets on map
                bool landButtonPressed = Keyboard.GetState().IsKeyDown(Keys.A);

                foreach (Planet planet in planets)
                {
                    if (    // Showing MESSAGE when player is near the first landable planet, only one time, if tutorial mode is on 
                        gameSimulation.getTutorialState() == TutorialState.True && 
                        !gameSimulation.getHasShownMessage()[(int)Message.FirstPlanetVisit] &&
                        Geometry.IsInsideCircle(player.getPosition(), 0, planet.getPosition(), planet.getDiameter()) &&
                        planet.getIsLandable()
                    )
                    {
                        gameSimulation.setMessage(Message.FirstPlanetVisit);
                    }

                    // landOnPlanet returns true if landing is successful.
                    // Message is played and message and eventual ability or weapon is triggered

                    if (player.landOnPlanet(planet, landButtonPressed, deltaTime))
                    {
                        eventListener.playMessageSound();
                        gameSimulation.setMessage(Message.LandingSuccessful);

                        switch (planet.getPower())
                        {
                            case PlanetPower.AutoFire:
                                gameSimulation.setMessage(Message.AutoFire);
                                break;
                            case PlanetPower.Missile:
                                gameSimulation.setMessage(Message.Missile);
                                break;
                            case PlanetPower.Shield:
                                gameSimulation.setMessage(Message.Shield);
                                break;
                            case PlanetPower.Fury:
                                gameSimulation.setMessage(Message.Fury);
                                break;
                        }
                    }
                    if (!planet.getIsLandable()) // Counting non-landable planets too
                    {
                        gameSimulation.setNumberOfVisitedPlanets(gameSimulation.getNumberOfVisitedPlanets() + 1);
                    }
                }

                // ASTEROID COLLISION

                // Going through all asteroids (stored in the Map) making damage on player and destroyes missile if it gets too near

                System.Collections.Generic.List<Asteroid> asteroids = gameSimulation.getMap().getAsteroids();
                
                for (int count = asteroids.Count - 1; count >= 0; count--)
                {
                    Asteroid asteroid = asteroids[count];
                    Vector2 astroidPosition = asteroid.getPosition();
                    float asteroidSize = (float)asteroid.getSize() / GameView.WINDOWSIZE.Y;

                    if (asteroid.activator.activeOneTimeStep( 
                        Geometry.IsInsideCircle(player.getPosition(), player.getDiameter(), asteroid.getPosition(), asteroidSize)
                        ))
                    {
                        player.isHit(asteroid.getDamage());
                        eventListener.MakeExplosion(asteroid.getPosition() + new Vector2(asteroidSize / 2, asteroidSize / 2), gameTime, 0.05f, 10.0f, 20.0f, 100.0f, 0.1f, 10.0f);
                        eventListener.playExplosionSmallSound();
                        asteroids.Remove(asteroid);

                        // ASTEROID warning message

                        if (gameSimulation.getTutorialState() == TutorialState.True && !gameSimulation.getHasShownMessage()[(int)Message.AsteroidWarning] && gameSimulation.getLevel() == 1)
                        {
                            gameSimulation.setMessage(Message.AsteroidWarning);
                        }
                    }

                    // BEAM HITS AND DESTROYS ASTEROID
                    
                    for (int index = player.getBeamWeapon().getBeams().Count - 1; index >= 0; index--)
                    {
                        BeamModel beam = player.getBeamWeapon().getBeams()[index];

                        if (Geometry.IsInsideCircle(beam.getPosition(), 0, asteroid.getPosition(), (float)asteroid.getSize() / GameView.WINDOWSIZE.Y))
                        {
                            player.getBeamWeapon().getBeams().Remove(beam);
                            asteroids.Remove(asteroid);
                            eventListener.MakeExplosion(asteroid.getPosition() + new Vector2(asteroidSize / 2, asteroidSize / 2), gameTime, 0.05f, 10.0f, 20.0f, 100.0f, 0.1f, 10.0f);
                            eventListener.playExplosionSmallSound();
                        }
                    }
                }
                
                // DEFENCE STATION warning

                if (gameSimulation.getTutorialState() == TutorialState.True && 
                    !gameSimulation.getHasShownMessage()[(int)Message.DefenceStationWarning] && 
                    gameSimulation.getLevel() == 1 &&
                    !player.getMissile().getMissileActivated()
                ) {
                    Planet stationPlanet = gameSimulation.getMap().getPlanets()[6];
                    float distanceToStationPlanet = Geometry.AbsoluteValue(player.getPosition() - stationPlanet.getPosition());

                    if ( distanceToStationPlanet < 0.6)
                    {
                        gameSimulation.setMessage(Message.DefenceStationWarning);
                    }
                }

                // NEW GAME MASSAGE

                // If tutorial mode:

                if (gameSimulation.getTutorialState() == TutorialState.True)
                {
                    if( !gameSimulation.getHasShownMessage()[(int)Message.Opening] && gameSimulation.getLevel() == 1)
                    {
                        gameSimulation.setMessage(Message.Opening);
                    }
                }
                // If normal mode:
                    
                else
                {
                    // Different messages for different levels
                    switch (gameSimulation.getLevel())
                    {
                        case 1:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL1Start] && gameSimulation.getLevel() == 1)
                            {
                                gameSimulation.setMessage(Message.MapL1Start);
                            }
                            break;
                        case 2:
                            if (!gameSimulation.getHasShownMessage()[(int)Message.MapL2Start] && gameSimulation.getLevel() == 2)
                            {
                                gameSimulation.setMessage(Message.MapL2Start);
                            }
                            break;
                                
                        case 3:
                            if( !gameSimulation.getHasShownMessage()[(int)Message.MapL3Start] && gameSimulation.getLevel() == 3)
                            {
                                gameSimulation.setMessage(Message.MapL3Start);
                            }
                            break;
                    }
                }
                
                // GAMEOVER: Testing if player is dead

                if (player.getHitPoints() < player.MIN_HP)
                {
                    gameSimulation.setMessage(Message.GameOver);
                }

                // ADVANCE LEVEL

                if (gameSimulation.getNumberOfVisitedPlanets() == planets.Count)
                {
                    gameSimulation.setMessage(Message.LevelComplete);
                    gameSimulation.advanceLevel();
                }
                else
                {
                    gameSimulation.setNumberOfVisitedPlanets(0);
                }

                /*
                 ********************************************************************************
                 * CONTROLS ENEMIES                                                             *
                 ********************************************************************************
                 */

                System.Collections.Generic.List<EnemyTemplate> enemies = gameSimulation.getMap().getEnemies(); // All enemies
                
                for (int count = enemies.Count - 1; count >= 0; count--)
                {
                    // ENEMIES MOVE

                    // Follows player: Direction and distance to player is calculated

                    EnemyTemplate enemy = enemies[count];
                    Vector2 directionToPlayer = enemy.getPosition() - player.getPosition();
                    float distanceToPlayer = Geometry.AbsoluteValue(directionToPlayer);
                    directionToPlayer.Normalize();
                    Vector2 direction = Geometry.AngleToDirection(enemy.getAngle());
                    
                    Movement movement = enemy.getMovement();
                    float angle = enemy.getAngle();
                    enemy.getMovement().setRotationSpeed(enemy.getRotationSpeed());

                    // Turns slowly. Calculation which decides which direction the nenmy should turn to fastest go to player

                    if (direction.X > 0 && directionToPlayer.X > 0)
                    {
                        
                        if (direction.Y > directionToPlayer.Y) { angle = movement.turnRight(enemy.getAngle(),deltaTime); }
                        else { angle = movement.turnLeft(enemy.getAngle(), deltaTime); }
                    }
                    else if (direction.X < 0 && directionToPlayer.X < 0)
                    {
                        if (direction.Y > directionToPlayer.Y) { angle = movement.turnLeft(enemy.getAngle(), deltaTime); }
                        else { angle = movement.turnRight(enemy.getAngle(), deltaTime); }
                    }
                    else if (direction.X > 0 && directionToPlayer.X < 0)
                    {
                        if (direction.Y > -directionToPlayer.Y) { angle = movement.turnLeft(enemy.getAngle(), deltaTime); }
                        else { angle = movement.turnRight(enemy.getAngle(), deltaTime); }
                    }
                    else if (direction.X < 0 && directionToPlayer.X > 0)
                    {
                        if (direction.Y > -directionToPlayer.Y) { angle = movement.turnRight(enemy.getAngle(), deltaTime); }
                        else { angle = movement.turnLeft(enemy.getAngle(), deltaTime); }
                    }
                    enemy.setAngle(angle);
            
                    // Updating position coordinates. Position is not updated if distance to player is too large. (It then stands still.)
                    // Star Destroyer always follows.
                    if (distanceToPlayer < 0.7f || enemy.getType() == EnemyType.Destroyer)
                    {
                        Vector2 enemyPosition = enemy.getMovement().move(enemy.getPosition(), enemy.getSpeed(), direction, gameSimulation.getMap().getBorderRadius(), deltaTime);
                        enemy.setPosition(enemyPosition);
                    }

                    // ENEMIES SHOOT BEAMS
                    //
                    // True if player presses the fire button. That does not mean a beam is fired, since 
                    // beam is only fired once when pressing the fire button, not one every time step, "deltaTime".

                    if (enemy.shootBeams(deltaTime))
                    {
                        eventListener.playEnemyBeamSounds();
                    }

                    // ENEMIES SMOKE

                    float D = enemy.getDiameter();

                    if ((float)enemy.getHitPoints() / enemy.getMaxHitPoints() > 0.3f && (float)enemy.getHitPoints() / enemy.getMaxHitPoints() < 0.7f)
                    {
                        eventListener.MakeSmoke(enemy.getPosition() + new Vector2(D / 2, D / 2), 15.0f, 50 * D, 250 * D);
                    }
                    // More smoke if more dameged
                    else if ((float)enemy.getHitPoints() / enemy.getMaxHitPoints() > 0 && (float)enemy.getHitPoints() / enemy.getMaxHitPoints() < 0.3f)
                    {
                        eventListener.MakeSmoke(enemy.getPosition() + new Vector2(D / 2, D / 2), 15.0f, 100 * D, 500 * D);
                    }

                    // ENEMIES CRASH

                    if (Geometry.IsInsideCircle(player.getPosition(), player.getDiameter(), enemy.getPosition(), enemy.getDiameter() / 2))
                    {
                        enemy.crash();
                        player.crash();
                    }

                    // ENEMIES DIE

                    if (enemy.getHitPoints() <= 0)
                    {
                        enemies.Remove(enemy);
                        eventListener.removeSmoke();

                        // Larger explosions for larger enemies
                        switch (enemy.getType())
                        {
                            case EnemyType.Class1:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 0.3f, 5.0f, 10.0f, 50.0f, 0.1f, 5.0f);
                                eventListener.playExplosionSmallSound();
                                break;
                            case EnemyType.Class2:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 0.5f, 5.0f, 15.0f, 75.0f, 0.2f, 5.0f);
                                eventListener.playExplosionSound();
                                break;
                            case EnemyType.DefenceStation:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 1.0f, 5.0f, 20.0f, 100.0f, 0.3f, 10.0f);
                                eventListener.playExplosionBigSound();
                                break;
                            case EnemyType.Destroyer:
                                eventListener.MakeExplosion(enemy.getPosition() + new Vector2(enemy.getDiameter() / 8, enemy.getDiameter() / 8), gameTime, 1.5f, 5.0f, 20.0f, 100.0f, 0.5f, 15.0f);
                                eventListener.playExplosionBigSound();
                                break;
                        }
                        
                    }

                    // MOVE ENEMY BEAMS

                    for (int index = enemy.getEnemyBeams().Count - 1; index >= 0; index--)
                    {
                        BeamModel beam = enemy.getEnemyBeams()[index];
                        Vector2 beamPosition = beam.getPosition() + beam.getSpeed() * beam.getDirection() * deltaTime;
                        beam.setPosition(beamPosition);

                        if (Geometry.IsInsideCircle(beam.getPosition(), 0, player.getPosition(), player.getDiameter()))
                        {
                            player.isHit(beam.getBeamDamage()); // Player is hit
                            eventListener.playPlayerHitSound(); // Plays soft sound
                            enemy.getEnemyBeams().Remove(beam);
                            eventListener.MakeExplosion(player.getPosition() + new Vector2(player.getDiameter() / 2, player.getDiameter() / 2), gameTime, 0.1f, 10.0f, 0.0f, 10.0f, 0.3f, 3.0f);
                        }
                    }
                }

                // SKIP/GO BACK TO LEVEL

                if (skipLevelActivator.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.H)))
                {
                    gameSimulation.setMessage(Message.LevelComplete);
                    gameSimulation.advanceLevel();
                }

                if (goBackLevelActivator.activeOneTimeStep(Keyboard.GetState().IsKeyDown(Keys.G)) && gameSimulation.getLevel() >= 2)
                {
                    gameSimulation.setMessage(Message.LevelComplete);
                    gameSimulation.goBackLevel();
                }

                // CHEAT

                if (Keyboard.GetState().IsKeyDown(Keys.L))
                {
                    player.MIN_HP = -10000;
                    player.setMAX_SPEED(0.5f);
                    player.getBeamWeapon().setHasAutoFire(true);
                    player.getBeamWeapon().setAutoFireLoadTime(1.0f);
                    player.getMissile().setMissileActivated(true);
                    player.getMissile().setMissileLoadTime(1.0f);
                }
            }
        }
    }
}

