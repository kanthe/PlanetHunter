﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class SideBar
    {
        public static readonly int SIDEBAR_WIDTH = 250;
        int sideBarHeight = (int)GameView.WINDOWSIZE.Y;
        static Texture2D bgTexture;
        public static Texture2D textCollectionTexture;
        GraphicsDevice device;
        ContentManager content;
        Camera camera;

        HitPointsBar hpBar;
        AutoFireBar autoFireBar;
        MissileBar missileBar;
        LandingBar landingBar;

        public SideBar(GraphicsDevice device, ContentManager content)
        {
            this.device = device;
            this.content = content;
            camera = GameView.camera;
            bgTexture = content.Load<Texture2D>("sidebar_backGround");
            textCollectionTexture = content.Load<Texture2D>("sidebar_text");
            // Draws Hit Points bar
            hpBar = new HitPointsBar(device);
            autoFireBar = new AutoFireBar(device);
            missileBar = new MissileBar(device);
            landingBar = new LandingBar(device);
        }
        public LandingBar getLandingBar() { return landingBar; }
        /*
        public void resetLandingBar()
        {
            landingBar.getCountDownView().resetCountDown();
        }
        public void setAutoFireLoadTimer(float loadTime)
        {
            autoFireBar.getCountDownView().setLoadTimer(loadTime);
        }
        public void setMissileLoadTimer(float loadTime)
        {
            missileBar.getCountDownView().setLoadTimer(loadTime);
        }
        */

        public void Draw(Player player, SpriteBatch spriteBatch, float deltaTime)
        {
            // Half transparant background
            spriteBatch.Draw(bgTexture, new Vector2(0, 0), Color.White);
            // Hitpoints bar
            hpBar.DrawHitPointsBar(player, spriteBatch);

            if (player.getBeamWeapon().getHasAutoFire())
            {
                autoFireBar.Draw(player, spriteBatch, deltaTime);
            }

            if (player.getMissile().getMissileActivated())
            {
                missileBar.Draw(player, spriteBatch, deltaTime);
            }
        }
        
        public void DrawLandingBar(SpriteBatch spriteBatch, float deltaTime)
        {
            landingBar.Draw(spriteBatch, deltaTime);
        }
    }
}
