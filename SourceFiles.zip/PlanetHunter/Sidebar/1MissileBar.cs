﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Model;

namespace View
{
    class MissileBar
    {
        CountDownView countDownView;
        Vector2 textPosition = new Vector2(30, 350);
        Vector2 textSize = new Vector2(210, 30);
        Vector2 textureCoords = new Vector2(0, 60);
        Vector2 countDownCirclePosition;

        public MissileBar(GraphicsDevice device)
        {
            countDownCirclePosition = new Vector2(90, textPosition.Y + 40);
            countDownView = new CountDownView(countDownCirclePosition, device);
        }
        public CountDownView getCountDownView() { return countDownView; }

        public void Draw(Player player, SpriteBatch spriteBatch, float deltaTime)
        {
            float loadTime = player.getMissile().getMissileLoadTime();

            spriteBatch.Draw(
                SideBar.textCollectionTexture,
                new Rectangle((int)textPosition.X, (int)textPosition.Y, (int)textSize.X, (int)textSize.Y),
                new Rectangle((int)textureCoords.X, (int)textureCoords.Y, (int)textSize.X, (int)textSize.Y),
                    Color.White
                    );
            countDownView.Draw(player.getMissile().getMissileLoadTime(), spriteBatch, deltaTime);
        }
    }
}
