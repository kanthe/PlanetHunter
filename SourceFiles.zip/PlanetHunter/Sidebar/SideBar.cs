﻿/*******************************************************************************************************/
// File:    SideBar.cs
// Summary: Creates and draws sidebar and its elements
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class SideBar
    {
        public static readonly int SIDEBAR_WIDTH = 250;
        int sideBarHeight = (int)GameView.WINDOWSIZE.Y;
        static Texture2D bgTexture;
        public static Texture2D textCollectionTexture;

        GraphicsDevice device;
        ContentManager content;
        Camera camera;

        HitPointsBar hpBar;
        AutoFireBar autoFireBar;
        MissileBar missileBar;
        LandingBar landingBar;

        public SideBar(GraphicsDevice device, ContentManager content)
        {
            this.device = device;
            this.content = content;
            camera = GameView.camera;
            bgTexture = content.Load<Texture2D>("sidebar_backGround");
            textCollectionTexture = content.Load<Texture2D>("sidebar_text");
            // Draws Hit Points bar
            hpBar = new HitPointsBar(device);
            autoFireBar = new AutoFireBar(device);
            missileBar = new MissileBar(device);
            landingBar = new LandingBar(device);
        }

        public void resetLandingBar()
        {
            landingBar.getCountDownView().setCountDown(0);
        }
        public void setAutoFireLoadTimer(float loadTime)
        {
            autoFireBar.getCountDownView().setLoadTimer(loadTime);
        }
        public void setMissileLoadTimer(float loadTime)
        {
            missileBar.getCountDownView().setLoadTimer(loadTime);
        }
        
        /// <summary>
        /// Draws different countdown bars and the HP-bar
        /// </summary>
        public void Draw(Player player, SpriteBatch spriteBatch, float deltaTime)
        {
            // Half transparant background
            spriteBatch.Draw(bgTexture, new Vector2(0, 0), Color.White);
            // Hitpoints bar
            hpBar.DrawHitPointsBar(player, spriteBatch);
            // Autofirebar if autofire is activated
            if (player.getBeamWeapon().getHasAutoFire())
            {
                autoFireBar.Draw(player, spriteBatch, deltaTime);
            }
            // Autofirebar if autofire is activated
            if (player.getMissile().getMissileActivated())
            {
                missileBar.Draw(player, spriteBatch, deltaTime);
            }
        }
        // Draws landingbar. Triggered if player is landing 
        public void DrawLandingBar(SpriteBatch spriteBatch, float deltaTime)
        {
            landingBar.Draw(spriteBatch, deltaTime);
        }
    }
}
