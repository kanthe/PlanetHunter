﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class AutoFireBar
    {
        CountDownView countDownView;
        Vector2 textPosition = new Vector2(55, 200);
        Vector2 textSize = new Vector2(135, 30);
        Vector2 textureCoords = new Vector2(0, 30);
        Vector2 countDownPosition;

        public AutoFireBar(GraphicsDevice device)
        {
            countDownPosition = new Vector2(90, textPosition.Y + 40);
            countDownView = new CountDownView(countDownPosition, device);
        }
        public CountDownView getCountDownView() { return countDownView; }

        public void Draw(Player player, SpriteBatch spriteBatch, float deltaTime)
        {
            float loadTime = player.getBeamWeapon().getAutoFireLoadTime();

            spriteBatch.Draw(
                SideBar.textCollectionTexture, 
                new Rectangle((int)textPosition.X, (int)textPosition.Y, (int)textSize.X, (int)textSize.Y),
                new Rectangle((int)textureCoords.X, (int)textureCoords.Y, (int)textSize.X, (int)textSize.Y),
                    Color.White
                    );
            countDownView.Draw(loadTime, spriteBatch, deltaTime);
        }
    }
}
