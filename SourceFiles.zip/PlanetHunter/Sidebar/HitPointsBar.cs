﻿/*******************************************************************************************************/
// File:    HitointsBar.cs
// Summary: Creates and draws HP-bar
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Model;

namespace View
{
    /// <summary>
    /// Creating and drawing a border in a square
    /// </summary>
    class HitPointsBar
    {
        Vector2 textPosition;
        Vector2 textSize;
        Vector2 textureCoords;
        Vector2 hpBarPosition;
        public static readonly int thickness = 20;
        Texture2D hpBarTexture;

        public HitPointsBar(GraphicsDevice device)
        {
            textPosition = new Vector2(75, 20);
            textSize = new Vector2(105, 30);
            textureCoords = new Vector2(115, 0);
            // Making texture for the bar
            hpBarPosition = new Vector2(25, 60);
            hpBarTexture = new Texture2D(device, 1, 1);
            hpBarTexture.SetData(new[] { Color.White });
        }
        /// <summary>
        /// Draws the border, with 4 rectangles
        /// </summary>
        /// <param name="scale">One model unit (square width)</param>
        public void DrawHitPointsBar(Player player, SpriteBatch spriteBatch)
        {
            int scaleFactor = 2;
            int hitPoints = player.getHitPoints();
            int width = player.STARTING_HITPOINTS;
            int posX = (int)hpBarPosition.X;
            int posY = (int)hpBarPosition.Y;
            spriteBatch.Draw(hpBarTexture, new Rectangle(posX, posY, scaleFactor * hitPoints, thickness), Color.Green);
            spriteBatch.Draw(hpBarTexture, new Rectangle(posX + scaleFactor * hitPoints, posY, scaleFactor * (width - hitPoints), thickness), Color.Red);

            spriteBatch.Draw(
                SideBar.textCollectionTexture,
                new Rectangle((int)textPosition.X, (int)textPosition.Y, (int)textSize.X, (int)textSize.Y),
                new Rectangle((int)textureCoords.X, (int)textureCoords.Y, (int)textSize.X, (int)textSize.Y),
                    Color.White
                    );
        }
    }
}
