﻿/*******************************************************************************************************/
// File:    CountDownView.cs
// Summary: Creates and draws a countdown circle.
// Also handles when circle will "turn" one quarter
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class CountDownView
    {
        Vector2 position;
        Vector2 size;
        GraphicsDevice device;
        Timer loadTimer = new Timer(0); // Timer which are used to count down to when countdown will increase one quarter
        int textureNumber = 1;

        Vector2[] countDownTextureCoords;

        public CountDownView(Vector2 position, GraphicsDevice device)
        {
            this.position = position;
            this.device = device;
            size = new Vector2(70, 70);

            countDownTextureCoords = new Vector2[] {
                new Vector2(230, 0), // countDownTextureCoordsFull
                new Vector2(0, 130), // countDownTextureCoordsQuarter1
                new Vector2(74, 130), // countDownTextureCoordsQuarter2
                new Vector2(147, 130), // countDownTextureCoordsQuarter3
                new Vector2(222, 130) // countDownTextureCoordsQuarter4
            };
        }
        // SETS loadtime
        public void setLoadTimer(float loadTime)
        { 
            loadTimer.setTimer(loadTime / 4); // After loadtime / 4, circle has to turn one quarter
        }
        // Each texturenumber shows the countdown at different times. This sets the texturenumber
        public void setCountDown(int textureNumber)
        {
            this.textureNumber = textureNumber;
        }
        /// <summary>
        /// Determining the right texture and draws the countdown circle
        /// </summary>
        public void Draw(bool timesUp, SpriteBatch spriteBatch, float deltaTime)
        {
            
            if (textureNumber == 0)
            {
                if (timesUp)
                {
                    textureNumber++;
                    loadTimer.resetTimer();
                }
            }
            // LOADTIME
            else if (loadTimer.runTimer(deltaTime)) 
            {
                if (textureNumber < 4)
                {
                    textureNumber++;
                    loadTimer.resetTimer();
                }
                else
                {
                    textureNumber = 0;
                }
            }

            Rectangle positionRectangle = new Rectangle((int)position.X, (int)position.Y, (int)size.X, (int)size.Y);
            Rectangle textureRectangle = new Rectangle((int)countDownTextureCoords[textureNumber].X, (int)countDownTextureCoords[textureNumber].Y, (int)size.X, (int)size.Y);

            spriteBatch.Draw(SideBar.textCollectionTexture, positionRectangle, textureRectangle, Color.White);
        }
    }
}
