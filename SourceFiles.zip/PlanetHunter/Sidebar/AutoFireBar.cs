﻿/*******************************************************************************************************/
// File:    CountDownView.cs
// Summary: Creates and draws the autofirebar.
// Version: Version 1.0 - 2016-01-12
// Author:  Robin Kanthe
// Email:   kanthe.robin@gmail.com
// -------------------------------------------
// Log:2016-01-12 Created the file. Robin Kanthe
/*******************************************************************************************************/
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Content;
using Model;

namespace View
{
    class AutoFireBar
    {
        CountDownView countDownView;
        Vector2 textPosition = new Vector2(55, 200);
        Vector2 textSize = new Vector2(135, 30);
        Vector2 textureCoords = new Vector2(0, 30);
        Vector2 countDownPosition;

        public AutoFireBar(GraphicsDevice device)
        {
            countDownPosition = new Vector2(90, textPosition.Y + 40);
            countDownView = new CountDownView(countDownPosition, device);
        }
        public CountDownView getCountDownView() { return countDownView; }
        /// <summary>
        /// 
        /// </summary>
        public void Draw(Player player, SpriteBatch spriteBatch, float deltaTime)
        {
            float loadTime = player.getBeamWeapon().getAutoFireLoadTime();

            spriteBatch.Draw(
                SideBar.textCollectionTexture, 
                new Rectangle((int)textPosition.X, (int)textPosition.Y, (int)textSize.X, (int)textSize.Y),
                new Rectangle((int)textureCoords.X, (int)textureCoords.Y, (int)textSize.X, (int)textSize.Y),
                    Color.White
                    );
            countDownView.Draw(player.getBeamWeapon().getResetCountDownCircle(), spriteBatch, deltaTime);
        }
    }
}
